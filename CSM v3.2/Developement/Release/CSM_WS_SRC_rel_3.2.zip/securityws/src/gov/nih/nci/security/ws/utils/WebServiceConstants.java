package gov.nih.nci.security.ws.utils;


public interface WebServiceConstants
{
	
	public static final String LOGIN = "Login";
	
	public static final String CHECK_PERMISSION = "CheckPermission";

}

-- MySQL dump 9.10
--
-- Host: localhost    Database: csd_ri1
-- ------------------------------------------------------
-- Server version	4.0.18-max-debug

DROP DATABASE IF EXISTS csm_ri;

CREATE DATABASE csm_ri;

USE csm_ri;

SET FOREIGN_KEY_CHECKS=0;

--
-- Table structure for table `csm_application`
--

CREATE TABLE csm_application (
  APPLICATION_ID bigint(20) NOT NULL auto_increment,
  APPLICATION_NAME varchar(100) NOT NULL default '',
  APPLICATION_DESCRIPTION varchar(200) NOT NULL default '',
  DECLARATIVE_FLAG tinyint(1) default NULL,
  ACTIVE_FLAG tinyint(1) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (APPLICATION_ID),
  UNIQUE KEY APPLICATION_NAME (APPLICATION_NAME)
) TYPE=InnoDB;

--
-- Dumping data for table `csm_application`
--

INSERT INTO csm_application VALUES (1,'csm_ri','Common Security Module Reference Implementation',0,0,'2005-03-13');
INSERT INTO csm_application VALUES (2,'csmupt','User Provisioing tool',0,0,'2005-03-13');

--
-- Table structure for table `csm_group`
--

CREATE TABLE csm_group (
  GROUP_ID bigint(20) NOT NULL auto_increment,
  GROUP_NAME varchar(100) NOT NULL default '',
  GROUP_DESC varchar(200) default NULL,
  UPDATE_DATE date NOT NULL default '0000-00-00',
  APPLICATION_ID bigint(20) NOT NULL default '0',
  PRIMARY KEY  (GROUP_ID),
  UNIQUE KEY APPLICATION_ID (APPLICATION_ID,GROUP_NAME),
  KEY idx_APPLICATION_ID (APPLICATION_ID),
  CONSTRAINT `FK_APPLICATION_GROUP` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_group`
--

INSERT INTO csm_group VALUES (1,'HR_MANAGER_GROUP','Group of HR managers','2005-03-16',1);
INSERT INTO csm_group VALUES (2,'EMPLOYEE_GROUP','Group of non-manager employees','2005-03-16',1);
INSERT INTO csm_group VALUES (3,'TECHNICAL_MANAGER_GROUP','Group of Technical Managers','2005-03-16',1);
INSERT INTO csm_group VALUES (4,'BUSINESS_MANAGER_GROUP','Group of business managers','2005-03-16',1);

--
-- Table structure for table `csm_pg_pe`
--

CREATE TABLE csm_pg_pe (
  PG_PE_ID bigint(20) NOT NULL auto_increment,
  PROTECTION_GROUP_ID bigint(20) NOT NULL default '0',
  PROTECTION_ELEMENT_ID bigint(20) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (PG_PE_ID),
  UNIQUE KEY PROTECTION_ELEMENT_ID (PROTECTION_ELEMENT_ID,PROTECTION_GROUP_ID),
  KEY idx_PROTECTION_ELEMENT_ID (PROTECTION_ELEMENT_ID),
  KEY idx_PROTECTION_GROUP_ID (PROTECTION_GROUP_ID),
  CONSTRAINT `FK_PROTECTION_ELEMENT_PROTECTION_GROUP` FOREIGN KEY (`PROTECTION_ELEMENT_ID`) REFERENCES `csm_protection_element` (`PROTECTION_ELEMENT_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_PROTECTION_GROUP_PROTECTION_ELEMENT` FOREIGN KEY (`PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_pg_pe`
--

INSERT INTO csm_pg_pe VALUES (6,3,5,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (7,3,12,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (28,7,19,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (30,7,13,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (32,8,2,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (33,8,13,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (34,8,19,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (35,8,18,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (37,8,9,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (38,8,15,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (39,8,4,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (40,7,21,'2005-03-15');
INSERT INTO csm_pg_pe VALUES (41,8,21,'2005-03-15');
INSERT INTO csm_pg_pe VALUES (43,8,22,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (44,7,28,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (45,8,28,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (46,7,30,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (47,8,30,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (55,8,38,'2005-03-16');
INSERT INTO csm_pg_pe VALUES (66,8,47,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (67,7,48,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (68,8,48,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (70,8,49,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (71,6,38,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (72,6,22,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (73,6,4,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (74,6,18,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (75,6,2,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (76,6,49,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (77,6,15,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (78,7,51,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (79,8,51,'2005-03-17');
INSERT INTO csm_pg_pe VALUES (80,7,52,'2005-03-21');
INSERT INTO csm_pg_pe VALUES (81,8,52,'2005-03-21');
INSERT INTO csm_pg_pe VALUES (82,7,55,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (83,8,55,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (84,7,59,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (85,8,59,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (86,7,60,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (87,8,60,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (88,7,61,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (89,8,61,'2005-03-22');
INSERT INTO csm_pg_pe VALUES (90,8,64,'2005-03-23');
INSERT INTO csm_pg_pe VALUES (91,8,66,'2005-03-23');
INSERT INTO csm_pg_pe VALUES (92,7,67,'2005-03-28');
INSERT INTO csm_pg_pe VALUES (93,8,67,'2005-03-28');
INSERT INTO csm_pg_pe VALUES (94,5,10,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (95,5,68,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (96,5,11,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (97,6,69,'2005-03-29');
INSERT INTO csm_pg_pe VALUES (98,8,69,'2005-03-29');
INSERT INTO csm_pg_pe VALUES (114,6,83,'2005-03-30');
INSERT INTO csm_pg_pe VALUES (115,8,83,'2005-03-30');
INSERT INTO csm_pg_pe VALUES (117,1,71,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (118,1,79,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (146,7,86,'2005-04-01');
INSERT INTO csm_pg_pe VALUES (147,8,86,'2005-04-01');
INSERT INTO csm_pg_pe VALUES (153,6,89,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (154,8,89,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (157,7,98,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (158,8,98,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (159,7,101,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (160,8,101,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (161,6,104,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (162,8,104,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (163,7,106,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (164,8,106,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (165,6,108,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (166,8,108,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (167,6,110,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (168,8,110,'2005-04-03');
INSERT INTO csm_pg_pe VALUES (169,7,112,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (170,8,112,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (171,6,114,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (172,8,114,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (197,6,152,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (198,8,152,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (199,7,154,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (200,8,154,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (201,6,157,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (202,8,157,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (203,7,159,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (204,8,159,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (205,7,161,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (206,8,161,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (207,6,163,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (208,8,163,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (209,7,165,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (210,8,165,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (211,6,167,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (212,8,167,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (213,6,168,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (214,8,168,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (215,8,184,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (216,8,185,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (217,8,186,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (218,8,187,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (219,8,188,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (220,8,189,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (221,8,190,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (222,8,191,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (223,8,192,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (224,8,193,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (225,8,194,'2005-04-04');
INSERT INTO csm_pg_pe VALUES (226,7,195,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (227,8,195,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (228,7,197,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (229,8,197,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (230,8,199,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (231,7,201,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (232,8,201,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (233,7,202,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (234,8,202,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (235,7,204,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (236,8,204,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (237,8,206,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (238,8,207,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (239,8,208,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (240,8,209,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (241,8,210,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (242,8,211,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (243,8,212,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (244,8,213,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (245,8,214,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (246,8,215,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (247,8,216,'2005-04-05');
INSERT INTO csm_pg_pe VALUES (248,7,217,'2005-04-06');
INSERT INTO csm_pg_pe VALUES (249,8,217,'2005-04-06');
INSERT INTO csm_pg_pe VALUES (250,6,218,'2005-04-06');
INSERT INTO csm_pg_pe VALUES (251,8,218,'2005-04-06');
INSERT INTO csm_pg_pe VALUES (252,8,219,'2005-04-07');
INSERT INTO csm_pg_pe VALUES (253,10,79,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (254,10,78,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (255,10,84,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (256,10,76,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (257,10,74,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (258,10,72,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (259,10,73,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (260,10,71,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (261,10,70,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (262,10,75,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (263,10,77,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (264,7,220,'2005-04-07');
INSERT INTO csm_pg_pe VALUES (265,8,220,'2005-04-07');
INSERT INTO csm_pg_pe VALUES (266,6,221,'2005-04-08');
INSERT INTO csm_pg_pe VALUES (267,8,221,'2005-04-08');
INSERT INTO csm_pg_pe VALUES (268,7,222,'2005-04-15');
INSERT INTO csm_pg_pe VALUES (269,8,222,'2005-04-15');
INSERT INTO csm_pg_pe VALUES (270,6,225,'2005-04-15');
INSERT INTO csm_pg_pe VALUES (271,8,225,'2005-04-15');
INSERT INTO csm_pg_pe VALUES (272,1,78,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (273,1,84,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (274,1,76,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (275,1,74,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (276,1,72,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (277,1,73,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (278,1,77,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (279,1,75,'0000-00-00');
INSERT INTO csm_pg_pe VALUES (280,1,70,'0000-00-00');

--
-- Table structure for table `csm_privilege`
--

CREATE TABLE csm_privilege (
  PRIVILEGE_ID bigint(20) NOT NULL auto_increment,
  PRIVILEGE_NAME varchar(100) NOT NULL default '',
  PRIVILEGE_DESCRIPTION varchar(200) default NULL,
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (PRIVILEGE_ID),
  UNIQUE KEY PRIVILEGE_NAME (PRIVILEGE_NAME)
) TYPE=InnoDB;

--
-- Dumping data for table `csm_privilege`
--

INSERT INTO csm_privilege VALUES (1,'CREATE','This privilege grants permission to a user to create an entity. This entity can be an object, a database entry, or a resource such as a network connection','2005-03-13');
INSERT INTO csm_privilege VALUES (2,'ACCESS','This privilege allows a user to access a particular resource.  Examples of resources include a network or database connection, socket, module of the application, or even the application itself','2005-03-13');
INSERT INTO csm_privilege VALUES (3,'READ','This privilege permits the user to read data from a file, URL, database, an object, etc. This can be used at an entity level signifying that the user is allowed to read data about a particular entry','2005-03-13');
INSERT INTO csm_privilege VALUES (4,'WRITE','This privilege allows a user to write data to a file, URL, database, an object, etc. This can be used at an entity level signifying that the user is allowed to write data about a particular entity','2005-03-13');
INSERT INTO csm_privilege VALUES (5,'UPDATE','This privilege grants permission at an entity level and signifies that the user is allowed to update data for a particular entity. Entities may include an object, object attribute, database row etc','2005-03-13');
INSERT INTO csm_privilege VALUES (6,'DELETE','This privilege permits a user to delete a logical entity. This entity can be an object, a database entry, a resource such as a network connection, etc','2005-03-13');
INSERT INTO csm_privilege VALUES (7,'EXECUTE','This privilege allows a user to execute a particular resource. The resource can be a method, function, behavior of the application, URL, button etc','2005-03-13');

--
-- Table structure for table `csm_protection_element`
--

CREATE TABLE csm_protection_element (
  PROTECTION_ELEMENT_ID bigint(20) NOT NULL auto_increment,
  PROTECTION_ELEMENT_NAME varchar(100) NOT NULL default '',
  PROTECTION_ELEMENT_DESCRIPTION varchar(200) default NULL,
  OBJECT_ID varchar(100) NOT NULL default '',
  ATTRIBUTE varchar(100) default NULL,
  PROTECTION_ELEMENT_TYPE_ID decimal(10,0) default NULL,
  APPLICATION_ID bigint(20) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (PROTECTION_ELEMENT_ID),
  UNIQUE KEY OBJECT_ID (OBJECT_ID,ATTRIBUTE,APPLICATION_ID),
  KEY idx_APPLICATION_ID (APPLICATION_ID),
  CONSTRAINT `FK_PE_APPLICATION` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_protection_element`
--

INSERT INTO csm_protection_element VALUES (1,'EMPLOYEE_SALARY','The Employee salary attribute','gov.nih.nci.security.ri.valueObject.Employee','Salary',NULL,1,'2005-03-13');
INSERT INTO csm_protection_element VALUES (2,'EMPLOYEE_RECORD_4','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_4','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (3,'EMPLOYEE_CLASS','The Employee class is protected from read and update','gov.nih.nci.security.ri.valueObject.Employee','class',NULL,1,'2005-03-13');
INSERT INTO csm_protection_element VALUES (4,'EMPLOYEE_RECORD_2','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_2','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (5,'VIEW_CREATE_EMPLOYEE_ACTION','Protecting create employee action','gov.nih.nci.security.ri.struts.actions.ViewCreateEmployeeAction','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (6,'CREATE_EMPLOYEE_ACTION','Protection for creating an employee','gov.nih.nci.security.ri.struts.actions.CreateEmployeeAction','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (9,'EMPLOYEE_RECORD_6','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_6','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (10,'VIEW_CREATE_PROJECT_ACTION','Protection for create project view','gov.nih.nci.security.ri.struts.actions.ViewCreateProjectAction','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (11,'CREATE_PROJECT_ACTION','Protects the create project action','gov.nih.nci.security.ri.struts.actions.CreateProjectAction','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (12,'CREATE_EMPLOYEE_ACTION','Protects create employee action','gov.nih.nci.security.ri.struts.actions.CreateEmployeeActiona','',NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (13,'EMPLOYEE_RECORD_7','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_7',NULL,NULL,1,'2005-03-14');
INSERT INTO csm_protection_element VALUES (15,'EMPLOYEE_RECORD_9','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_9',NULL,NULL,1,'2005-03-15');
INSERT INTO csm_protection_element VALUES (18,'EMPLOYEE_RECORD_12','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_12',NULL,NULL,1,'2005-03-15');
INSERT INTO csm_protection_element VALUES (19,'EMPLOYEE_RECORD_13','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_13',NULL,NULL,1,'2005-03-15');
INSERT INTO csm_protection_element VALUES (21,'EMPLOYEE_RECORD_15','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_15',NULL,NULL,1,'2005-03-15');
INSERT INTO csm_protection_element VALUES (22,'EMPLOYEE_RECORD_16','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_16',NULL,NULL,1,'2005-03-16');
INSERT INTO csm_protection_element VALUES (28,'EMPLOYEE_RECORD_27','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_27',NULL,NULL,1,'2005-03-16');
INSERT INTO csm_protection_element VALUES (30,'EMPLOYEE_RECORD_29','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_29',NULL,NULL,1,'2005-03-16');
INSERT INTO csm_protection_element VALUES (31,'EMPLOYEE_RECORD_30','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_30',NULL,NULL,1,'2005-03-16');
INSERT INTO csm_protection_element VALUES (38,'EMPLOYEE_RECORD_37','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_37',NULL,NULL,1,'2005-03-16');
INSERT INTO csm_protection_element VALUES (47,'EMPLOYEE_RECORD_46','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_46',NULL,NULL,1,'2005-03-17');
INSERT INTO csm_protection_element VALUES (48,'EMPLOYEE_RECORD_47','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_47',NULL,NULL,1,'2005-03-17');
INSERT INTO csm_protection_element VALUES (49,'EMPLOYEE_RECORD_48','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_48',NULL,NULL,1,'2005-03-17');
INSERT INTO csm_protection_element VALUES (50,'EMPLOYEE_RECORD_49','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_49',NULL,NULL,1,'2005-03-17');
INSERT INTO csm_protection_element VALUES (51,'EMPLOYEE_RECORD_50','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_50',NULL,NULL,1,'2005-03-17');
INSERT INTO csm_protection_element VALUES (52,'EMPLOYEE_RECORD_51','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_51',NULL,NULL,1,'2005-03-21');
INSERT INTO csm_protection_element VALUES (53,'EMPLOYEE_RECORD_52','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_52',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (54,'EMPLOYEE_RECORD_53','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_53',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (55,'EMPLOYEE_RECORD_54','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_54',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (56,'EMPLOYEE_RECORD_55','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_55',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (57,'EMPLOYEE_RECORD_56','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_56',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (58,'EMPLOYEE_RECORD_57','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_57',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (59,'EMPLOYEE_RECORD_58','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_58',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (60,'EMPLOYEE_RECORD_59','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_59',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (61,'EMPLOYEE_RECORD_60','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_60',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (62,'EMPLOYEE_RECORD_61','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_61',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (63,'EMPLOYEE_RECORD_62','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_62',NULL,NULL,1,'2005-03-22');
INSERT INTO csm_protection_element VALUES (64,'EMPLOYEE_RECORD_63','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_63',NULL,NULL,1,'2005-03-23');
INSERT INTO csm_protection_element VALUES (65,'EMPLOYEE_RECORD_64','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_64',NULL,NULL,1,'2005-03-23');
INSERT INTO csm_protection_element VALUES (66,'EMPLOYEE_RECORD_65','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_65',NULL,NULL,1,'2005-03-23');
INSERT INTO csm_protection_element VALUES (67,'EMPLOYEE_RECORD_66','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_66',NULL,NULL,1,'2005-03-28');
INSERT INTO csm_protection_element VALUES (68,'MODIFY_EMPLOYEE_PROJECT_ACTION','Action required for modifying employee projects.','MODIFY_EMPLOYEE_PROJECT_ACTION','',NULL,1,'2005-03-28');
INSERT INTO csm_protection_element VALUES (69,'EMPLOYEE_RECORD_67','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_67',NULL,NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (70,'Employee Id','employee Id','gov.nih.nci.security.ri.valueObject.Employee','employeeId',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (71,'Employee First Name','first name of employee','gov.nih.nci.security.ri.valueObject.Employee','firstName',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (72,'Employee Middle Name','employee\'s middle name','gov.nih.nci.security.ri.valueObject.Employee','middleName',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (73,'Employee Last Name','employee\'s last name','gov.nih.nci.security.ri.valueObject.Employee','lastName',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (74,'Employee Phone','employee\'s phone number','gov.nih.nci.security.ri.valueObject.Employee','phoneNumber',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (75,'Employee emailAddr','employee\'s email address','gov.nih.nci.security.ri.valueObject.Employee','emailAddr',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (76,'Employee streetAddr','employee\'s street addr','gov.nih.nci.security.ri.valueObject.Employee','streetAddr',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (77,'Employee City','employee\'s city','gov.nih.nci.security.ri.valueObject.Employee','city',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (78,'Employee state','employee\'s state','gov.nih.nci.security.ri.valueObject.Employee','state',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (79,'Employee Zip','Employee\'s zip','gov.nih.nci.security.ri.valueObject.Employee','zip',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (80,'Employee Projects','the employee\'s projects','gov.nih.nci.security.ri.valueObject.Employee','employeeProjects',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (81,'Employee managerStatus','employee\'s manager status','gov.nih.nci.security.ri.valueObject.Employee','managerStatus',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (82,'Employee SSN','Employee\'s SSN','gov.nih.nci.security.ri.valueObject.Employee','ssn',NULL,1,'2005-03-29');
INSERT INTO csm_protection_element VALUES (83,'EMPLOYEE_RECORD_68','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_68',NULL,NULL,1,'2005-03-30');
INSERT INTO csm_protection_element VALUES (84,'Employee User Name','The Employee\'s csm_user name','gov.nih.nci.security.ri.valueObject.Employee','userName',NULL,1,'2005-03-30');
INSERT INTO csm_protection_element VALUES (85,'Employee Password','The Employee\'s password','gov.nih.nci.security.ri.valueObject.Employee','password',NULL,1,'2005-03-30');
INSERT INTO csm_protection_element VALUES (86,'EMPLOYEE_RECORD_69','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_69',NULL,NULL,1,'2005-04-01');
INSERT INTO csm_protection_element VALUES (87,'Employee associatedIds','the employee\'s associatedIds','gov.nih.nci.security.ri.valueObject.Employee','associatedIds',NULL,1,'2005-04-01');
INSERT INTO csm_protection_element VALUES (88,'Employee availableIds','the employee\'s availableIds','gov.nih.nci.security.ri.valueObject.Employee','availableIds',NULL,1,'2005-04-01');
INSERT INTO csm_protection_element VALUES (89,'EMPLOYEE_RECORD_70','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_70',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (98,'EMPLOYEE_RECORD_79','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_79',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (99,'EMPLOYEE_RECORD_80','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_80',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (100,'EMPLOYEE_RECORD_81','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_81',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (101,'EMPLOYEE_RECORD_82','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_82',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (102,'EMPLOYEE_RECORD_83','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_83',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (103,'EMPLOYEE_RECORD_84','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_84',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (104,'EMPLOYEE_RECORD_85','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_85',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (105,'EMPLOYEE_RECORD_86','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_86',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (106,'EMPLOYEE_RECORD_87','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_87',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (107,'EMPLOYEE_RECORD_88','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_88',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (108,'EMPLOYEE_RECORD_89','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_89',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (109,'EMPLOYEE_RECORD_90','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_90',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (110,'EMPLOYEE_RECORD_91','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_91',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (111,'EMPLOYEE_RECORD_92','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_92',NULL,NULL,1,'2005-04-03');
INSERT INTO csm_protection_element VALUES (112,'EMPLOYEE_RECORD_93','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_93',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (113,'EMPLOYEE_RECORD_94','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_94',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (114,'EMPLOYEE_RECORD_95','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_95',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (152,'EMPLOYEE_RECORD_128','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_128',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (153,'EMPLOYEE_RECORD_129','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_129',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (154,'EMPLOYEE_RECORD_130','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_130',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (155,'EMPLOYEE_RECORD_131','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_131',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (156,'EMPLOYEE_RECORD_132','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_132',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (157,'EMPLOYEE_RECORD_133','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_133',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (158,'EMPLOYEE_RECORD_134','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_134',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (159,'EMPLOYEE_RECORD_135','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_135',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (160,'EMPLOYEE_RECORD_136','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_136',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (161,'EMPLOYEE_RECORD_137','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_137',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (162,'EMPLOYEE_RECORD_138','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_138',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (163,'EMPLOYEE_RECORD_139','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_139',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (164,'EMPLOYEE_RECORD_140','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_140',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (165,'EMPLOYEE_RECORD_141','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_141',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (166,'EMPLOYEE_RECORD_142','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_142',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (167,'EMPLOYEE_RECORD_143','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_143',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (168,'EMPLOYEE_RECORD_144','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_144',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (173,'RI Test Case',NULL,'vinaykumar1112669316187',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (174,'RI Test Case',NULL,'vinaykumar1112669317437',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (175,'RI Test Case',NULL,'vinaykumar1112669318468',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (176,'RI Test Case',NULL,'vinaykumar1112669319484',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (177,'RI Test Case',NULL,'vinaykumar1112669320500',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (178,'RI Test Case',NULL,'vinaykumar1112669321546',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (179,'RI Test Case',NULL,'vinaykumar1112669322531',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (180,'RI Test Case',NULL,'vinaykumar1112669323578',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (181,'RI Test Case',NULL,'vinaykumar1112669324609',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (182,'RI Test Case',NULL,'vinaykumar1112669325625',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (183,'RI Test Case',NULL,'vinaykumar1112669326671',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (184,'RI Test Case',NULL,'vinaykumar1112670058578',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (185,'RI Test Case',NULL,'vinaykumar1112670081796',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (186,'RI Test Case',NULL,'vinaykumar1112670102953',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (187,'RI Test Case',NULL,'vinaykumar1112670115375',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (188,'RI Test Case',NULL,'vinaykumar1112670118390',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (189,'RI Test Case',NULL,'vinaykumar1112670121000',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (190,'RI Test Case',NULL,'vinaykumar1112670123312',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (191,'RI Test Case',NULL,'vinaykumar1112670125578',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (192,'RI Test Case',NULL,'vinaykumar1112670128062',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (193,'RI Test Case',NULL,'vinaykumar1112670130375',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (194,'RI Test Case',NULL,'vinaykumar1112670132828',NULL,NULL,1,'2005-04-04');
INSERT INTO csm_protection_element VALUES (195,'EMPLOYEE_RECORD_145','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_145',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (196,'EMPLOYEE_RECORD_146','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_146',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (197,'EMPLOYEE_RECORD_147','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_147',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (198,'EMPLOYEE_RECORD_148','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_148',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (199,'RI Test Case',NULL,'modikunal1112712780793',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (200,'RI Test Case',NULL,'modikunal1112712786572',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (201,'EMPLOYEE_RECORD_150','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_150',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (202,'EMPLOYEE_RECORD_151','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_151',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (203,'EMPLOYEE_RECORD_152','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_152',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (204,'EMPLOYEE_RECORD_153','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_153',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (205,'EMPLOYEE_RECORD_154','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_154',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (206,'RI Test Case',NULL,'copeneric1112715275491',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (207,'RI Test Case',NULL,'copeneric1112715277213',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (208,'RI Test Case',NULL,'copeneric1112715278825',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (209,'RI Test Case',NULL,'copeneric1112715280328',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (210,'RI Test Case',NULL,'copeneric1112715281990',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (211,'RI Test Case',NULL,'copeneric1112715283582',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (212,'RI Test Case',NULL,'copeneric1112715285104',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (213,'RI Test Case',NULL,'copeneric1112715288790',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (214,'RI Test Case',NULL,'copeneric1112715290382',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (215,'RI Test Case',NULL,'copeneric1112715291904',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (216,'RI Test Case',NULL,'copeneric1112715293456',NULL,NULL,1,'2005-04-05');
INSERT INTO csm_protection_element VALUES (217,'EMPLOYEE_RECORD_156','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_156',NULL,NULL,1,'2005-04-06');
INSERT INTO csm_protection_element VALUES (218,'EMPLOYEE_RECORD_157','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_157',NULL,NULL,1,'2005-04-06');
INSERT INTO csm_protection_element VALUES (219,'EMPLOYEE_RECORD_158','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_158',NULL,NULL,1,'2005-04-07');
INSERT INTO csm_protection_element VALUES (220,'EMPLOYEE_RECORD_159','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_159',NULL,NULL,1,'2005-04-07');
INSERT INTO csm_protection_element VALUES (221,'EMPLOYEE_RECORD_160','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_160',NULL,NULL,1,'2005-04-08');
INSERT INTO csm_protection_element VALUES (222,'EMPLOYEE_RECORD_161','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_161',NULL,NULL,1,'2005-04-15');
INSERT INTO csm_protection_element VALUES (223,'csmupt',NULL,'csmupt',NULL,NULL,2,'0000-00-00');
INSERT INTO csm_protection_element VALUES (224,'csm_ri',NULL,'csm_ri',NULL,NULL,2,'0000-00-00');
INSERT INTO csm_protection_element VALUES (225,'EMPLOYEE_RECORD_162','The gov.nih.nci.security.ri.valueObject.Employee Object','gov.nih.nci.security.ri.valueObject.Employee_162',NULL,NULL,1,'2005-04-15');

--
-- Table structure for table `csm_protection_group`
--

CREATE TABLE csm_protection_group (
  PROTECTION_GROUP_ID bigint(20) NOT NULL auto_increment,
  PROTECTION_GROUP_NAME varchar(100) NOT NULL default '',
  PROTECTION_GROUP_DESCRIPTION varchar(200) default NULL,
  APPLICATION_ID bigint(20) NOT NULL default '0',
  LARGE_ELEMENT_COUNT_FLAG tinyint(1) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PARENT_PROTECTION_GROUP_ID bigint(20) default NULL,
  PRIMARY KEY  (PROTECTION_GROUP_ID),
  UNIQUE KEY APPLICATION_ID (APPLICATION_ID,PROTECTION_GROUP_NAME),
  KEY idx_APPLICATION_ID (APPLICATION_ID),
  KEY idx_PARENT_PROTECTION_GROUP_ID (PARENT_PROTECTION_GROUP_ID),
  CONSTRAINT `FK_PG_APPLICATION` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_PROTECTION_GROUP` FOREIGN KEY (`PARENT_PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`)
) TYPE=InnoDB;

--
-- Dumping data for table `csm_protection_group`
--

INSERT INTO csm_protection_group VALUES (1,'EMPLOYEE_PROTECTED_ATTRIBUTES','This group is created to protect attributes about employees',1,0,'2005-03-13',NULL);
INSERT INTO csm_protection_group VALUES (3,'SECURED_HR_ACTIONS','Actions that HR Manager have exclusive access to execute',1,0,'2005-03-14',NULL);
INSERT INTO csm_protection_group VALUES (5,'SECURED_MANAGER_ACTIONS','Actions that Managers have exclusive access to',1,0,'2005-03-14',NULL);
INSERT INTO csm_protection_group VALUES (6,'BUSINESS_DIVISION','This group represents the business division employee base',1,0,'2005-03-15',NULL);
INSERT INTO csm_protection_group VALUES (7,'TECHNICAL_DIVISION','The technical division employee base',1,0,'2005-03-15',NULL);
INSERT INTO csm_protection_group VALUES (8,'HR_DIVISION','Protection group with access to all employees',1,0,'2005-03-15',NULL);
INSERT INTO csm_protection_group VALUES (10,'EMPLOYEE_PUBLIC_ATTRIBUTES','Attributes that do not require security to view',1,0,'2005-03-29',NULL);

--
-- Table structure for table `csm_role`
--

CREATE TABLE csm_role (
  ROLE_ID bigint(20) NOT NULL auto_increment,
  ROLE_NAME varchar(100) NOT NULL default '',
  ROLE_DESCRIPTION varchar(200) default NULL,
  APPLICATION_ID bigint(20) NOT NULL default '0',
  ACTIVE_FLAG tinyint(1) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (ROLE_ID),
  UNIQUE KEY APPLICATION_ID (APPLICATION_ID,ROLE_NAME),
  KEY idx_APPLICATION_ID (APPLICATION_ID),
  CONSTRAINT `FK_APPLICATION_ROLE` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_role`
--

INSERT INTO csm_role VALUES (1,'EMPLOYEE_MANAGER','Manager of Employees',1,0,'2005-03-13');
INSERT INTO csm_role VALUES (2,'HR_MANAGER','Role for HR Managers',1,0,'2005-03-14');
INSERT INTO csm_role VALUES (3,'EMPLOYEE','The csm_role assigned to an employee',1,0,'2005-03-14');
INSERT INTO csm_role VALUES (4,'READ_ONLY_ROLE','to give read only permission',1,0,'2005-03-14');

--
-- Table structure for table `csm_role_privilege`
--

CREATE TABLE csm_role_privilege (
  ROLE_PRIVILEGE_ID bigint(20) NOT NULL auto_increment,
  ROLE_ID bigint(20) NOT NULL default '0',
  PRIVILEGE_ID bigint(20) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (ROLE_PRIVILEGE_ID),
  UNIQUE KEY PRIVILEGE_ID (PRIVILEGE_ID,ROLE_ID),
  KEY idx_PRIVILEGE_ID (PRIVILEGE_ID),
  KEY idx_ROLE_ID (ROLE_ID),
  CONSTRAINT `FK_PRIVILEGE_ROLE` FOREIGN KEY (`PRIVILEGE_ID`) REFERENCES `csm_privilege` (`PRIVILEGE_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_ROLE` FOREIGN KEY (`ROLE_ID`) REFERENCES `csm_role` (`ROLE_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_role_privilege`
--

INSERT INTO csm_role_privilege VALUES (1,1,5,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (2,1,3,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (4,2,7,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (5,2,3,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (6,2,5,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (8,1,7,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (9,3,3,'0000-00-00');
INSERT INTO csm_role_privilege VALUES (10,3,5,'0000-00-00');

--
-- Table structure for table `csm_user`
--

CREATE TABLE csm_user (
  USER_ID bigint(20) NOT NULL auto_increment,
  LOGIN_NAME varchar(100) NOT NULL default '',
  FIRST_NAME varchar(100) NOT NULL default '',
  LAST_NAME varchar(100) NOT NULL default '',
  ORGANIZATION varchar(100) default NULL,
  DEPARTMENT varchar(100) default NULL,
  TITLE varchar(100) default NULL,
  PHONE_NUMBER varchar(15) default NULL,
  PASSWORD varchar(100) default NULL,
  EMAIL_ID varchar(100) default NULL,
  START_DATE date default NULL,
  END_DATE date default NULL,
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (USER_ID),
  UNIQUE KEY LOGIN_NAME (LOGIN_NAME)
) TYPE=InnoDB;

--
-- Dumping data for table `csm_user`
--

INSERT INTO csm_user VALUES (2,'NCICB_Test','NCICB_Test','NCICB_Test','NCICB_Test','NCICB_Test','NCICB_Test',NULL,NULL,NULL,NULL,NULL,'0000-00-00');
INSERT INTO csm_user VALUES (4,'business_manager','employee_manager','employee_manager','employee_manager','employee_manager','employee_manager','2025558888','employee_manager','employee_manager@test.com',NULL,NULL,'2005-03-13');
INSERT INTO csm_user VALUES (5,'employee_1','employee_1','employee_1','employees','employees','employee','2025558899','employee_1','employee_1@test.com',NULL,NULL,'2005-03-13');
INSERT INTO csm_user VALUES (7,'employee_2','employee_2','employee_2','Test','IT','employee','2056699992','employee_2','employee_2@test.com',NULL,NULL,'2005-03-14');
INSERT INTO csm_user VALUES (8,'hr_manager','hr_manager','hr_manager','HR','HR','hr_manager','3015589746','hr_manager','hr_manager@test.com',NULL,NULL,'2005-03-14');
INSERT INTO csm_user VALUES (9,'employee_3','employee_3','employee_3','IT','IT','Architect','3015894455','employee_3','employee_3@test.com',NULL,NULL,'2005-03-14');
INSERT INTO csm_user VALUES (10,'technical_manager','technical_manager','technical_manager','IT','IT','Program Manager','2025589746','technical_manager','technical_manager@test.com',NULL,NULL,'2005-03-14');
INSERT INTO csm_user VALUES (11,'employee_4','employee_4','employee_4','Business','Business','BD','5556669999','employee_4','employee_4@test.com',NULL,NULL,'2005-03-15');
INSERT INTO csm_user VALUES (12,'employee_5','employee_5','employee_5','Business','BD','Administrator','3012568974','employee_5','employee_5@test.com',NULL,NULL,'2005-03-15');
INSERT INTO csm_user VALUES (13,'employee_6','employee_6','employee_6','Technical','IT','Programmer','3012569988','employee_6','employee_6@test.com',NULL,NULL,'2005-03-15');
INSERT INTO csm_user VALUES (14,'employee_7','employee_7','employee_7','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'2025549877','employee_7','employee_7@test.com',NULL,NULL,'2005-03-16');
INSERT INTO csm_user VALUES (24,'employee_8','employee_8','employee_8','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3014567899','employee_8','employee_8@test.com',NULL,NULL,'2005-03-16');
INSERT INTO csm_user VALUES (26,'employee_9','employee_9','employee_9','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3018974455','employee_9','employee_9@test.com',NULL,NULL,'2005-03-16');
INSERT INTO csm_user VALUES (34,'employee_11','employee_11','employee_11','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_11','employee_11@test.com',NULL,NULL,'2005-03-16');
INSERT INTO csm_user VALUES (43,'hr_manager_2','hr_manager_2','hr_manager_2','HR_DIVISION','HR_DIVISION',NULL,'2136549877','hr_manager_2','hr_manager_2@test.com',NULL,NULL,'2005-03-17');
INSERT INTO csm_user VALUES (44,'technical_manager_2','technical_manager_2','technical_manager_2','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'12323423456','technical_manager_2','technical_manager_2@test.com',NULL,NULL,'2005-03-17');
INSERT INTO csm_user VALUES (45,'business_manager_2','business_manager_2','business_manager_2','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','business_manager_2','business_manager_2@tset.com',NULL,NULL,'2005-03-17');
INSERT INTO csm_user VALUES (46,'employee_13','employee_13','employee_13','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_13','employee_13@test.com',NULL,NULL,'2005-03-17');
INSERT INTO csm_user VALUES (52,'modik','Kunal','Modi','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','modik','Kunal.Modi@gmail.com',NULL,NULL,'2005-03-22');
INSERT INTO csm_user VALUES (53,'eric','eric','copen','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3','eric','3',NULL,NULL,'2005-03-22');
INSERT INTO csm_user VALUES (56,'employee_20','employee_20','employee_20','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_20','employee_20@test.com',NULL,NULL,'2005-03-28');
INSERT INTO csm_user VALUES (57,'employee_21','employee_21','employee_21','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'4108971200','employee_21','employee_21@test.com',NULL,NULL,'2005-03-29');
INSERT INTO csm_user VALUES (58,'employee_22','employee_22','employee_22','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_22','employee_22@test.com',NULL,NULL,'2005-03-30');
INSERT INTO csm_user VALUES (59,'test1','first1','last1','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'234-987-7654','test1','test@test.com',NULL,NULL,'2005-04-01');
INSERT INTO csm_user VALUES (60,'employee_24','employee_24','employee_24','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3021564778','employee_24','employee_24@Test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (67,'employee_25','employee_25','employee_25','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_25','employee_25@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (68,'employee_27','employee_27','employee_27','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_27','employee_27@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (69,'technical_manager_4','technical_manager_4','technical_manager_4','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','technical_manager_4','technical_manager_4@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (70,'technical_manager_5','technical_manager_5','technical_manager_5','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','technical_manager_5','technical_manager_5@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (71,'employee_29','employee_29','employee_29','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_29','employee_29@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (72,'employee_30','employee_30','employee_30','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_30','employee_30@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (73,'employee_31','employee_31','employee_31','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_31','employee_31@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (74,'employee_33','employee_33','employee_33','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_33','employee_33@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (75,'employee_34','employee_34','employee_34','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_34','employee_34@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (76,'employee_35','employee_35','employee_35','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_35','employee_35@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (77,'employee_36','employee_36','employee_36','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_36','employee_36@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (78,'employee_40','employee_40','employee_40','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_40','employee_40@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (79,'employee_41','employee_41','employee_41','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_41','employee_41@test.com',NULL,NULL,'2005-04-03');
INSERT INTO csm_user VALUES (80,'employee_45','employee_45','employee_45','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_45','employee_45@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (81,'employee_46','employee_46','employee_46','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_46','employee_46@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (82,'md','md','md','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'234-234-2342','md','md@md.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (83,'va','va','va','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'345-987-3456','va','va@va.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (84,'timepass','timepass','timepass','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','timepass','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (85,'timepass1','timepass','timepass1','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','timepass1','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (86,'timepass1234','timepass1234','timepass1234','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','timepass1234','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (87,'employee_60','employee_60','employee_60','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_60','employee_60@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (88,'employee_61','employee_61','employee_61','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_61','employee_61@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (89,'create1','create1','create1','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create1','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (90,'create2','create2','create2','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create2','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (91,'create3','create3','create3','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create3','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (92,'create4','create4','create4','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create4','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (93,'create5','create5','create5','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create5','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (94,'create7','create7','create7','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create7','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (95,'create8','create8','create8','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create8','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (96,'employee_70','employee_70','employee_70','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_70','employee_70@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (97,'employee_71','employee_71','employee_71','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_71','employee_71@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (98,'employee_80','employee_80','employee_80','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_80','employee_80@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (99,'employee_81','employee_81','employee_81','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_81','employee_81@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (100,'employee_90','employee_90','employee_90','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_90','employee_90@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (101,'employee_91','employee_91','employee_91','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_91','employee_91@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (107,'employee_94','employee_94','employee_94','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_94','employee_94@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (108,'employee_95','employee_95','employee_95','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_95','employee_95@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (119,'employee_130','employee_130','employee_130','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_130','employee_130@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (120,'employee_131','employee_131','employee_131','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_131','employee_131@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (121,'employee_98','employee_98','employee_98','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_98','employee_98@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (122,'employee_99','employee_99','employee_99','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_99','employee_99@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (123,'employee_445','employee_445','employee_445','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'1234123444','employee_445','employee_45@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (124,'employee_446','employee_446','employee_446','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'2345234524','employee_446','employee_446@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (125,'employee_999','employee_999','employee_999','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'2342342344','employee_999','employee_999@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (126,'employee_9999','employee_9999','employee_9999','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'2342343223','employee_9999','employee_9999@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (127,'employee_800','employee_800','employee_800','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_800','employee_800@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (128,'employee_801','employee_801','employee_801','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_801','employee_801@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (129,'employee_255','employee_255','employee_255','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_255','employee_255@tset.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (130,'employee_256','employee_256','employee_256','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_256','employee_256@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (131,'employee_665','employee_665','employee_665','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'3216549877','employee_665','employee_665@tset.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (132,'employee_667','employee_667','employee_667','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_667','employee_667@test.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (133,'employee_1234','employee_1234','employee_1234','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_1234','employee_1234@tset.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (134,'employee_1235','employee_1235','employee_1235','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'3216549877','employee_1235','employee_1235@tset.com',NULL,NULL,'2005-04-04');
INSERT INTO csm_user VALUES (161,'create10','create10','create10','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create10','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (162,'create11','create11','create11','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create11','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (163,'myname','myfirst','mylast','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'123-234-1123','mypass','d',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (164,'d','d','d','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'123-465-9876','d','',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (167,'create22','create22','create22','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create22','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (168,'create23','create23','create23','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create23','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (169,'f','f','f','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'234-987-6787','f','',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (170,'create24','create24','create24','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'650-430-8195','create24','Kunal.Modi@gmail.com',NULL,NULL,'2005-04-05');
INSERT INTO csm_user VALUES (182,'t','t','t','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'234-456-8765','t','t@tmail.com',NULL,NULL,'2005-04-06');
INSERT INTO csm_user VALUES (183,'r','r','r','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'123-123-1231','r','r@rroad.com',NULL,NULL,'2005-04-06');
INSERT INTO csm_user VALUES (184,'hrperson','hrperson','hrperson','HR_DIVISION','HR_DIVISION',NULL,'123-879-6754','hrperson','',NULL,NULL,'2005-04-07');
INSERT INTO csm_user VALUES (185,'p','p','p','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'1231231231','p','p',NULL,NULL,'2005-04-07');
INSERT INTO csm_user VALUES (186,'jsmith','John','Smith','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'345-897-8976','jsmith','jsmith@abctoys.com',NULL,NULL,'2005-04-08');
INSERT INTO csm_user VALUES (187,'test','test','test','TECHNICAL_DIVISION','TECHNICAL_DIVISION',NULL,'123-123-2345','test','test@test.com',NULL,NULL,'2005-04-15');
INSERT INTO csm_user VALUES (188,'uptadmin','uptadmin','',NULL,NULL,NULL,NULL,'uptadmin',NULL,NULL,NULL,'0000-00-00');
INSERT INTO csm_user VALUES (189,'riadmin','','',NULL,NULL,NULL,NULL,'riadmin',NULL,NULL,NULL,'0000-00-00');
INSERT INTO csm_user VALUES (190,'user1','user1','user1','BUSINESS_DIVISION','BUSINESS_DIVISION',NULL,'565-456-7894','user1','email@email.com',NULL,NULL,'2005-04-15');

--
-- Table structure for table `csm_user_group`
--

CREATE TABLE csm_user_group (
  USER_GROUP_ID bigint(20) NOT NULL auto_increment,
  USER_ID bigint(20) NOT NULL default '0',
  GROUP_ID bigint(20) NOT NULL default '0',
  PRIMARY KEY  (USER_GROUP_ID),
  KEY idx_USER_ID (USER_ID),
  KEY idx_GROUP_ID (GROUP_ID),
  CONSTRAINT `FK_UG_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `csm_group` (`GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_USER_GROUP` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_user_group`
--

INSERT INTO csm_user_group VALUES (1,8,1);
INSERT INTO csm_user_group VALUES (2,4,4);
INSERT INTO csm_user_group VALUES (3,10,3);
INSERT INTO csm_user_group VALUES (4,5,2);
INSERT INTO csm_user_group VALUES (5,7,2);
INSERT INTO csm_user_group VALUES (6,9,2);
INSERT INTO csm_user_group VALUES (7,11,2);
INSERT INTO csm_user_group VALUES (8,12,2);
INSERT INTO csm_user_group VALUES (9,13,2);
INSERT INTO csm_user_group VALUES (10,14,2);
INSERT INTO csm_user_group VALUES (16,24,2);
INSERT INTO csm_user_group VALUES (17,26,2);
INSERT INTO csm_user_group VALUES (21,34,2);
INSERT INTO csm_user_group VALUES (29,43,1);
INSERT INTO csm_user_group VALUES (30,44,3);
INSERT INTO csm_user_group VALUES (31,45,4);
INSERT INTO csm_user_group VALUES (32,46,2);
INSERT INTO csm_user_group VALUES (36,52,2);
INSERT INTO csm_user_group VALUES (37,53,2);
INSERT INTO csm_user_group VALUES (40,56,2);
INSERT INTO csm_user_group VALUES (41,57,2);
INSERT INTO csm_user_group VALUES (42,58,2);
INSERT INTO csm_user_group VALUES (43,59,2);
INSERT INTO csm_user_group VALUES (44,60,2);
INSERT INTO csm_user_group VALUES (51,67,2);
INSERT INTO csm_user_group VALUES (52,68,2);
INSERT INTO csm_user_group VALUES (53,69,3);
INSERT INTO csm_user_group VALUES (54,70,3);
INSERT INTO csm_user_group VALUES (55,71,2);
INSERT INTO csm_user_group VALUES (56,72,2);
INSERT INTO csm_user_group VALUES (57,73,2);
INSERT INTO csm_user_group VALUES (58,74,2);
INSERT INTO csm_user_group VALUES (59,75,2);
INSERT INTO csm_user_group VALUES (60,76,2);
INSERT INTO csm_user_group VALUES (61,77,2);
INSERT INTO csm_user_group VALUES (62,78,2);
INSERT INTO csm_user_group VALUES (63,79,2);
INSERT INTO csm_user_group VALUES (64,80,2);
INSERT INTO csm_user_group VALUES (65,81,2);
INSERT INTO csm_user_group VALUES (66,82,2);
INSERT INTO csm_user_group VALUES (67,83,4);
INSERT INTO csm_user_group VALUES (68,84,3);
INSERT INTO csm_user_group VALUES (69,85,2);
INSERT INTO csm_user_group VALUES (70,86,2);
INSERT INTO csm_user_group VALUES (71,87,2);
INSERT INTO csm_user_group VALUES (72,88,2);
INSERT INTO csm_user_group VALUES (73,89,3);
INSERT INTO csm_user_group VALUES (74,90,3);
INSERT INTO csm_user_group VALUES (75,91,3);
INSERT INTO csm_user_group VALUES (76,92,3);
INSERT INTO csm_user_group VALUES (77,93,3);
INSERT INTO csm_user_group VALUES (78,94,3);
INSERT INTO csm_user_group VALUES (79,95,3);
INSERT INTO csm_user_group VALUES (80,96,2);
INSERT INTO csm_user_group VALUES (81,97,2);
INSERT INTO csm_user_group VALUES (82,98,2);
INSERT INTO csm_user_group VALUES (83,99,2);
INSERT INTO csm_user_group VALUES (84,100,2);
INSERT INTO csm_user_group VALUES (85,101,2);
INSERT INTO csm_user_group VALUES (86,107,2);
INSERT INTO csm_user_group VALUES (87,108,2);
INSERT INTO csm_user_group VALUES (98,119,2);
INSERT INTO csm_user_group VALUES (99,120,2);
INSERT INTO csm_user_group VALUES (100,121,2);
INSERT INTO csm_user_group VALUES (101,122,2);
INSERT INTO csm_user_group VALUES (102,123,2);
INSERT INTO csm_user_group VALUES (103,124,2);
INSERT INTO csm_user_group VALUES (104,125,2);
INSERT INTO csm_user_group VALUES (105,126,2);
INSERT INTO csm_user_group VALUES (106,127,2);
INSERT INTO csm_user_group VALUES (107,128,2);
INSERT INTO csm_user_group VALUES (108,129,2);
INSERT INTO csm_user_group VALUES (109,130,2);
INSERT INTO csm_user_group VALUES (110,131,2);
INSERT INTO csm_user_group VALUES (111,132,2);
INSERT INTO csm_user_group VALUES (112,133,2);
INSERT INTO csm_user_group VALUES (113,134,2);
INSERT INTO csm_user_group VALUES (140,161,3);
INSERT INTO csm_user_group VALUES (141,162,3);
INSERT INTO csm_user_group VALUES (142,163,2);
INSERT INTO csm_user_group VALUES (143,164,3);
INSERT INTO csm_user_group VALUES (146,167,3);
INSERT INTO csm_user_group VALUES (147,168,3);
INSERT INTO csm_user_group VALUES (148,169,3);
INSERT INTO csm_user_group VALUES (149,170,3);
INSERT INTO csm_user_group VALUES (161,182,2);
INSERT INTO csm_user_group VALUES (162,183,4);
INSERT INTO csm_user_group VALUES (163,184,2);
INSERT INTO csm_user_group VALUES (164,185,2);
INSERT INTO csm_user_group VALUES (165,186,2);
INSERT INTO csm_user_group VALUES (166,187,3);
INSERT INTO csm_user_group VALUES (167,190,4);

--
-- Table structure for table `csm_user_group_role_pg`
--

CREATE TABLE csm_user_group_role_pg (
  USER_GROUP_ROLE_PG_ID bigint(20) NOT NULL auto_increment,
  USER_ID bigint(20) default NULL,
  GROUP_ID bigint(20) default NULL,
  ROLE_ID bigint(20) NOT NULL default '0',
  PROTECTION_GROUP_ID bigint(20) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (USER_GROUP_ROLE_PG_ID),
  KEY idx_GROUP_ID (GROUP_ID),
  KEY idx_ROLE_ID (ROLE_ID),
  KEY idx_PROTECTION_GROUP_ID (PROTECTION_GROUP_ID),
  KEY idx_USER_ID (USER_ID),
  CONSTRAINT `FK_USER_GROUP_ROLE_PROTECTION_GROUP_GROUPS` FOREIGN KEY (`GROUP_ID`) REFERENCES `csm_group` (`GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_USER_GROUP_ROLE_PROTECTION_GROUP_PROTECTION_GROUP` FOREIGN KEY (`PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_USER_GROUP_ROLE_PROTECTION_GROUP_ROLE` FOREIGN KEY (`ROLE_ID`) REFERENCES `csm_role` (`ROLE_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_USER_GROUP_ROLE_PROTECTION_GROUP_USER` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_user_group_role_pg`
--

INSERT INTO csm_user_group_role_pg VALUES (14,NULL,1,2,3,'2005-03-15');
INSERT INTO csm_user_group_role_pg VALUES (15,NULL,1,2,8,'2005-03-15');
INSERT INTO csm_user_group_role_pg VALUES (19,NULL,2,3,1,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (20,NULL,3,1,1,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (21,NULL,3,1,5,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (22,NULL,3,1,7,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (23,NULL,4,1,1,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (24,NULL,4,1,5,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (25,NULL,4,1,6,'2005-03-16');
INSERT INTO csm_user_group_role_pg VALUES (26,NULL,4,1,10,'2005-03-29');
INSERT INTO csm_user_group_role_pg VALUES (27,NULL,2,3,10,'2005-03-29');
INSERT INTO csm_user_group_role_pg VALUES (28,NULL,1,2,10,'2005-03-29');
INSERT INTO csm_user_group_role_pg VALUES (30,NULL,3,4,10,'0000-00-00');
INSERT INTO csm_user_group_role_pg VALUES (31,NULL,3,1,10,'0000-00-00');

--
-- Table structure for table `csm_user_pe`
--

CREATE TABLE csm_user_pe (
  USER_PROTECTION_ELEMENT_ID bigint(20) NOT NULL auto_increment,
  PROTECTION_ELEMENT_ID bigint(20) NOT NULL default '0',
  USER_ID bigint(20) NOT NULL default '0',
  UPDATE_DATE date NOT NULL default '0000-00-00',
  PRIMARY KEY  (USER_PROTECTION_ELEMENT_ID),
  UNIQUE KEY USER_ID (USER_ID,PROTECTION_ELEMENT_ID),
  KEY idx_USER_ID (USER_ID),
  KEY idx_PROTECTION_ELEMENT_ID (PROTECTION_ELEMENT_ID),
  CONSTRAINT `FK_PE_USER` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE,
  CONSTRAINT `FK_PROTECTION_ELEMENT_USER` FOREIGN KEY (`PROTECTION_ELEMENT_ID`) REFERENCES `csm_protection_element` (`PROTECTION_ELEMENT_ID`) ON DELETE CASCADE
) TYPE=InnoDB;

--
-- Dumping data for table `csm_user_pe`
--

INSERT INTO csm_user_pe VALUES (1,223,188,'2005-05-13');
INSERT INTO csm_user_pe VALUES (2,4,4,'2005-05-13');
INSERT INTO csm_user_pe VALUES (4,9,8,'2005-03-14');
INSERT INTO csm_user_pe VALUES (5,13,7,'2005-03-14');
INSERT INTO csm_user_pe VALUES (10,15,11,'2005-03-15');
INSERT INTO csm_user_pe VALUES (12,18,12,'2005-03-15');
INSERT INTO csm_user_pe VALUES (14,21,13,'2005-03-15');
INSERT INTO csm_user_pe VALUES (15,22,14,'2005-03-16');
INSERT INTO csm_user_pe VALUES (16,28,24,'2005-03-16');
INSERT INTO csm_user_pe VALUES (17,30,26,'2005-03-16');
INSERT INTO csm_user_pe VALUES (21,38,34,'2005-03-16');
INSERT INTO csm_user_pe VALUES (27,47,43,'2005-03-17');
INSERT INTO csm_user_pe VALUES (28,48,44,'2005-03-17');
INSERT INTO csm_user_pe VALUES (29,49,45,'2005-03-17');
INSERT INTO csm_user_pe VALUES (30,51,46,'2005-03-17');
INSERT INTO csm_user_pe VALUES (34,60,52,'2005-03-22');
INSERT INTO csm_user_pe VALUES (35,61,53,'2005-03-22');
INSERT INTO csm_user_pe VALUES (38,67,56,'2005-03-28');
INSERT INTO csm_user_pe VALUES (39,69,57,'2005-03-29');
INSERT INTO csm_user_pe VALUES (40,83,58,'2005-03-30');
INSERT INTO csm_user_pe VALUES (41,86,59,'2005-04-01');
INSERT INTO csm_user_pe VALUES (42,89,60,'2005-04-03');
INSERT INTO csm_user_pe VALUES (44,98,67,'2005-04-03');
INSERT INTO csm_user_pe VALUES (45,101,70,'2005-04-03');
INSERT INTO csm_user_pe VALUES (46,104,72,'2005-04-03');
INSERT INTO csm_user_pe VALUES (47,106,74,'2005-04-03');
INSERT INTO csm_user_pe VALUES (48,108,76,'2005-04-03');
INSERT INTO csm_user_pe VALUES (49,110,78,'2005-04-03');
INSERT INTO csm_user_pe VALUES (50,112,80,'2005-04-04');
INSERT INTO csm_user_pe VALUES (51,114,82,'2005-04-04');
INSERT INTO csm_user_pe VALUES (69,152,119,'2005-04-04');
INSERT INTO csm_user_pe VALUES (70,154,121,'2005-04-04');
INSERT INTO csm_user_pe VALUES (71,157,123,'2005-04-04');
INSERT INTO csm_user_pe VALUES (72,159,125,'2005-04-04');
INSERT INTO csm_user_pe VALUES (73,161,127,'2005-04-04');
INSERT INTO csm_user_pe VALUES (74,163,129,'2005-04-04');
INSERT INTO csm_user_pe VALUES (75,165,131,'2005-04-04');
INSERT INTO csm_user_pe VALUES (76,166,132,'2005-04-04');
INSERT INTO csm_user_pe VALUES (77,167,133,'2005-04-04');
INSERT INTO csm_user_pe VALUES (78,168,134,'2005-04-04');
INSERT INTO csm_user_pe VALUES (105,195,161,'2005-04-05');
INSERT INTO csm_user_pe VALUES (106,197,163,'2005-04-05');
INSERT INTO csm_user_pe VALUES (108,201,167,'2005-04-05');
INSERT INTO csm_user_pe VALUES (109,202,168,'2005-04-05');
INSERT INTO csm_user_pe VALUES (110,204,170,'2005-04-05');
INSERT INTO csm_user_pe VALUES (122,217,182,'2005-04-06');
INSERT INTO csm_user_pe VALUES (123,218,183,'2005-04-06');
INSERT INTO csm_user_pe VALUES (124,219,184,'2005-04-07');
INSERT INTO csm_user_pe VALUES (125,220,185,'2005-04-07');
INSERT INTO csm_user_pe VALUES (126,221,186,'2005-04-08');
INSERT INTO csm_user_pe VALUES (127,222,187,'2005-04-15');
INSERT INTO csm_user_pe VALUES (128,224,189,'0000-00-00');
INSERT INTO csm_user_pe VALUES (129,225,190,'2005-04-15');

--
-- Table structure for table `employee`
--

CREATE TABLE employee (
  EMPLOYEE_ID bigint(200) NOT NULL auto_increment,
  FIRST_NAME varchar(50) NOT NULL default '',
  MIDDLE_NAME varchar(50) default NULL,
  LAST_NAME varchar(50) NOT NULL default '',
  LOGIN_NAME varchar(50) NOT NULL default '',
  PASSWORD varchar(50) NOT NULL default '',
  PHONE_NUMBER varchar(20) default NULL,
  EMAIL_ADDR varchar(50) default NULL,
  STREET_ADDR varchar(50) default NULL,
  CITY varchar(50) default NULL,
  STATE char(3) default NULL,
  ZIP varchar(10) default NULL,
  SALARY varchar(50) default NULL,
  SSN varchar(9) default NULL,
  EMPLOYEE_MGR_ID bigint(200) default NULL,
  PRIMARY KEY  (EMPLOYEE_ID),
  KEY EMPLOYEE_MGR_ID (EMPLOYEE_MGR_ID),
  CONSTRAINT `FK_EMPLOYEE_MGR_ID` FOREIGN KEY (`EMPLOYEE_MGR_ID`) REFERENCES `employee` (`EMPLOYEE_ID`)
) TYPE=InnoDB;

--
-- Dumping data for table `employee`
--

INSERT INTO employee VALUES (2,'business_manager','','business_manager','business_manager','business_manager','2025554444','employee_manager@test.com','23 Test Rd','Annapolis','MD','21401','','',NULL);
INSERT INTO employee VALUES (4,'employee_1','a','employee_1','employee_1','employee_1','4108889999','employee_1@test.com','23 Test Rdd','Annapoliss','MD','21401','','',NULL);
INSERT INTO employee VALUES (6,'hr_manager','T','hr_manager','hr_manager','hr_manager','3015698877','hr_manager@test.com','23 Test Rd','Annapolis','MD','21404','250006','123456789',NULL);
INSERT INTO employee VALUES (7,'employee_2','A','employee_2','employee_2','employee_2','4108971200','employee_2@test.com','23 Test RD','Annapolis','MD','21771','99999','123456789',NULL);
INSERT INTO employee VALUES (8,'employee_3','E','employee_3','employee_3','employee_3','4108971200','employee_3@test.com','23 Test  Drive','Annapolis','MD','21401','12341234','123456789',NULL);
INSERT INTO employee VALUES (9,'employee_4','T','employee_4','employee_4','employee_41','3015198877','employee_4@test.com','23 Test Rd','Annapoliss','MD','21771','','',NULL);
INSERT INTO employee VALUES (12,'employee_5','T','employee_5','employee_51','employee_51','5556669999','employee_5@test.com','23 Test Rd','Annapolis','MD','21401','89000','123456789',NULL);
INSERT INTO employee VALUES (13,'technical_manager','T','technical_manager','technical_manager','technical_manager','3012569988','technical_manager@test.com','23 Test Rd','Annapolis','MD','21771','44500','123456789',NULL);
INSERT INTO employee VALUES (15,'employee_6','T','employee_6','employee_6','employee_6','3206589977','employee_6@test.com','23 Test RD','Annapolis','MD','21401','999999','123456789',NULL);
INSERT INTO employee VALUES (16,'employee_7','T','employee_7','employee_71','employee_7','2025549877','employee_7@test.com','23 Test Rd','Annapolis','MD','21771','3432','234232222',NULL);
INSERT INTO employee VALUES (27,'employee_8','r','employee_8','employee_8','employee_8','3014567899','employee_8@test.com','23 Test Rdd','Annapolisss','MD','21401','88888','123456789',NULL);
INSERT INTO employee VALUES (29,'employee_9','A','employee_9','employee_9','employee_9','3018974455','employee_9@test.com','23 s Rdd','Annapolis','','21403','6666666666','123456789',NULL);
INSERT INTO employee VALUES (37,'employee_11','a','employee_11','emp11','emp11','3216549877','employee_11@test.com','23 Test Rd','Annapolis','MD','214101','','',NULL);
INSERT INTO employee VALUES (46,'hr_manager_2','a','hr_manager_2','hr_manager_2','hr_manager_2','2136549877','hr_manager_2@test.com','23 Test Rd','Annapolis','MD','21401','321654987','321654987',NULL);
INSERT INTO employee VALUES (47,'technical_manager_2','a','technical_manager_2','technical_manager_2','technical_manager_2','12323423456','technical_manager_2@test.com','23 Test Rd','Annapolis','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (48,'business_manager_2','a','business_manager_2','business_manager_2','business_manager_2','3216549877','business_manager_2@tset.com','23 Test Rd','Annapolis','MD','21401','9999','321654987',NULL);
INSERT INTO employee VALUES (49,'employee_10','A','employee_10','employee_10','employee_10','3216549877','employee_10@test.com','23 Test Rd','Annapolis','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (50,'employee_13','A','employee_13','employee_13','employee_13','3216549877','employee_13@test.com','23 Test Rd','St Peters','MD','21040','888888','321654987',NULL);
INSERT INTO employee VALUES (59,'Timessdf','','Asdfs','asdf','asdf','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (60,'eric','','copen','eric','eric','3','3','23','3','3','3','3234','33',NULL);
INSERT INTO employee VALUES (66,'employee_20','a','employee_20','employee_20','employee_20','3216549877','employee_20@test.com','23 Test Rd','Annapolis','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (67,'employee_21','A','employee_21','employee21','employee21','4108971200','employee_21@test.com','23 Test Rd','Annapolis','MD','21401','','',NULL);
INSERT INTO employee VALUES (68,'employee_22','a','employee_22','employee_221','employee_221','3216549877','employee_22@test.com','23 Test Rd','Annapolis','MD','21771','9999999','123456789',NULL);
INSERT INTO employee VALUES (69,'first1','m','last1','test1','test1','234-987-7654','test@test.com','234 test lane','test city','MD','12345','newnumber','newnumber',NULL);
INSERT INTO employee VALUES (70,'employee_24','A','employee_24','employee_24','employee_24','321654987','employee_24@Test.com','23 Test Rd','Annapolis','md','21411','99999','321654987',NULL);
INSERT INTO employee VALUES (79,'employee_25','A','employee_25','employee_25','employee_25','3216549877','employee_25@test.com','Test Rd','Annapolis','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (80,'employee_27','A','employee_27','employee_27','employee_27','3216549877','employee_27@test.com','23 Test Rd','Annapolis','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (81,'technical_manager_4','A','technical_manager_4','technical_manager_4','technical_manager_4','3216549877','technical_manager_4@test.com','Test Rd','Annapolis','Md','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (82,'technical_manager_5','A','technical_manager_5','technical_manager_5','technical_manager_5','3216549877','technical_manager_5@test.com','Test Rd','Test','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (83,'employee_29','A','employee_29','employee_29','employee_29','3216549877','employee_29@test.com','Test Rd','Annapolis','MD','21441','321654','321654987',NULL);
INSERT INTO employee VALUES (84,'employee_29','A','employee_29','employee_29','employee_29','3216549877','employee_29@test.com','23 Test Rd','Annapolis','MD','21401','321654987','321654987',NULL);
INSERT INTO employee VALUES (85,'employee_30','A','employee_30','employee_301','employee_301','3216549877','employee_30@test.com','23 Test Rd','Annapolis','MD','214015','321654987','321654987',NULL);
INSERT INTO employee VALUES (86,'employee_31','A','employee_31','employee_31','employee_31','3216549877','employee_31@test.com','23 Test Rd','Annapolis','MD','21401','654654','321654987',NULL);
INSERT INTO employee VALUES (87,'employee_33','A','employee_33','employee_33','employee_33','3216549877','employee_33@test.com','Test','Test','MD','21410','654654','321654987',NULL);
INSERT INTO employee VALUES (88,'employee_34','A','employee_34','employee_34','employee_34','3216549877','employee_34@test.com','Test','Test','MD','321654','89745','321654987',NULL);
INSERT INTO employee VALUES (89,'employee_35','A','employee_35','employee_35','employee_35','3216549877','employee_35@test.com','Test','Test','MD','321664','999999','321654',NULL);
INSERT INTO employee VALUES (90,'employee_36','a','employee_36','employee_36','employee_36','3216549877','employee_36@test.com','Test','Test','MD','321654','321654987','321654987',NULL);
INSERT INTO employee VALUES (91,'employee_40','A','employee_40','employee_40','employee_40','3216549877','employee_40@test.com','Test','Tes','MD','321654','98897','321654987',NULL);
INSERT INTO employee VALUES (92,'employee_41','a','employee_41','employee_41','employee_41','3216549877','employee_41@test.com','Test','Test','MD','231654','879787','321654987',NULL);
INSERT INTO employee VALUES (93,'employee_45','A','employee_45','employee_45','employee_45','3216549877','employee_45@test.com','Test Rd','Test','MD','21401','32132','321654987',NULL);
INSERT INTO employee VALUES (94,'employee_46','a','employee_46','employee_46','employee_46','3216549877','employee_46@test.com','Test','Rd','MD','21401','321654','321654987',NULL);
INSERT INTO employee VALUES (128,'employee_130','a','employee_130','employee_130','employee_130','3216549877','employee_130@test.com','test','test','md','32154','98000','321654987',NULL);
INSERT INTO employee VALUES (129,'employee_131','a','employee_131','employee_131','employee_131','3216549877','employee_131@test.com','test','test','md','32154','78000','321654987',NULL);
INSERT INTO employee VALUES (130,'employee_98','d','employee_98','employee_98','employee_98','3216549877','employee_98@test.com','employee_98','employee_98','md','21545','89200','321654987',NULL);
INSERT INTO employee VALUES (131,'employee_99','','employee_99','employee_99','employee_99','3216549877','employee_99@test.com','employee_99','employee_99','de','32121','3216547','321695498',NULL);
INSERT INTO employee VALUES (132,'employee_45','','employee_45','employee_45','employee_45','1234123444','employee_45@test.com','employee_45','employee_45','sdf','234123','89000','321654987',NULL);
INSERT INTO employee VALUES (133,'employee_445','','employee_445','employee_445','employee_445','1234123444','employee_45@test.com','employee_445','employee_445','sdf','234123','89000','321654987',NULL);
INSERT INTO employee VALUES (134,'employee_446','','employee_446','employee_446','employee_446','2345234524','employee_446@test.com','employee_446','employee_446','sdf','2345235','98987988','321654987',NULL);
INSERT INTO employee VALUES (135,'employee_999','','employee_999','employee_999','employee_999','2342342344','employee_999@test.com','employee_999','employee_999','sd','234234','54245','321654987',NULL);
INSERT INTO employee VALUES (136,'employee_9999','','employee_9999','employee_9999','employee_9999','2342343223','employee_9999@test.com','employee_9999','employee_9999','sd','23542345','98000','32165987',NULL);
INSERT INTO employee VALUES (137,'employee_800','','employee_800','employee_8001','employee_800','3216549877','employee_800@test.com','employee_800','employee_800','sd','321321','321321','321654987',NULL);
INSERT INTO employee VALUES (138,'employee_801','s','employee_801','employee_801','employee_801','3216549877','employee_801@test.com','employee_801','employee_801','md','3213214','98000','321654987',NULL);
INSERT INTO employee VALUES (139,'employee_255','','employee_255','employee_255','employee_255','3216549877','employee_255@tset.com','employee_255','employee_255','sd','23423','321321','3216547',NULL);
INSERT INTO employee VALUES (140,'employee_256','','employee_256','employee_256','employee_256','3216549877','employee_256@test.com','employee_256','employee_256','sd','234324','321321','3216547',NULL);
INSERT INTO employee VALUES (141,'employee_665','','employee_665','employee_665','employee_665','3216549877','employee_665@tset.com','employee_665','employee_665','sd','23233','23233','321654987',NULL);
INSERT INTO employee VALUES (142,'employee_667','','employee_667','employee_667','employee_667','3216549877','employee_667@test.com','employee_667','employee_667','sd','232342','2323','321654987',NULL);
INSERT INTO employee VALUES (143,'employee_1234','s','employee_1234','employee_1234','employee_1234','3216549877','employee_1234@tset.com','Test','TEst','MD','205555','1312','321654987',NULL);
INSERT INTO employee VALUES (144,'employee_1235','','employee_1235','employee_1235','employee_1235','3216549877','employee_1235@tset.com','employee_1235','employee_1235','sd','321321','664','321654987',NULL);
INSERT INTO employee VALUES (145,'create10','c','create10','create10','create10','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (146,'create11','c','create11','create11','create11','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (147,'myfirst','d','mylast','myname','mypass','123-234-1123','d','d','d','d','d','d','d',NULL);
INSERT INTO employee VALUES (148,'d','d','d','d','d','123-465-9876','','d','d','d','d','d','',NULL);
INSERT INTO employee VALUES (149,'create20','c','create20','create20','create20','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (150,'create22','c','create22','create22','create22','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','1000','123-456-7',NULL);
INSERT INTO employee VALUES (151,'create23','c','create23','create23','create23','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (152,'f','f','f','f','f','234-987-6787','','f','f','f','f','s','',NULL);
INSERT INTO employee VALUES (153,'create24','c','create24','create24','create24','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (154,'f','f','f','f','f','234-987-6787','','f','f','f','f','s','',NULL);
INSERT INTO employee VALUES (155,'create30','c','create30','create30','create30','12334567890','abc@xyz.com','123 Second St','Rockville','MD','20852','100000','123-456-7',NULL);
INSERT INTO employee VALUES (156,'t','t','t','t','t','234-456-8765','t@tmail.com','tt tom road','city','tr','12341','32424','1231123',NULL);
INSERT INTO employee VALUES (157,'r','r','r','r','r','123-123-1231','r@rroad.com','rr road','r','rr','r','12312','12123',NULL);
INSERT INTO employee VALUES (158,'hrperson','d','hrperson','hrperson','hrperson','123-879-6754','','hrperson','hrperson','234','23423','213','',NULL);
INSERT INTO employee VALUES (159,'p','p','p','p','p','1231231231','p','p','p','p','p','p','p',NULL);
INSERT INTO employee VALUES (160,'John','E','Smith','jsmith','password','345-897-8976','jsmith@abctoys.com','1231 Rocy Run Drive','Annapolis','MD','23324','145,000','123456234',NULL);
INSERT INTO employee VALUES (161,'test','t','test','test','test','123-123-2345','test@test.com','test','test','tes','test','234234','1231223',NULL);
INSERT INTO employee VALUES (162,'user1','u','user1','user1','user1','565-456-7894','email@email.com','234 street','city','md','54657','123','3123',NULL);

--
-- Table structure for table `employee_project`
--

CREATE TABLE employee_project (
  EMPLOYEE_PROJECT_ID bigint(200) NOT NULL auto_increment,
  EMPLOYEE_ID bigint(200) NOT NULL default '0',
  PROJECT_ID bigint(200) NOT NULL default '0',
  PRIMARY KEY  (EMPLOYEE_PROJECT_ID)
) TYPE=InnoDB;

--
-- Dumping data for table `employee_project`
--

INSERT INTO employee_project VALUES (48,48,3);
INSERT INTO employee_project VALUES (52,50,15);
INSERT INTO employee_project VALUES (53,50,4);
INSERT INTO employee_project VALUES (76,27,3);
INSERT INTO employee_project VALUES (77,27,2);
INSERT INTO employee_project VALUES (78,27,1);
INSERT INTO employee_project VALUES (79,27,18);
INSERT INTO employee_project VALUES (84,70,5);
INSERT INTO employee_project VALUES (85,70,24);
INSERT INTO employee_project VALUES (94,85,17);
INSERT INTO employee_project VALUES (95,85,27);
INSERT INTO employee_project VALUES (105,29,5);
INSERT INTO employee_project VALUES (106,29,3);
INSERT INTO employee_project VALUES (107,128,31);
INSERT INTO employee_project VALUES (114,59,5);
INSERT INTO employee_project VALUES (115,59,2);
INSERT INTO employee_project VALUES (116,59,16);
INSERT INTO employee_project VALUES (143,160,19);
INSERT INTO employee_project VALUES (144,160,4);
INSERT INTO employee_project VALUES (145,160,5);
INSERT INTO employee_project VALUES (146,160,2);
INSERT INTO employee_project VALUES (147,160,1);
INSERT INTO employee_project VALUES (151,162,15);

--
-- Table structure for table `project`
--

CREATE TABLE project (
  PROJECT_ID bigint(200) NOT NULL auto_increment,
  NAME varchar(50) NOT NULL default '',
  DESCRIPTION varchar(200) default NULL,
  PRIMARY KEY  (PROJECT_ID)
) TYPE=InnoDB;

--
-- Dumping data for table `project`
--

INSERT INTO project VALUES (1,'my new project','desc.');
INSERT INTO project VALUES (2,'my new project','desc.');
INSERT INTO project VALUES (3,'testproject1','hello description');
INSERT INTO project VALUES (4,'test project','hello');
INSERT INTO project VALUES (5,'my project here','this is my project');
INSERT INTO project VALUES (14,'a','a');
INSERT INTO project VALUES (15,'a','a');
INSERT INTO project VALUES (16,'the','project');
INSERT INTO project VALUES (17,'the','project');
INSERT INTO project VALUES (18,'the','project2');
INSERT INTO project VALUES (19,'newp','newp desc.');
INSERT INTO project VALUES (20,'TestProject','test Project One');
INSERT INTO project VALUES (21,'testproject','tp1');
INSERT INTO project VALUES (22,'testproject2','tp12');
INSERT INTO project VALUES (23,'API','this is an important API.');
INSERT INTO project VALUES (24,'TestBrianProject2','TEst');
INSERT INTO project VALUES (25,'testec1','s');
INSERT INTO project VALUES (26,'testec2','s');
INSERT INTO project VALUES (27,'new project','hello');
INSERT INTO project VALUES (28,'tp1','asdfas');
INSERT INTO project VALUES (29,'newp','newp');
INSERT INTO project VALUES (30,'newp','newp');
INSERT INTO project VALUES (31,'hello','hello\r\n');
INSERT INTO project VALUES (32,'hello','hello\r\n');
INSERT INTO project VALUES (33,'hello','hello\r\n');
INSERT INTO project VALUES (34,'RI','Create a simple RI that shows how the UPT works.');
INSERT INTO project VALUES (35,'project 25','desc.\r\n');
INSERT INTO project VALUES (36,'user1test','test');


/*
SQLyog Trial v8.81 
MySQL - 5.1.35-community : Database - catissue_ils
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`catissue_ils` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `catissue_ils`;

/*Table structure for table `association` */

DROP TABLE IF EXISTS `association`;

CREATE TABLE `association` (
  `ASSOCIATION_ID` bigint(20) NOT NULL,
  `ASSOCIATION_TYPE` int(8) NOT NULL,
  PRIMARY KEY (`ASSOCIATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `association` */

insert  into `association`(`ASSOCIATION_ID`,`ASSOCIATION_TYPE`) values (2,2),(3,2),(5,2),(7,2),(9,2),(10,2),(11,2),(12,2),(13,2),(15,2),(19,2),(20,2),(24,2),(25,2),(26,2),(35,2),(40,2),(46,2),(48,2),(51,2),(53,2),(54,2),(55,2),(58,2),(67,2),(69,2),(70,2),(71,2),(73,2),(75,2),(77,2),(78,2),(83,2),(86,2),(89,2),(93,2),(96,2),(98,2),(100,2),(104,2),(111,2),(112,2),(114,2),(118,2),(124,2),(125,2),(126,2),(127,2),(131,2),(132,2),(133,2),(134,2),(139,2),(140,2),(141,2),(142,2),(143,2),(144,2),(145,2),(147,2),(149,2),(154,2),(157,2),(167,2),(173,2),(174,2),(179,2),(180,2),(183,2),(186,2),(187,2),(189,2),(190,2),(191,2),(192,2),(195,2),(196,2),(200,2),(201,2),(202,2),(205,2),(207,2),(208,2),(209,2),(215,2),(218,2),(221,2),(222,2),(227,2),(228,2),(234,2),(238,2),(241,2),(242,2),(243,2),(244,2),(245,2),(247,2),(250,2),(252,2),(255,2),(256,2),(257,2),(260,2),(261,2),(262,2),(263,2),(264,2),(270,2),(271,2),(272,2),(273,2),(274,2),(275,2),(276,2),(281,2),(282,2),(284,2),(288,2),(289,2),(292,2),(293,2),(295,2),(296,2),(297,2),(299,2),(304,2),(305,2),(306,2),(311,2),(312,2),(313,2),(317,2),(319,2),(320,2),(323,2),(325,2),(328,2),(329,2),(330,2),(332,2),(338,2),(342,2),(344,2),(346,2),(349,2),(351,2),(357,2),(359,2),(364,2),(368,2),(371,2),(372,2),(376,2),(380,2),(381,2),(387,2),(391,2),(393,2),(395,2),(396,2),(397,2),(400,2),(401,2),(402,2),(403,2),(404,2),(410,2),(418,2),(420,2),(426,2),(428,2),(430,2),(432,2),(437,2),(438,2),(441,2),(445,2),(449,2),(450,2),(453,2),(456,2),(457,2),(466,2),(467,2),(473,2),(481,2),(483,2),(487,2),(489,2),(494,2),(495,2),(498,2),(499,2),(500,2),(501,2),(502,2),(503,2),(506,2),(507,2),(508,2),(509,2),(510,2),(512,2),(517,2),(520,2),(521,2),(522,2),(523,2),(524,2),(528,2),(531,2),(533,2),(534,2),(536,2),(538,2),(543,2),(544,2),(548,2),(550,2),(555,2),(562,2),(564,2),(565,2),(566,2),(567,2),(568,2),(570,2),(571,2),(572,2),(573,2),(574,2),(575,2),(576,2),(577,2),(580,2),(584,2),(585,2),(586,2),(587,2),(589,2),(590,2),(591,2),(595,2),(596,2),(597,2),(600,2),(603,2),(606,2),(611,2),(612,2),(613,2),(616,2),(619,2),(621,2),(622,2),(623,2),(626,2),(629,2),(632,2),(634,2),(635,2),(636,2),(638,2),(644,2),(645,2),(646,2),(647,2),(648,2),(649,2),(650,2),(653,2),(655,2),(656,2),(657,2),(660,2),(661,2),(662,2),(664,2),(665,2),(666,2),(667,2),(668,2),(669,2),(670,2),(671,2),(672,2),(673,2),(674,2),(675,2),(676,2),(677,2),(678,2),(679,2),(680,2),(681,2),(682,2),(683,2),(684,2),(685,2),(686,2),(687,2),(688,2),(689,2),(690,2),(691,2),(692,2),(693,2),(694,2),(695,2),(696,2),(697,2),(698,2),(699,2),(700,2),(701,2),(702,2),(703,2),(704,2),(705,2),(706,2),(707,2),(708,2),(709,2),(710,2),(711,2),(712,2),(713,2),(714,2),(715,2),(716,2),(717,2),(718,2),(719,2),(720,2),(721,2),(722,2),(723,2),(724,2),(725,2),(726,2),(727,2),(728,2),(729,2),(730,2),(731,2),(732,2),(733,2),(734,2),(735,2),(736,2),(737,2),(738,2),(739,2),(740,2),(741,2),(742,2),(743,2),(744,2),(745,2),(746,2),(747,2),(748,2),(749,2),(750,2),(751,2),(752,2),(753,2),(754,2),(755,2),(756,2),(757,2),(758,2),(759,2),(760,2),(761,2),(762,2),(763,2),(764,2),(765,2),(766,2),(767,2),(768,2),(769,2),(770,2),(771,2),(772,2),(773,2),(774,2),(775,2),(776,2),(777,2),(778,2),(779,2),(780,2),(781,2),(782,2),(783,2),(784,2),(785,2),(786,2),(787,2),(788,2),(789,2),(790,2),(791,2),(792,2),(793,2),(794,2),(795,2),(796,2),(797,2),(798,2),(799,2),(800,2),(801,2),(802,2),(803,2),(804,2),(805,2),(806,2),(807,2),(808,2),(809,2),(810,2),(811,2),(812,2),(813,2),(814,2),(815,2),(816,2),(817,2),(818,2),(819,2),(820,2),(821,2),(822,2),(823,2),(824,2),(825,2),(826,2),(827,2),(828,2),(829,2),(830,2),(831,2),(832,2),(833,2),(834,2),(835,2),(836,2),(837,2),(838,2),(839,2),(840,2),(841,2),(842,2),(843,2),(844,2),(845,2),(846,2),(847,2),(848,2),(849,2),(850,2),(851,2),(852,2);

/*Table structure for table `categorial_attribute` */

DROP TABLE IF EXISTS `categorial_attribute`;

CREATE TABLE `categorial_attribute` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CATEGORIAL_CLASS_ID` bigint(20) DEFAULT NULL,
  `DE_CATEGORY_ATTRIBUTE_ID` bigint(20) DEFAULT NULL,
  `DE_SOURCE_CLASS_ATTRIBUTE_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK31F77B56E8CBD948` (`CATEGORIAL_CLASS_ID`),
  CONSTRAINT `FK31F77B56E8CBD948` FOREIGN KEY (`CATEGORIAL_CLASS_ID`) REFERENCES `categorial_class` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `categorial_attribute` */

/*Table structure for table `categorial_class` */

DROP TABLE IF EXISTS `categorial_class`;

CREATE TABLE `categorial_class` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `DE_ENTITY_ID` bigint(20) DEFAULT NULL,
  `PATH_FROM_PARENT_ID` bigint(20) DEFAULT NULL,
  `PARENT_CATEGORIAL_CLASS_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK9651EF32D8D56A33` (`PARENT_CATEGORIAL_CLASS_ID`),
  CONSTRAINT `FK9651EF32D8D56A33` FOREIGN KEY (`PARENT_CATEGORIAL_CLASS_ID`) REFERENCES `categorial_class` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `categorial_class` */

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `DE_ENTITY_ID` bigint(20) DEFAULT NULL,
  `PARENT_CATEGORY_ID` bigint(20) DEFAULT NULL,
  `ROOT_CATEGORIAL_CLASS_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ROOT_CATEGORIAL_CLASS_ID` (`ROOT_CATEGORIAL_CLASS_ID`),
  KEY `FK31A8ACFE2D0F63E7` (`PARENT_CATEGORY_ID`),
  KEY `FK31A8ACFE211D9A6B` (`ROOT_CATEGORIAL_CLASS_ID`),
  CONSTRAINT `FK31A8ACFE211D9A6B` FOREIGN KEY (`ROOT_CATEGORIAL_CLASS_ID`) REFERENCES `categorial_class` (`ID`),
  CONSTRAINT `FK31A8ACFE2D0F63E7` FOREIGN KEY (`PARENT_CATEGORY_ID`) REFERENCES `category` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `category` */

/*Table structure for table `catissue_abs_speci_coll_group` */

DROP TABLE IF EXISTS `catissue_abs_speci_coll_group`;

CREATE TABLE `catissue_abs_speci_coll_group` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLINICAL_DIAGNOSIS` varchar(150) DEFAULT NULL,
  `CLINICAL_STATUS` varchar(50) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `SITE_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKDEBAF167A7F77D13` (`SITE_ID`),
  KEY `INDX_SP_COL_GR_CLIN_STATUS` (`CLINICAL_STATUS`),
  CONSTRAINT `FKDEBAF167A7F77D13` FOREIGN KEY (`SITE_ID`) REFERENCES `catissue_site` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_abs_speci_coll_group` */

insert  into `catissue_abs_speci_coll_group`(`IDENTIFIER`,`CLINICAL_DIAGNOSIS`,`CLINICAL_STATUS`,`ACTIVITY_STATUS`,`SITE_ID`) values (1,'Not Specified','Not Specified','Active',NULL),(2,'Not Specified','Not Specified','Active',1),(3,'Not Specified','Not Specified','Active',NULL),(4,'Not Specified','Not Specified','Active',1),(5,'Not Specified','Not Specified','Active',NULL),(6,'Not Specified','Not Specified','Active',1);

/*Table structure for table `catissue_abstract_position` */

DROP TABLE IF EXISTS `catissue_abstract_position`;

CREATE TABLE `catissue_abstract_position` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `POSITION_DIMENSION_ONE` int(11) DEFAULT NULL,
  `POSITION_DIMENSION_TWO` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `catissue_abstract_position` */

/*Table structure for table `catissue_abstract_specimen` */

DROP TABLE IF EXISTS `catissue_abstract_specimen`;

CREATE TABLE `catissue_abstract_specimen` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `SPECIMEN_CLASS` varchar(50) NOT NULL DEFAULT '',
  `SPECIMEN_TYPE` varchar(50) DEFAULT NULL,
  `LINEAGE` varchar(50) DEFAULT NULL,
  `PATHOLOGICAL_STATUS` varchar(50) DEFAULT NULL,
  `PARENT_SPECIMEN_ID` bigint(20) DEFAULT NULL,
  `SPECIMEN_CHARACTERISTICS_ID` bigint(20) DEFAULT NULL,
  `INITIAL_QUANTITY` double DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK1674810456906F39` (`SPECIMEN_CHARACTERISTICS_ID`),
  KEY `INDX_CATISSUE_SPECIMEN_CLASS` (`SPECIMEN_CLASS`),
  KEY `INDX_CATISSUE_SPECIMEN_TYPE` (`SPECIMEN_TYPE`),
  KEY `INDX_CATISSUE_SPECIMEN_PATH` (`PATHOLOGICAL_STATUS`),
  KEY `INDX_CATISSUE_SPECIMEN_QTY` (`INITIAL_QUANTITY`),
  CONSTRAINT `FK1674810456906F39` FOREIGN KEY (`SPECIMEN_CHARACTERISTICS_ID`) REFERENCES `catissue_specimen_char` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_abstract_specimen` */

insert  into `catissue_abstract_specimen`(`IDENTIFIER`,`SPECIMEN_CLASS`,`SPECIMEN_TYPE`,`LINEAGE`,`PATHOLOGICAL_STATUS`,`PARENT_SPECIMEN_ID`,`SPECIMEN_CHARACTERISTICS_ID`,`INITIAL_QUANTITY`) values (1,'Tissue','Fresh Tissue','New','Not Specified',NULL,1,10),(2,'Tissue','Fresh Tissue','New','Not Specified',NULL,2,10),(3,'Tissue','Fixed Tissue','New','Not Specified',NULL,3,10),(4,'Tissue','Fixed Tissue','New','Not Specified',NULL,4,10),(5,'Cell','Fixed Cell','New','Not Specified',NULL,5,10),(6,'Cell','Fixed Cell','New','Not Specified',NULL,6,10);

/*Table structure for table `catissue_address` */

DROP TABLE IF EXISTS `catissue_address`;

CREATE TABLE `catissue_address` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `STREET` varchar(255) DEFAULT NULL,
  `CITY` varchar(50) DEFAULT NULL,
  `STATE` varchar(50) DEFAULT NULL,
  `COUNTRY` varchar(50) DEFAULT NULL,
  `ZIPCODE` varchar(30) DEFAULT NULL,
  `PHONE_NUMBER` varchar(50) DEFAULT NULL,
  `FAX_NUMBER` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_address` */

insert  into `catissue_address`(`IDENTIFIER`,`STREET`,`CITY`,`STATE`,`COUNTRY`,`ZIPCODE`,`PHONE_NUMBER`,`FAX_NUMBER`) values (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `catissue_audit_event` */

DROP TABLE IF EXISTS `catissue_audit_event`;

CREATE TABLE `catissue_audit_event` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `IP_ADDRESS` varchar(20) DEFAULT NULL,
  `EVENT_TIMESTAMP` datetime DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `COMMENTS` text,
  `EVENT_TYPE` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKACAF697A2206F20F` (`USER_ID`),
  CONSTRAINT `FKACAF697A2206F20F` FOREIGN KEY (`USER_ID`) REFERENCES `catissue_user` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_audit_event` */

/*Table structure for table `catissue_biohazard` */

DROP TABLE IF EXISTS `catissue_biohazard`;

CREATE TABLE `catissue_biohazard` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  `COMMENTS` text,
  `TYPE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `INDX_CATISSUE_BIOHAZARD_TYPE` (`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_biohazard` */

/*Table structure for table `catissue_bulk_operation` */

DROP TABLE IF EXISTS `catissue_bulk_operation`;

CREATE TABLE `catissue_bulk_operation` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `OPERATION` varchar(100) NOT NULL,
  `CSV_TEMPLATE` varchar(5000) NOT NULL,
  `XML_TEMPALTE` varchar(15000) NOT NULL,
  `DROPDOWN_NAME` varchar(100) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `OPERATION` (`OPERATION`),
  UNIQUE KEY `DROPDOWN_NAME` (`DROPDOWN_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_bulk_operation` */

/*Table structure for table `catissue_cancer_research_group` */

DROP TABLE IF EXISTS `catissue_cancer_research_group`;

CREATE TABLE `catissue_cancer_research_group` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_cancer_research_group` */

insert  into `catissue_cancer_research_group`(`IDENTIFIER`,`NAME`) values (1,'c');

/*Table structure for table `catissue_capacity` */

DROP TABLE IF EXISTS `catissue_capacity`;

CREATE TABLE `catissue_capacity` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `ONE_DIMENSION_CAPACITY` int(11) DEFAULT NULL,
  `TWO_DIMENSION_CAPACITY` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_capacity` */

insert  into `catissue_capacity`(`IDENTIFIER`,`ONE_DIMENSION_CAPACITY`,`TWO_DIMENSION_CAPACITY`) values (1,100,1);

/*Table structure for table `catissue_cde` */

DROP TABLE IF EXISTS `catissue_cde`;

CREATE TABLE `catissue_cde` (
  `PUBLIC_ID` varchar(30) NOT NULL,
  `LONG_NAME` varchar(200) DEFAULT NULL,
  `DEFINITION` text,
  `VERSION` varchar(50) DEFAULT NULL,
  `LAST_UPDATED` date DEFAULT NULL,
  PRIMARY KEY (`PUBLIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_cde` */

insert  into `catissue_cde`(`PUBLIC_ID`,`LONG_NAME`,`DEFINITION`,`VERSION`,`LAST_UPDATED`) values ('2003988','Clinical Status','Clinical status of the participant.','1.0',NULL),('2003989','Gender','Gender of the participant.','1.0',NULL),('2003990','Genotype','Genotype of the participant.','1.0',NULL),('2003991','Specimen','Specimen Class','1.0',NULL),('2003992','Tissue Side','Tissue Side','1.0',NULL),('2003993','Pathological Status','Pathological Status','1.0',NULL),('2003994','Received Quality','Received Quality','1.0',NULL),('2003995','Fixation Type','Fixation Type','1.0',NULL),('2003996','Collection Procedure','Collection Procedure','1.0',NULL),('2003997','Container','Container','1.0',NULL),('2003998','Method','Method','1.0',NULL),('2003999','Embedding Medium','Embedding Medium','1.0',NULL),('2004000','Biohazard','Biohazard','1.0',NULL),('2004001','VitalStatus','Vital status of the participant.','1.0',NULL),('2004100','Countries','List of Countries.','1.0',NULL),('2004200','States','List of States.','1.0',NULL),('4284','Request Status','Statuses for the ordered requests','1.0',NULL),('4285','Requested Items Status','Statuses for the individual elements in the ordered request','1.0',NULL),('Clinical_Diagnosis_PID','Clinical Diagnosis','Clinical Diagnosis','1.0',NULL),('Ethnicity_PID','Ethnicity','Ethnicity','1.0',NULL),('Hist_Quality','Histological Quality','Histological Quality','1.0',NULL),('Race_PID','Race','Race','1.0',NULL),('Site_Type_PID','Site Type','Site Type','1.0',NULL),('Specimen_Type_PID','Specimen Type','Specimen Type','1.0',NULL),('Tissue_Site_PID','Tissue Site','Tissue Site','1.0',NULL);

/*Table structure for table `catissue_coll_prot_event` */

DROP TABLE IF EXISTS `catissue_coll_prot_event`;

CREATE TABLE `catissue_coll_prot_event` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLINICAL_STATUS` varchar(50) DEFAULT NULL,
  `COLLECTION_POINT_LABEL` varchar(255) DEFAULT NULL,
  `STUDY_CALENDAR_EVENT_POINT` double DEFAULT NULL,
  `COLLECTION_PROTOCOL_ID` bigint(20) DEFAULT NULL,
  `LABELFORMAT` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `COLLECTION_PROTOCOL_ID` (`COLLECTION_PROTOCOL_ID`,`COLLECTION_POINT_LABEL`),
  KEY `FK7AE7715948304401` (`COLLECTION_PROTOCOL_ID`),
  KEY `INDX_COLPROTO_EVNT_CAL` (`STUDY_CALENDAR_EVENT_POINT`),
  CONSTRAINT `FK7AE7715948304401` FOREIGN KEY (`COLLECTION_PROTOCOL_ID`) REFERENCES `catissue_collection_protocol` (`IDENTIFIER`),
  CONSTRAINT `FK_PARENT_COLL_PROT_EVENT` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_abs_speci_coll_group` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_coll_prot_event` */

insert  into `catissue_coll_prot_event`(`IDENTIFIER`,`CLINICAL_STATUS`,`COLLECTION_POINT_LABEL`,`STUDY_CALENDAR_EVENT_POINT`,`COLLECTION_PROTOCOL_ID`,`LABELFORMAT`) values (1,NULL,'cpl1',NULL,1,NULL),(3,NULL,'cpl2',NULL,1,NULL),(5,NULL,'cpl3',NULL,2,NULL);

/*Table structure for table `catissue_coll_prot_reg` */

DROP TABLE IF EXISTS `catissue_coll_prot_reg`;

CREATE TABLE `catissue_coll_prot_reg` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `PROTOCOL_PARTICIPANT_ID` varchar(255) DEFAULT NULL,
  `REGISTRATION_DATE` date DEFAULT NULL,
  `PARTICIPANT_ID` bigint(20) DEFAULT NULL,
  `COLLECTION_PROTOCOL_ID` bigint(20) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `CONSENT_SIGN_DATE` datetime DEFAULT NULL,
  `CONSENT_DOC_URL` text,
  `CONSENT_WITNESS` bigint(20) DEFAULT NULL,
  `BARCODE` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `DATE_OFFSET` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `BARCODE` (`BARCODE`),
  KEY `FK5EB25F1387E5ADC7` (`PARTICIPANT_ID`),
  KEY `FK5EB25F13A0FF79D4` (`CONSENT_WITNESS`),
  KEY `FK5EB25F1348304401` (`COLLECTION_PROTOCOL_ID`),
  KEY `INDX_COLL_PROT_REGID` (`PROTOCOL_PARTICIPANT_ID`),
  KEY `INDX_COLL_PROT_REG_DATE` (`REGISTRATION_DATE`),
  CONSTRAINT `FK5EB25F1348304401` FOREIGN KEY (`COLLECTION_PROTOCOL_ID`) REFERENCES `catissue_collection_protocol` (`IDENTIFIER`),
  CONSTRAINT `FK5EB25F1387E5ADC7` FOREIGN KEY (`PARTICIPANT_ID`) REFERENCES `catissue_participant` (`IDENTIFIER`),
  CONSTRAINT `FK5EB25F13A0FF79D4` FOREIGN KEY (`CONSENT_WITNESS`) REFERENCES `catissue_user` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_coll_prot_reg` */

insert  into `catissue_coll_prot_reg`(`IDENTIFIER`,`PROTOCOL_PARTICIPANT_ID`,`REGISTRATION_DATE`,`PARTICIPANT_ID`,`COLLECTION_PROTOCOL_ID`,`ACTIVITY_STATUS`,`CONSENT_SIGN_DATE`,`CONSENT_DOC_URL`,`CONSENT_WITNESS`,`BARCODE`,`DATE_OFFSET`) values (1,'1_1','2010-11-10',1,1,'Active',NULL,NULL,NULL,NULL,NULL),(2,'1_2','2010-11-10',2,1,'Active',NULL,NULL,NULL,NULL,NULL),(3,'2_1','2010-11-10',1,2,'Active',NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `catissue_collection_protocol` */

DROP TABLE IF EXISTS `catissue_collection_protocol`;

CREATE TABLE `catissue_collection_protocol` (
  `IDENTIFIER` bigint(20) NOT NULL,
  `UNSIGNED_CONSENT_DOC_URL` text,
  `ALIQUOT_IN_SAME_CONTAINER` bit(1) DEFAULT NULL,
  `CONSENTS_WAIVED` bit(1) DEFAULT NULL,
  `CP_TYPE` varchar(50) DEFAULT NULL,
  `PARENT_CP_ID` bigint(20) DEFAULT NULL,
  `SEQUENCE_NUMBER` int(11) DEFAULT NULL,
  `STUDY_CALENDAR_EVENT_POINT` double DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK32DC439DBC7298A9` (`IDENTIFIER`),
  KEY `FK32DC439DBC7298B9` (`PARENT_CP_ID`),
  CONSTRAINT `FK32DC439DBC7298A9` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_specimen_protocol` (`IDENTIFIER`),
  CONSTRAINT `FK32DC439DBC7298B9` FOREIGN KEY (`PARENT_CP_ID`) REFERENCES `catissue_collection_protocol` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_collection_protocol` */

insert  into `catissue_collection_protocol`(`IDENTIFIER`,`UNSIGNED_CONSENT_DOC_URL`,`ALIQUOT_IN_SAME_CONTAINER`,`CONSENTS_WAIVED`,`CP_TYPE`,`PARENT_CP_ID`,`SEQUENCE_NUMBER`,`STUDY_CALENDAR_EVENT_POINT`) values (1,NULL,NULL,NULL,'CP_1',NULL,NULL,NULL),(2,NULL,NULL,NULL,'CP_2',NULL,NULL,NULL);

/*Table structure for table `catissue_concept_classificatn` */

DROP TABLE IF EXISTS `catissue_concept_classificatn`;

CREATE TABLE `catissue_concept_classificatn` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` text,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_concept_classificatn` */

/*Table structure for table `catissue_container` */

DROP TABLE IF EXISTS `catissue_container`;

CREATE TABLE `catissue_container` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `BARCODE` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `CAPACITY_ID` bigint(20) DEFAULT NULL,
  `COMMENTS` text,
  `CONT_FULL` bit(1) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `BARCODE` (`BARCODE`),
  KEY `FK49B8DE5DAC76C0` (`CAPACITY_ID`),
  CONSTRAINT `FK49B8DE5DAC76C0` FOREIGN KEY (`CAPACITY_ID`) REFERENCES `catissue_capacity` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_container` */

/*Table structure for table `catissue_container_position` */

DROP TABLE IF EXISTS `catissue_container_position`;

CREATE TABLE `catissue_container_position` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `PARENT_CONTAINER_ID` bigint(20) DEFAULT NULL,
  `CONTAINER_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK_CONTAINER_POSITION` (`IDENTIFIER`),
  KEY `FK_CONTAINER` (`CONTAINER_ID`),
  KEY `FK_OCCUPIED_CONTAINER` (`PARENT_CONTAINER_ID`),
  CONSTRAINT `FK_CONTAINER` FOREIGN KEY (`CONTAINER_ID`) REFERENCES `catissue_container` (`IDENTIFIER`),
  CONSTRAINT `FK_CONTAINER_POSITION` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_abstract_position` (`IDENTIFIER`),
  CONSTRAINT `FK_OCCUPIED_CONTAINER` FOREIGN KEY (`PARENT_CONTAINER_ID`) REFERENCES `catissue_container` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `catissue_container_position` */

/*Table structure for table `catissue_container_type` */

DROP TABLE IF EXISTS `catissue_container_type`;

CREATE TABLE `catissue_container_type` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CAPACITY_ID` bigint(20) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `ONE_DIMENSION_LABEL` varchar(255) DEFAULT NULL,
  `TWO_DIMENSION_LABEL` varchar(255) DEFAULT NULL,
  `COMMENTS` text,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `FKCBBC9954DAC76C0` (`CAPACITY_ID`),
  CONSTRAINT `FKCBBC9954DAC76C0` FOREIGN KEY (`CAPACITY_ID`) REFERENCES `catissue_capacity` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_container_type` */

insert  into `catissue_container_type`(`IDENTIFIER`,`CAPACITY_ID`,`NAME`,`ONE_DIMENSION_LABEL`,`TWO_DIMENSION_LABEL`,`COMMENTS`,`ACTIVITY_STATUS`) values (1,NULL,'All',NULL,NULL,NULL,'Disabled'),(2,NULL,'Any',NULL,NULL,NULL,'Disabled'),(3,1,'Shipment Container','X','Y',NULL,'Active');

/*Table structure for table `catissue_cp_req_specimen` */

DROP TABLE IF EXISTS `catissue_cp_req_specimen`;

CREATE TABLE `catissue_cp_req_specimen` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `STORAGE_TYPE` varchar(255) NOT NULL DEFAULT '',
  `COLLECTION_PROTOCOL_EVENT_ID` bigint(20) DEFAULT NULL,
  `LABELFORMAT` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK111110456906F39` (`COLLECTION_PROTOCOL_EVENT_ID`),
  CONSTRAINT `FK111110456906F39` FOREIGN KEY (`COLLECTION_PROTOCOL_EVENT_ID`) REFERENCES `catissue_coll_prot_event` (`IDENTIFIER`),
  CONSTRAINT `FK_PARENT_CP_REQ_SPECIMEN` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_abstract_specimen` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_cp_req_specimen` */

insert  into `catissue_cp_req_specimen`(`IDENTIFIER`,`STORAGE_TYPE`,`COLLECTION_PROTOCOL_EVENT_ID`,`LABELFORMAT`) values (1,'Virtual',1,NULL),(3,'Virtual',3,NULL),(5,'Virtual',5,NULL);

/*Table structure for table `catissue_cp_studyformcontext` */

DROP TABLE IF EXISTS `catissue_cp_studyformcontext`;

CREATE TABLE `catissue_cp_studyformcontext` (
  `STUDY_FORM_CONTEXT_ID` bigint(20) NOT NULL,
  `COLLECTION_PROTOCOL_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`STUDY_FORM_CONTEXT_ID`,`COLLECTION_PROTOCOL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_cp_studyformcontext` */

/*Table structure for table `catissue_department` */

DROP TABLE IF EXISTS `catissue_department`;

CREATE TABLE `catissue_department` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_department` */

insert  into `catissue_department`(`IDENTIFIER`,`NAME`) values (1,'d');

/*Table structure for table `catissue_institution` */

DROP TABLE IF EXISTS `catissue_institution`;

CREATE TABLE `catissue_institution` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_institution` */

insert  into `catissue_institution`(`IDENTIFIER`,`NAME`) values (1,'i'),(2,'i1'),(3,'i2');

/*Table structure for table `catissue_interface_column_data` */

DROP TABLE IF EXISTS `catissue_interface_column_data`;

CREATE TABLE `catissue_interface_column_data` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `TABLE_ID` bigint(20) NOT NULL,
  `COLUMN_NAME` varchar(50) DEFAULT NULL,
  `ATTRIBUTE_TYPE` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_interface_column_data` */

insert  into `catissue_interface_column_data`(`IDENTIFIER`,`TABLE_ID`,`COLUMN_NAME`,`ATTRIBUTE_TYPE`) values (1,4,'IDENTIFIER','bigint'),(2,4,'STREET','varchar'),(3,4,'CITY','varchar'),(4,4,'STATE','varchar'),(5,4,'COUNTRY','varchar'),(6,4,'ZIPCODE','varchar'),(7,4,'PHONE_NUMBER','varchar'),(8,4,'FAX_NUMBER','varchar'),(9,39,'IDENTIFIER','bigint'),(10,39,'IP_ADDRESS','varchar'),(11,39,'EVENT_TIMESTAMP','timestamp'),(12,39,'USER_ID','bigint'),(13,39,'COMMENTS','text'),(14,40,'IDENTIFIER','bigint'),(15,40,'ELEMENT_NAME','varchar'),(16,40,'PREVIOUS_VALUE','varchar'),(17,40,'CURRENT_VALUE','varchar'),(18,40,'AUDIT_EVENT_LOG_ID','bigint'),(19,41,'IDENTIFIER','bigint'),(20,41,'OBJECT_IDENTIFIER','bigint'),(21,41,'OBJECT_NAME','varchar'),(22,41,'EVENT_TYPE','varchar'),(23,41,'AUDIT_EVENT_ID','bigint'),(24,8,'IDENTIFIER','bigint'),(25,8,'NAME','varchar'),(26,8,'COMMENTS','text'),(27,8,'TYPE','varchar'),(28,7,'IDENTIFIER','bigint'),(29,7,'NAME','varchar'),(30,42,'PUBLIC_ID','varchar'),(31,42,'LONG_NAME','varchar'),(32,42,'DEFINITION','text'),(33,42,'VERSION','varchar'),(37,12,'QUANTITY_ID','bigint'),(38,12,'SPECIMEN_CLASS','varchar'),(39,43,'IDENTIFIER','bigint'),(40,43,'NEOPLASTIC_CELLULARITY_PER','double'),(41,43,'VIABLE_CELL_PERCENTAGE','double'),(42,44,'IDENTIFIER','bigint'),(43,44,'STORAGE_STATUS','varchar'),(47,17,'COLLECTION_PROTOCOL_ID','bigint'),(48,17,'USER_ID','bigint'),(49,45,'COLLECTION_PROTOCOL_ID','bigint'),(50,45,'DISTRIBUTION_PROTOCOL_ID','bigint'),(51,46,'IDENTIFIER','bigint'),(52,46,'COLLECTION_PROCEDURE','varchar'),(53,46,'CONTAINER','varchar'),(54,10,'IDENTIFIER','bigint'),(55,11,'IDENTIFIER','bigint'),(56,11,'CLINICAL_STATUS','varchar'),(57,11,'STUDY_CALENDAR_EVENT_POINT','double'),(58,11,'COLLECTION_PROTOCOL_ID','bigint'),(59,27,'IDENTIFIER','bigint'),(60,27,'PROTOCOL_PARTICIPANT_ID','varchar'),(61,27,'REGISTRATION_DATE','date'),(62,27,'PARTICIPANT_ID','bigint'),(63,27,'COLLECTION_PROTOCOL_ID','bigint'),(64,27,'ACTIVITY_STATUS','varchar'),(65,18,'COLLECTION_PROTOCOL_EVENT_ID','bigint'),(66,18,'SPECIMEN_REQUIREMENT_ID','bigint'),(67,5,'IDENTIFIER','bigint'),(68,5,'NAME','varchar'),(69,47,'IDENTIFIER','bigint'),(70,47,'REASON','varchar'),(71,37,'IDENTIFIER','bigint'),(72,37,'QUANTITY','double'),(73,37,'SPECIMEN_ID','bigint'),(74,37,'DISTRIBUTION_ID','bigint'),(75,38,'IDENTIFIER','bigint'),(76,38,'TO_SITE_ID','bigint'),(78,38,'DISTRIBUTION_PROTOCOL_ID','bigint'),(79,19,'IDENTIFIER','bigint'),(80,20,'DISTRIBUTION_PROTOCOL_ID','bigint'),(82,48,'IDENTIFIER','bigint'),(83,48,'EMBEDDING_MEDIUM','varchar'),(84,28,'IDENTIFIER','bigint'),(85,28,'NAME','varchar'),(86,28,'VALUE','varchar'),(87,28,'SPECIMEN_ID','bigint'),(88,49,'IDENTIFIER','bigint'),(89,49,'FIXATION_TYPE','varchar'),(90,49,'DURATION_IN_MINUTES','integer'),(96,50,'IDENTIFIER','bigint'),(97,50,'CELL_COUNT','double'),(98,51,'IDENTIFIER','bigint'),(99,51,'METHOD','varchar'),(100,6,'IDENTIFIER','bigint'),(101,6,'NAME','varchar'),(102,100,'SPECIMEN_CLASS','varchar'),(103,100,'INITIAL_QUANTITY','double'),(104,33,'AVAILABLE_QUANTITY','double'),(108,52,'IDENTIFIER','bigint'),(109,52,'GEL_IMAGE_URL','varchar'),(110,52,'QUALITY_INDEX','varchar'),(111,52,'LANE_NUMBER','varchar'),(112,52,'GEL_NUMBER','integer'),(113,52,'ABSORBANCE_AT_260','double'),(114,52,'ABSORBANCE_AT_280','double'),(115,52,'RATIO_28S_TO_18S','double'),(116,31,'IDENTIFIER','bigint'),(117,31,'LAST_NAME','varchar'),(118,31,'FIRST_NAME','varchar'),(119,31,'MIDDLE_NAME','varchar'),(120,31,'BIRTH_DATE','date'),(121,31,'GENDER','varchar'),(122,31,'GENOTYPE','varchar'),(124,31,'ETHNICITY','varchar'),(125,31,'SOCIAL_SECURITY_NUMBER','varchar'),(126,31,'ACTIVITY_STATUS','varchar'),(127,32,'IDENTIFIER','bigint'),(128,32,'MEDICAL_RECORD_NUMBER','varchar'),(129,32,'SITE_ID','bigint'),(130,32,'PARTICIPANT_ID','bigint'),(131,53,'IDENTIFIER','varchar'),(132,53,'CONCEPT_CODE','varchar'),(133,53,'DEFINITION','text'),(134,53,'EVS_CODE','text'),(135,53,'PARENT_IDENTIFIER','varchar'),(136,53,'VALUE','varchar'),(137,53,'PUBLIC_ID','varchar'),(138,54,'IDENTIFIER','bigint'),(139,54,'URL','varchar'),(140,54,'NAME','varchar'),(141,55,'IDENTIFIER','bigint'),(142,55,'TABLE_ID','bigint'),(143,55,'COLUMN_NAME','varchar'),(144,55,'DISPLAY_NAME','varchar'),(145,55,'ATTRIBUTE_TYPE','varchar'),(146,56,'TABLE_ID','bigint'),(147,56,'DISPLAY_NAME','varchar'),(148,56,'TABLE_NAME','varchar'),(149,56,'ALIAS_NAME','varchar'),(150,57,'IDENTIFIER','bigint'),(151,57,'RECEIVED_QUALITY','varchar'),(152,58,'FIRST_TABLE_ID','bigint'),(153,58,'SECOND_TABLE_ID','bigint'),(154,58,'FIRST_TABLE_JOIN_COLUMN','varchar'),(155,58,'SECOND_TABLE_JOIN_COLUMN','varchar'),(156,59,'IDENTIFIER','bigint'),(157,59,'AFFILIATION','varchar'),(158,59,'NAME_OF_REPORTER','varchar'),(159,59,'REPORTERS_EMAIL_ID','varchar'),(160,59,'MESSAGE_BODY','varchar'),(161,59,'SUBJECT','varchar'),(162,59,'REPORTED_DATE','date'),(163,59,'ACTIVITY_STATUS','varchar'),(164,59,'COMMENTS','text'),(165,60,'IDENTIFIER','bigint'),(166,61,'IDENTIFIER','bigint'),(167,61,'FIRST_NAME','varchar'),(168,61,'LAST_NAME','varchar'),(169,61,'LOGIN_NAME','varchar'),(170,61,'EMAIL_ADDRESS','varchar'),(171,61,'START_DATE','date'),(172,61,'ACTIVITY_STATUS','varchar'),(173,61,'DEPARTMENT_ID','bigint'),(174,61,'STREET','varchar'),(175,61,'CITY','varchar'),(176,61,'STATE','varchar'),(177,61,'COUNTRY','varchar'),(178,61,'ZIPCODE','varchar'),(179,61,'PHONE_NUMBER','varchar'),(180,61,'FAX_NUMBER','varchar'),(181,61,'CANCER_RESEARCH_GROUP_ID','bigint'),(182,61,'INSTITUTION_ID','bigint'),(183,61,'STATUS_COMMENT','text'),(184,3,'IDENTIFIER','bigint'),(185,3,'NAME','varchar'),(186,3,'TYPE','varchar'),(187,3,'EMAIL_ADDRESS','varchar'),(188,3,'USER_ID','bigint'),(189,3,'ACTIVITY_STATUS','varchar'),(190,3,'ADDRESS_ID','bigint'),(191,33,'IDENTIFIER','bigint'),(192,100,'SPECIMEN_TYPE','varchar'),(193,33,'AVAILABLE','tinyint'),(196,33,'BARCODE','varchar'),(197,33,'COMMENTS','varchar'),(198,33,'ACTIVITY_STATUS','varchar'),(199,100,'PARENT_SPECIMEN_ID','bigint'),(200,94,'STORAGE_CONTAINER_IDENTIFIER','bigint'),(201,33,'SPECIMEN_COLLECTION_GROUP_ID','bigint'),(202,100,'SPECIMEN_CHARACTERISTICS_ID','bigint'),(203,62,'BIOHAZARD_ID','bigint'),(204,62,'SPECIMEN_ID','bigint'),(205,34,'IDENTIFIER','bigint'),(206,34,'TISSUE_SITE','varchar'),(207,34,'TISSUE_SIDE','varchar'),(208,100,'PATHOLOGICAL_STATUS','varchar'),(209,35,'IDENTIFIER','bigint'),(210,92,'CLINICAL_DIAGNOSIS','varchar'),(211,92,'CLINICAL_STATUS','varchar'),(212,92,'ACTIVITY_STATUS','varchar'),(213,92,'SITE_ID','bigint'),(214,35,'COLLECTION_PROTOCOL_EVENT_ID','bigint'),(215,35,'SURGICAL_PATHOLOGY_NUMBER','varchar'),(216,35,'COLLECTION_PROTOCOL_REG_ID','bigint'),(217,63,'IDENTIFIER','bigint'),(218,63,'SPECIMEN_ID','bigint'),(219,63,'EVENT_TIMESTAMP','timestamptime'),(220,63,'USER_ID','bigint'),(221,63,'COMMENTS','text'),(222,9,'IDENTIFIER','bigint'),(223,9,'PRINCIPAL_INVESTIGATOR_ID','bigint'),(224,9,'TITLE','varchar'),(225,9,'SHORT_TITLE','varchar'),(226,9,'IRB_IDENTIFIER','varchar'),(227,9,'START_DATE','date'),(228,9,'END_DATE','date'),(229,9,'ENROLLMENT','integer'),(230,9,'DESCRIPTION_URL','varchar'),(231,9,'ACTIVITY_STATUS','varchar'),(232,12,'IDENTIFIER','bigint'),(233,12,'SPECIMEN_TYPE','varchar'),(234,12,'TISSUE_SITE','varchar'),(235,12,'PATHOLOGY_STATUS','varchar'),(236,64,'IDENTIFIER','bigint'),(237,64,'GFORCE','double'),(238,64,'DURATION_IN_MINUTES','integer'),(239,21,'IDENTIFIER','bigint'),(240,70,'NAME','varchar'),(241,21,'TEMPERATURE','double'),(242,70,'CONT_FULL','tinyint'),(243,70,'BARCODE','varchar'),(244,70,'ACTIVITY_STATUS','varchar'),(245,21,'STORAGE_TYPE_ID','bigint'),(246,21,'SITE_ID','bigint'),(247,95,'PARENT_CONTAINER_ID','bigint'),(248,70,'CAPACITY_ID','bigint'),(249,93,'POSITION_DIMENSION_ONE','integer'),(250,93,'POSITION_DIMENSION_TWO','integer'),(251,2,'IDENTIFIER','bigint'),(252,2,'ONE_DIMENSION_CAPACITY','integer'),(253,2,'TWO_DIMENSION_CAPACITY','integer'),(258,1,'IDENTIFIER','bigint'),(260,1,'DEFAULT_TEMPERATURE','double'),(261,69,'ONE_DIMENSION_LABEL','varchar'),(262,69,'TWO_DIMENSION_LABEL','varchar'),(263,69,'CAPACITY_ID','bigint'),(264,65,'PARENT_TABLE_ID','bigint'),(265,65,'CHILD_TABLE_ID','bigint'),(266,66,'IDENTIFIER','bigint'),(272,67,'IDENTIFIER','bigint'),(273,67,'NEOPLASTIC_CELLULARITY_PER','double'),(274,67,'NECROSIS_PERCENTAGE','double'),(275,67,'LYMPHOCYTIC_PERCENTAGE','double'),(276,67,'TOTAL_CELLULARITY_PERCENTAGE','double'),(277,67,'HISTOLOGICAL_QUALITY','varchar'),(278,68,'IDENTIFIER','bigint'),(279,68,'FROM_POSITION_DIMENSION_ONE','integer'),(280,68,'FROM_POSITION_DIMENSION_TWO','integer'),(281,68,'TO_POSITION_DIMENSION_ONE','integer'),(282,68,'TO_POSITION_DIMENSION_TWO','integer'),(283,68,'TO_STORAGE_CONTAINER_ID','bigint'),(284,68,'FROM_STORAGE_CONTAINER_ID','bigint'),(285,23,'IDENTIFIER','bigint'),(286,23,'ACTIVITY_STATUS','varchar'),(287,23,'DEPARTMENT_ID','bigint'),(288,23,'CANCER_RESEARCH_GROUP_ID','bigint'),(289,23,'INSTITUTION_ID','bigint'),(290,23,'ADDRESS_ID','bigint'),(291,23,'STATUS_COMMENT','text'),(292,23,'LAST_NAME','varchar'),(293,23,'FIRST_NAME','varchar'),(294,23,'LOGIN_NAME','varchar'),(295,23,'START_DATE','date'),(296,63,'EVENT_TIMESTAMP','timestampdate'),(297,38,'ACTIVITY_STATUS','varchar'),(298,38,'EVENT_TIMESTAMP','timestampdate'),(299,38,'USER_ID','bigint'),(300,38,'COMMENTS','varchar'),(301,38,'SPECIMEN_ID','bigint'),(302,38,'EVENT_TIMESTAMP','timestamptime'),(303,31,'DEATH_DATE','date'),(304,31,'VITAL_STATUS','varchar'),(305,1,'ACTIVITY_STATUS','varchar'),(306,69,'IDENTIFIER','bigint'),(307,69,'NAME','varchar'),(308,69,'COMMENTS','varchar'),(309,70,'IDENTIFIER','bigint'),(310,70,'COMMENTS','varchar'),(311,71,'IDENTIFIER','bigint'),(312,71,'SPECIMEN_CLASS','varchar'),(313,72,'IDENTIFIER','bigint'),(314,72,'CREATED_BY_ID','bigint'),(315,72,'SPECIMEN_ARRAY_TYPE_ID','bigint'),(316,73,'PARTICIPANT_ID','bigint'),(317,73,'RACE_NAME','varchar'),(320,35,'NAME','varchar'),(321,72,'DISTRIBUTION_ID','bigint'),(322,100,'LINEAGE','varchar'),(323,33,'LABEL','varchar'),(324,72,'AVAILABLE','tinyint'),(325,75,'EVENT_TIMESTAMP','timestampdate'),(326,75,'EVENT_TIMESTAMP','timestamptime'),(327,75,'IDENTIFIER','bigint'),(328,33,'CREATED_ON_DATE','date'),(329,11,'COLLECTION_POINT_LABEL','varchar'),(330,92,'IDENTIFIER','bigint'),(331,94,'IDENTIFIER','bigint'),(332,94,'SPECIMEN_ID','bigint'),(333,94,'CONTAINER_ID','bigint'),(334,95,'IDENTIFIER','bigint'),(335,95,'CONTAINER_ID','bigint'),(336,93,'IDENTIFIER','bigint'),(337,100,'IDENTIFIER','bigint'),(338,35,'BARCODE','varchar'),(339,27,'BARCODE','varchar'),(340,20,'SPECIMEN_TYPE','varchar'),(341,20,'SPECIMEN_CLASS','varchar'),(342,20,'TISSUE_SITE','varchar'),(343,20,'PATHOLOGY_STATUS','varchar'),(344,20,'QUANTITY','double'),(345,99,'CONCENTRATION','double');

/*Table structure for table `catissue_login_audit_event_log` */

DROP TABLE IF EXISTS `catissue_login_audit_event_log`;

CREATE TABLE `catissue_login_audit_event_log` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `LOGIN_TIMESTAMP` datetime DEFAULT NULL,
  `USER_LOGIN_ID` bigint(20) DEFAULT NULL,
  `LOGIN_SOURCE_ID` bigint(20) DEFAULT NULL,
  `LOGIN_IP_ADDRESS` varchar(20) DEFAULT NULL,
  `IS_LOGIN_SUCCESSFUL` bit(1) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_login_audit_event_log` */

/*Table structure for table `catissue_participant` */

DROP TABLE IF EXISTS `catissue_participant`;

CREATE TABLE `catissue_participant` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `MIDDLE_NAME` varchar(255) DEFAULT NULL,
  `BIRTH_DATE` date DEFAULT NULL,
  `GENDER` varchar(20) DEFAULT NULL,
  `GENOTYPE` varchar(50) DEFAULT NULL,
  `ETHNICITY` varchar(50) DEFAULT NULL,
  `SOCIAL_SECURITY_NUMBER` varchar(50) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `DEATH_DATE` date DEFAULT NULL,
  `VITAL_STATUS` varchar(50) DEFAULT NULL,
  `LNAME_METAPHONE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `SOCIAL_SECURITY_NUMBER` (`SOCIAL_SECURITY_NUMBER`),
  KEY `INDX_PARTICIPANT_LNAME` (`LAST_NAME`),
  KEY `INDX_PARTICIPANT_FNAME` (`FIRST_NAME`),
  KEY `INDX_PARTICIPANT_MNAME` (`MIDDLE_NAME`),
  KEY `INDX_PARTICIPANT_BDATE` (`BIRTH_DATE`),
  KEY `INDX_PARTICIPANT_DDATE` (`DEATH_DATE`),
  KEY `INDX_PARTICIPANT_VSTATUS` (`VITAL_STATUS`),
  KEY `INDX_PARTICIPANT_GENDER` (`GENDER`),
  KEY `INDX_PARTICIPANT_GENOTYPE` (`GENOTYPE`),
  KEY `INDX_PARTICIPANT_ETHNICITY` (`ETHNICITY`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_participant` */

insert  into `catissue_participant`(`IDENTIFIER`,`LAST_NAME`,`FIRST_NAME`,`MIDDLE_NAME`,`BIRTH_DATE`,`GENDER`,`GENOTYPE`,`ETHNICITY`,`SOCIAL_SECURITY_NUMBER`,`ACTIVITY_STATUS`,`DEATH_DATE`,`VITAL_STATUS`,`LNAME_METAPHONE`) values (1,'Basu','Prerna','Anurag',NULL,'Female',NULL,NULL,NULL,'Active',NULL,NULL,NULL),(2,'Bajaj','Hrishibh','Vijay',NULL,'Male',NULL,NULL,NULL,'Active',NULL,NULL,NULL);

/*Table structure for table `catissue_permissible_value` */

DROP TABLE IF EXISTS `catissue_permissible_value`;

CREATE TABLE `catissue_permissible_value` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CONCEPT_CODE` varchar(40) DEFAULT NULL,
  `DEFINITION` text,
  `PARENT_IDENTIFIER` bigint(20) DEFAULT NULL,
  `VALUE` varchar(225) DEFAULT NULL,
  `PUBLIC_ID` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK57DDCE153B5435E` (`PARENT_IDENTIFIER`),
  KEY `FK57DDCE1FC56C2B1` (`PUBLIC_ID`),
  CONSTRAINT `FK57DDCE153B5435E` FOREIGN KEY (`PARENT_IDENTIFIER`) REFERENCES `catissue_permissible_value` (`IDENTIFIER`),
  CONSTRAINT `FK57DDCE1FC56C2B1` FOREIGN KEY (`PUBLIC_ID`) REFERENCES `catissue_cde` (`PUBLIC_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4141660082537375019 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_permissible_value` */

/*Table structure for table `catissue_query_editlink_cols` */

DROP TABLE IF EXISTS `catissue_query_editlink_cols`;

CREATE TABLE `catissue_query_editlink_cols` (
  `TABLE_ID` bigint(20) NOT NULL,
  `COL_ID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_query_editlink_cols` */

insert  into `catissue_query_editlink_cols`(`TABLE_ID`,`COL_ID`) values (8,25),(7,29),(10,225),(10,224),(27,59),(5,68),(38,75),(19,224),(19,225),(75,327),(6,101),(31,116),(31,117),(31,118),(3,185),(33,196),(33,323),(72,240),(72,243),(71,307),(35,320),(21,240),(1,307),(23,292),(23,293),(23,294);

/*Table structure for table `catissue_query_table_data` */

DROP TABLE IF EXISTS `catissue_query_table_data`;

CREATE TABLE `catissue_query_table_data` (
  `TABLE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TABLE_NAME` varchar(50) DEFAULT NULL,
  `DISPLAY_NAME` varchar(50) DEFAULT NULL,
  `ALIAS_NAME` varchar(50) DEFAULT NULL,
  `PRIVILEGE_ID` int(1) DEFAULT NULL,
  `FOR_SQI` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`TABLE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_query_table_data` */

insert  into `catissue_query_table_data`(`TABLE_ID`,`TABLE_NAME`,`DISPLAY_NAME`,`ALIAS_NAME`,`PRIVILEGE_ID`,`FOR_SQI`) values (1,'CATISSUE_STORAGE_TYPE','Storage Type','StorageType',1,1),(2,'CATISSUE_CAPACITY','Storage Container Capacity','StorageContainerCapacity',2,NULL),(3,'CATISSUE_SITE','Site','Site',2,1),(4,'CATISSUE_ADDRESS','Address','Address',2,NULL),(5,'CATISSUE_DEPARTMENT','Department','Department',1,1),(6,'CATISSUE_INSTITUTION','Institution','Institution',1,1),(7,'CATISSUE_CANCER_RESEARCH_GROUP','Cancer Research Group','CancerResearchGroup',1,1),(8,'CATISSUE_BIOHAZARD','Biohazard','Biohazard',1,1),(9,'CATISSUE_SPECIMEN_PROTOCOL','Specimen Protocol','SpecimenProtocol',2,NULL),(10,'CATISSUE_COLLECTION_PROTOCOL','Collection Protocol','CollectionProtocol',2,1),(11,'CATISSUE_COLL_PROT_EVENT','Collection Protocol Event','CollectionProtocolEvent',2,NULL),(12,'CATISSUE_SPECIMEN_REQUIREMENT','Specimen Requirement','SpecimenRequirement',2,NULL),(17,'CATISSUE_COLL_COORDINATORS','Collection Coordinators','CollectionCoordinators',2,NULL),(18,'CATISSUE_CP_REQ_SPECIMEN','Collection Specimen Requirement','CollectionSpecReq',2,NULL),(19,'CATISSUE_DISTRIBUTION_PROTOCOL','Distribution Protocol','DistributionProtocol',2,1),(20,'CATISSUE_DISTRIBUTION_SPEC_REQ','Distribution Specimen Requirement','DistributionSpecReq',1,NULL),(21,'CATISSUE_STORAGE_CONTAINER','Storage Container','StorageContainer',2,1),(23,'CATISSUE_USER','User','User',2,1),(27,'CATISSUE_COLL_PROT_REG','Collection Protocol Registration','CollectionProtReg',2,1),(28,'CATISSUE_EXTERNAL_IDENTIFIER','External Identifier','ExternalIdentifier',2,NULL),(31,'CATISSUE_PARTICIPANT','Participant','Participant',2,1),(32,'CATISSUE_PART_MEDICAL_ID','Participant Medical Identifier','ParticipantMedicalId',2,NULL),(33,'CATISSUE_SPECIMEN','Specimen','Specimen',2,1),(34,'CATISSUE_SPECIMEN_CHAR','Specimen Characteristics','SpecimenCharacteristics',2,NULL),(35,'CATISSUE_SPECIMEN_COLL_GROUP','Specimen Collection Group','SpecimenCollectionGroup',2,1),(37,'CATISSUE_DISTRIBUTED_ITEM','Distributed Item','DistributedItem',1,NULL),(38,'CATISSUE_DISTRIBUTION','Distribution','Distribution',2,1),(39,'CATISSUE_AUDIT_EVENT','Audit Event','AuditEvent',1,NULL),(40,'CATISSUE_AUDIT_EVENT_DETAILS','Audit Event Details','AuditEventDetails',1,NULL),(41,'CATISSUE_AUDIT_EVENT_LOG','Audit Event Log','AuditEventLog',1,NULL),(42,'CATISSUE_CDE','Cde','Cde',0,NULL),(43,'CATISSUE_CELL_SPE_REVIEW_PARAM','Cell Specimen Review Parameters','CellSpecimenParam',2,2),(44,'CATISSUE_IN_OUT_EVENT_PARAM','Checkin Checkout Event Parameter','CheckinoutEventParam',2,2),(45,'CATISSUE_COLL_DISTRIBUTION_REL','Collection Distribution Relation','CollectionDistributionRel',2,NULL),(46,'CATISSUE_COLL_EVENT_PARAM','Collection Event Parameters','CollectionEventParam',2,2),(47,'CATISSUE_DISPOSAL_EVENT_PARAM','Disposal Event Parameters','DisposalEventParam',2,2),(48,'CATISSUE_EMBEDDED_EVENT_PARAM','Embedded Event Parameters','EmbeddedEventParam',2,2),(49,'CATISSUE_FIXED_EVENT_PARAM','Fixed Event Parameters','FixedEventParameters',2,2),(50,'CATISSUE_FLUID_SPE_EVENT_PARAM','Fluid Specimen Review Event Parameters','FluidSpecEventParam',2,2),(51,'CATISSUE_FROZEN_EVENT_PARAM','Frozen Event Parameters','FrozenEventParameters',2,2),(52,'CATISSUE_MOL_SPE_REVIEW_PARAM','Molecular Specimen Review Parameters','MolecularSpecParam',2,2),(53,'CATISSUE_PERMISSIBLE_VALUE','Permissible Value','PermissibleValue',0,NULL),(54,'CATISSUE_PROCEDURE_EVENT_PARAM','Procedure Event Parameters','ProcedureEventParam',2,2),(55,'CATISSUE_INTERFACE_COLUMN_DATA','Query Interface Column Data','QueryInterfaceColumnData',0,NULL),(56,'CATISSUE_QUERY_TABLE_DATA','Query Interface Table Data','QueryInterfaceTableData',0,NULL),(57,'CATISSUE_RECEIVED_EVENT_PARAM','Received Event Parameters','ReceivedEventParam',2,2),(58,'CATISSUE_RELATED_TABLES_MAP','Related Tables Map','RelatedTablesMap',0,NULL),(59,'CATISSUE_REPORTED_PROBLEM','Reported Problem','ReportedProblem',1,1),(60,'CATISSUE_EVENT_PARAM','Review Event Parameters','ReviewEventParameters',2,NULL),(61,'CATISSUE_SIGNUP_USER','Signup User','SignupUser',2,NULL),(62,'CATISSUE_SPECIMEN_BIOHZ_REL','Biohazard','SpecimenBiohazardRel',2,NULL),(63,'CATISSUE_SPECIMEN_EVENT_PARAM','Specimen Event Parameters','SpecimenEventParameters',2,NULL),(64,'CATISSUE_SPUN_EVENT_PARAMETERS','Spun Event Parameters','SpunEventParameters',2,2),(65,'CATISSUE_TABLE_RELATION','Table Relation','TableRelation',0,NULL),(66,'CATISSUE_THAW_EVENT_PARAMETERS','Thaw Event Parameters','ThawEventParameters',2,2),(67,'CATISSUE_TIS_SPE_EVENT_PARAM','Tissue Specimen Review Event Parameters','TissueSpecEventParam',2,2),(68,'CATISSUE_TRANSFER_EVENT_PARAM','Transfer Event Parameter','TransferEventParameter',2,2),(69,'CATISSUE_CONTAINER_TYPE','Container Type','ContainerType',0,NULL),(70,'CATISSUE_CONTAINER','Container','Container',0,NULL),(71,'CATISSUE_SPECIMEN_ARRAY_TYPE','Specimen Array Type','SpecimenArrayType',2,1),(72,'CATISSUE_SPECIMEN_ARRAY','Specimen Array','SpecimenArray',2,1),(73,'CATISSUE_RACE','Race','Race',0,NULL),(75,'CATISSUE_DISTRIBUTION','Distribution_array','Distribution_array',2,1),(76,'CATISSUE_ORDER','Order','OrderDetails',2,NULL),(77,'CATISSUE_REPORT_QUEUE','Report Queue','ReportQueue',2,NULL),(78,'CATISSUE_PATHOLOGY_REPORT','Surgical Pathology Report','SurgicalPathologyReport',2,NULL),(79,'CATISSUE_IDENTIFIED_REPORT','Identified Surgical Pathology Report','IdentifiedSurgicalPathologyReport',2,NULL),(80,'CATISSUE_DEIDENTIFIED_REPORT','Deidentified Surgical Pathology Report','DeidentifiedSurgicalPathologyReport',2,NULL),(81,'CATISSUE_REPORT_CONTENT','Report Content','ReportContent',2,NULL),(82,'CATISSUE_REPORT_TEXTCONTENT','Text Content','TextContent',2,NULL),(83,'CATISSUE_REPORT_BICONTENT','Binary Content','BinaryContent',2,NULL),(84,'CATISSUE_REPORT_SECTION','Report Section','ReportSection',2,NULL),(85,'CATISSUE_CONCEPT','Concept','Concept',2,NULL),(87,'CATISSUE_CONCEPT_REFERENT','Concept Referent','ConceptReferent',2,NULL),(88,'CATISSUE_CONCEPT_CLASSIFICATN','Concept Referent Classification','ConceptReferentClassification',2,NULL),(89,'CATISSUE_SEMANTIC_TYPE','Semantic Type','SemanticType',2,NULL),(90,'CATISSUE_REVIEW_PARAMS','Pathology Report Review Parameter','PathologyReportReviewParameter',2,NULL),(91,'CATISSUE_QUARANTINE_PARAMS','Quarantine Event Parameter','QuarantineEventParameter',2,NULL),(92,'CATISSUE_ABS_SPECI_COLL_GROUP','Abstract Specimen Coll Group','AbstractScg',2,NULL),(93,'CATISSUE_ABSTRACT_POSITION','Abstract Position','AbstractPosition',2,NULL),(94,'CATISSUE_SPECIMEN_POSITION','Specimen Position','SpecimenPosition',2,1),(95,'CATISSUE_CONTAINER_POSITION','Container Position','ContainerPosition',2,1),(96,'catissue_tissue_specimen','Tissue Specimen','Tissue Specimen',2,NULL),(97,'catissue_cell_specimen','Cell Specimen','Cell Specimen',2,NULL),(98,'catissue_fluid_specimen','Fluid Specimen','Fluid Specimen',2,NULL),(99,'catissue_molecular_specimen','Molecular Specimen','MolecularSpecimen',2,NULL),(100,'CATISSUE_ABSTRACT_SPECIMEN','Abstract Specimen','AbstractSpecimen',2,NULL),(101,'CATISSUE_SHIPMENT','Shipment','Shipment',2,NULL),(102,'CATISSUE_SHIPMENT_REQUEST','Shipment Request','ShipmentRequest',2,NULL);

/*Table structure for table `catissue_race` */

DROP TABLE IF EXISTS `catissue_race`;

CREATE TABLE `catissue_race` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `RACE_NAME` varchar(50) DEFAULT NULL,
  `PARTICIPANT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKB0242ECD87E5ADC7` (`PARTICIPANT_ID`),
  KEY `INDX_RACE_NAME` (`RACE_NAME`),
  CONSTRAINT `FKB0242ECD87E5ADC7` FOREIGN KEY (`PARTICIPANT_ID`) REFERENCES `catissue_participant` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_race` */

/*Table structure for table `catissue_related_tables_map` */

DROP TABLE IF EXISTS `catissue_related_tables_map`;

CREATE TABLE `catissue_related_tables_map` (
  `FIRST_TABLE_ID` bigint(20) DEFAULT NULL,
  `SECOND_TABLE_ID` bigint(20) DEFAULT NULL,
  `FIRST_TABLE_JOIN_COLUMN` varchar(50) DEFAULT NULL,
  `SECOND_TABLE_JOIN_COLUMN` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_related_tables_map` */

insert  into `catissue_related_tables_map`(`FIRST_TABLE_ID`,`SECOND_TABLE_ID`,`FIRST_TABLE_JOIN_COLUMN`,`SECOND_TABLE_JOIN_COLUMN`) values (10,11,'IDENTIFIER','COLLECTION_PROTOCOL_ID'),(5,23,'IDENTIFIER','DEPARTMENT_ID'),(6,23,'IDENTIFIER','INSTITUTION_ID'),(7,23,'IDENTIFIER','CANCER_RESEARCH_GROUP_ID'),(4,23,'IDENTIFIER','ADDRESS_ID'),(4,3,'IDENTIFIER','ADDRESS_ID'),(9,10,'IDENTIFIER','IDENTIFIER'),(23,9,'IDENTIFIER','PRINCIPAL_INVESTIGATOR_ID'),(23,17,'IDENTIFIER','USER_ID'),(10,17,'IDENTIFIER','COLLECTION_PROTOCOL_ID'),(12,18,'IDENTIFIER','SPECIMEN_REQUIREMENT_ID'),(11,18,'IDENTIFIER','COLLECTION_PROTOCOL_EVENT_ID'),(9,19,'IDENTIFIER','IDENTIFIER'),(19,20,'IDENTIFIER','DISTRIBUTION_PROTOCOL_ID'),(23,24,'IDENTIFIER','USER_ID'),(31,32,'IDENTIFIER','PARTICIPANT_ID'),(31,73,'IDENTIFIER','PARTICIPANT_ID'),(10,27,'IDENTIFIER','COLLECTION_PROTOCOL_ID'),(31,27,'IDENTIFIER','PARTICIPANT_ID'),(3,92,'IDENTIFIER','SITE_ID'),(11,35,'IDENTIFIER','COLLECTION_PROTOCOL_EVENT_ID'),(27,35,'IDENTIFIER','COLLECTION_PROTOCOL_REG_ID'),(35,33,'IDENTIFIER','SPECIMEN_COLLECTION_GROUP_ID'),(34,100,'IDENTIFIER','SPECIMEN_CHARACTERISTICS_ID'),(100,100,'IDENTIFIER','PARENT_SPECIMEN_ID'),(33,37,'IDENTIFIER','SPECIMEN_ID'),(38,37,'IDENTIFIER','DISTRIBUTION_ID'),(33,62,'IDENTIFIER','SPECIMEN_ID'),(8,62,'IDENTIFIER','BIOHAZARD_ID'),(33,28,'IDENTIFIER','SPECIMEN_ID'),(33,63,'IDENTIFIER','SPECIMEN_ID'),(1,69,'IDENTIFIER','IDENTIFIER'),(3,21,'IDENTIFIER','SITE_ID'),(2,70,'IDENTIFIER','CAPACITY_ID'),(1,21,'IDENTIFIER','STORAGE_TYPE_ID'),(70,21,'IDENTIFIER','IDENTIFIER'),(71,69,'IDENTIFIER','IDENTIFIER'),(72,71,'SPECIMEN_ARRAY_TYPE_ID','IDENTIFIER'),(72,70,'IDENTIFIER','IDENTIFIER'),(75,37,'IDENTIFIER','DISTRIBUTION_ID'),(72,37,'IDENTIFIER','SPECIMEN_ARRAY_ID'),(63,43,'IDENTIFIER','IDENTIFIER'),(63,44,'IDENTIFIER','IDENTIFIER'),(63,46,'IDENTIFIER','IDENTIFIER'),(63,47,'IDENTIFIER','IDENTIFIER'),(63,48,'IDENTIFIER','IDENTIFIER'),(63,49,'IDENTIFIER','IDENTIFIER'),(63,50,'IDENTIFIER','IDENTIFIER'),(63,51,'IDENTIFIER','IDENTIFIER'),(63,52,'IDENTIFIER','IDENTIFIER'),(63,54,'IDENTIFIER','IDENTIFIER'),(63,57,'IDENTIFIER','IDENTIFIER'),(63,64,'IDENTIFIER','IDENTIFIER'),(63,66,'IDENTIFIER','IDENTIFIER'),(63,67,'IDENTIFIER','IDENTIFIER'),(63,68,'IDENTIFIER','IDENTIFIER'),(23,63,'IDENTIFIER','USER_ID'),(38,9,'DISTRIBUTION_PROTOCOL_ID','IDENTIFIER'),(75,3,'TO_SITE_ID','IDENTIFIER'),(75,9,'DISTRIBUTION_PROTOCOL_ID','IDENTIFIER'),(92,35,'IDENTIFIER','IDENTIFIER'),(93,94,'IDENTIFIER','IDENTIFIER'),(93,95,'IDENTIFIER','IDENTIFIER'),(33,94,'IDENTIFIER','SPECIMEN_ID'),(72,95,'IDENTIFIER','CONTAINER_ID'),(21,94,'IDENTIFIER','CONTAINER_ID'),(21,95,'IDENTIFIER','CONTAINER_ID'),(100,33,'IDENTIFIER','IDENTIFIER'),(33,99,'IDENTIFIER','IDENTIFIER');

/*Table structure for table `catissue_report_content` */

DROP TABLE IF EXISTS `catissue_report_content`;

CREATE TABLE `catissue_report_content` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `REPORT_DATA` text,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_report_content` */

/*Table structure for table `catissue_report_particip_rel` */

DROP TABLE IF EXISTS `catissue_report_particip_rel`;

CREATE TABLE `catissue_report_particip_rel` (
  `PARTICIPANT_ID` bigint(20) DEFAULT NULL,
  `REPORT_ID` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_report_particip_rel` */

/*Table structure for table `catissue_report_section` */

DROP TABLE IF EXISTS `catissue_report_section`;

CREATE TABLE `catissue_report_section` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `DOCUMENT_FRAGMENT` text,
  `END_OFFSET` int(11) DEFAULT NULL,
  `NAME` varchar(100) DEFAULT NULL,
  `START_OFFSET` int(11) DEFAULT NULL,
  `TEXT_CONTENT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_report_section` */

/*Table structure for table `catissue_reported_problem` */

DROP TABLE IF EXISTS `catissue_reported_problem`;

CREATE TABLE `catissue_reported_problem` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `AFFILIATION` varchar(255) NOT NULL,
  `NAME_OF_REPORTER` varchar(255) NOT NULL,
  `REPORTERS_EMAIL_ID` varchar(255) NOT NULL,
  `MESSAGE_BODY` varchar(500) NOT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `REPORTED_DATE` date DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(100) DEFAULT NULL,
  `COMMENTS` text,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_reported_problem` */

/*Table structure for table `catissue_search_display_data` */

DROP TABLE IF EXISTS `catissue_search_display_data`;

CREATE TABLE `catissue_search_display_data` (
  `RELATIONSHIP_ID` bigint(20) NOT NULL,
  `COL_ID` bigint(20) NOT NULL,
  `DISPLAY_NAME` varchar(50) DEFAULT NULL,
  `DEFAULT_VIEW_ATTRIBUTE` bit(1) DEFAULT b'0',
  `ATTRIBUTE_ORDER` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_search_display_data` */

insert  into `catissue_search_display_data`(`RELATIONSHIP_ID`,`COL_ID`,`DISPLAY_NAME`,`DEFAULT_VIEW_ATTRIBUTE`,`ATTRIBUTE_ORDER`) values (6,185,'Name','',1),(6,184,'Identifier','',2),(6,186,'Type','',3),(6,187,'Email Address','',4),(7,2,'Street','',5),(7,3,'City','',6),(7,4,'State','',7),(7,5,'Country','',8),(7,6,'Zip Code','',9),(7,7,'Phone Number','',10),(7,8,'Fax Number','',11),(2,101,'Name','',1),(2,100,'Identifier','',2),(3,68,'Name','',1),(3,67,'Identifier','',2),(4,29,'Name','',1),(4,28,'Identifier','',2),(5,25,'Name','',1),(5,24,'Identifier','',2),(5,26,'Comments','',3),(5,27,'Type','',4),(108,307,'Name','',1),(1,258,'Identifier','',2),(1,260,'Default Temperature','',3),(108,261,'One Dimension Label','',4),(108,262,'Two Dimension Label','',5),(108,308,'Comments','\0',6),(110,240,'Container Name','',1),(8,239,'Identifier','',2),(8,241,'Temperature','',3),(9,252,'One Dimension Capacity','\0',4),(9,253,'Two Dimension Capacity','\0',5),(10,307,'Container Type','\0',6),(10,261,'One Dimension Label','\0',7),(10,262,'Two Dimension Label','\0',8),(11,185,'Site Name','',9),(110,242,'Is Container Full','',10),(110,243,'Barcode','',11),(110,247,'Parent Container Identifier','',12),(110,310,'Comments','\0',15),(112,307,'Name','',1),(111,311,'Identifier','',2),(111,312,'Specimen Class','',3),(112,261,'One Dimension Label','',4),(112,262,'Two Dimension Label','',5),(112,308,'Comments','\0',6),(114,240,'Array Label','',1),(113,313,'Identifier','',2),(114,242,'Is Container Full','',3),(114,243,'Barcode','',4),(114,247,'Parent Container Identifier','',5),(114,310,'Comments','\0',8),(115,252,'One Dimension Capacity','',9),(115,253,'Two Dimension Capacity','',10),(116,307,'Array Type','\0',11),(129,312,'SpecimenClass','',12),(13,224,'Title','',1),(12,54,'Identifier','',2),(40,292,'Principal Investigator Last Name','',3),(40,293,'Principal Investigator First Name','',4),(42,292,'Protocol Coordinator Last Name','\0',5),(42,293,'Protocol Coordinator First Name','\0',6),(13,225,'Short Title','',7),(13,226,'IRB Identifier','',8),(13,227,'Start Date','',9),(18,224,'Title','',1),(17,79,'Identifier','',2),(18,225,'Short Title','',3),(18,226,'IRB Identifier','',4),(18,227,'Start Date','',5),(18,228,'End Date','',6),(18,229,'Enrollment','',7),(18,230,'Description URL','',8),(20,233,'Specimen Type','\0',9),(20,234,'Tissue Site','\0',10),(20,235,'Pathological Status','\0',11),(43,292,'Principal Investigator Last Name','',13),(43,293,'Principal Investigator First Name','',14),(19,80,'Distribution Protocol Identifier','\0',15),(21,293,'First Name','',1),(21,292,'Last Name','',2),(21,285,'Identifier','',3),(21,294,'Login Name','',4),(21,295,'Date','',5),(23,2,'Street','',6),(23,3,'City','',7),(23,4,'State','',8),(23,5,'Country','',9),(23,6,'Zip Code','',10),(23,7,'Phone Number','',11),(23,8,'Fax Number','',12),(25,101,'Institution Name','',13),(24,68,'Department Name','',14),(26,29,'Cancer Research Group Name','',15),(27,118,'First Name','',2),(27,117,'Last Name','',1),(27,116,'Identifier','',12),(27,119,'Middle Name','',3),(27,120,'Birth Date','',5),(27,303,'Death Date','',11),(27,304,'Vital Status','',10),(27,121,'Gender','',6),(27,122,'Genotype','',7),(27,124,'Ethnicity','',8),(27,125,'Social Security Number','',9),(28,128,'Medical Record Number','\0',4),(29,59,'Identifier','',8),(45,224,'Protocol Title','\0',6),(29,60,'Participant Protocol Identifier','',1),(29,61,'Registration Date','',7),(46,117,'Participant Last Name','',2),(46,118,'Participant First Name','',3),(46,119,'Participant Middle Name','',4),(46,120,'Participant Birth Date','',5),(30,320,'Name','',1),(30,209,'Identifier','',12),(137,210,'Clinical Diagnosis','',7),(137,211,'Clinical Status','',8),(48,224,'Collection Protocol Title','\0',11),(31,57,'Study Calendar Event Point','',9),(31,329,'Collection Point Label','\0',9),(32,185,'Site Name','',10),(33,60,'Protocol Participant Identifier','',2),(47,45,'Surgical Pathology Number','',6),(47,46,'Medical Record Number','',5),(54,117,'Participant Last Name','',3),(54,118,'Participant First Name','',4),(34,323,'Label','',2),(34,191,'Identifier','',20),(146,102,'Class','',6),(34,201,'Specimen Collection Group Identifier','',5),(146,199,'Parent Specimen Identifier','',9),(146,192,'Type','',7),(146,208,'Pathological Status','',12),(34,193,'Is Available','',16),(34,196,'Barcode','',1),(146,103,'Initial Quantity','',13),(34,104,'Available Quantity','',14),(146,322,'Lineage','',8),(34,328,'Created On','',19),(35,206,'Tissue Site','',11),(35,207,'Tissue Side','',10),(50,85,'External Identifier Name','',3),(50,86,'External Identifier Value','',4),(36,75,'Identifier','',1),(36,298,'Distribution Date','',2),(36,302,'Distribution Time','',3),(37,72,'Distributed Quantity','',4),(52,337,'Distributed Specimen Identifier','',5),(52,192,'Distributed Specimen Type','',6),(55,206,'Distributed Specimen Tissue Site','',7),(55,207,'Distributed Specimen Tissue Side','',8),(52,208,'Distributed Specimen Pathological Status','',9),(57,39,'Identifier','',NULL),(58,218,'Specimen Identifier','\0',NULL),(58,219,'Event Timestamp','\0',NULL),(58,221,'Comments','\0',NULL),(59,292,'User Last Name','\0',NULL),(59,293,'User First Name','\0',NULL),(57,40,'Neoplastic Cellularity Percentage','\0',NULL),(57,41,'Viable Cell Percentage','\0',NULL),(60,42,'Identifier','',NULL),(61,218,'Specimen Identifier','\0',NULL),(61,219,'Event Timestamp','\0',NULL),(61,221,'Comments','\0',NULL),(62,292,'User Last Name','\0',NULL),(62,293,'User First Name','\0',NULL),(60,43,'Storage Status','',NULL),(63,51,'Identifier','',NULL),(64,218,'Specimen Identifier','\0',NULL),(64,219,'Event Timestamp','\0',NULL),(64,221,'Comments','\0',NULL),(65,292,'User Last Name','\0',NULL),(65,293,'User First Name','\0',NULL),(63,52,'Collection Procedure','',NULL),(63,53,'Container','',NULL),(66,69,'Identifier','',NULL),(67,218,'Specimen Identifier','\0',NULL),(67,219,'Event Timestamp','\0',NULL),(67,221,'Comments','\0',NULL),(68,292,'User Last Name','\0',NULL),(68,293,'User First Name','\0',NULL),(66,70,'Reason','',NULL),(69,82,'Identifier','',NULL),(70,218,'Specimen Identifier','\0',NULL),(70,219,'Event Timestamp','\0',NULL),(70,221,'Comments','\0',NULL),(71,292,'User Last Name','\0',NULL),(71,293,'User First Name','\0',NULL),(69,83,'Embedding Medium','',NULL),(72,88,'Identifier','',NULL),(73,218,'Specimen Identifier','\0',NULL),(73,219,'Event Timestamp','\0',NULL),(73,221,'Comments','\0',NULL),(74,292,'User Last Name','\0',NULL),(74,293,'User First Name','\0',NULL),(72,89,'Fixation Type','',NULL),(72,90,'Duration In Minutes','',NULL),(75,96,'Identifier','',NULL),(76,218,'Specimen Identifier','\0',NULL),(76,219,'Event Timestamp','\0',NULL),(76,221,'Comments','\0',NULL),(77,292,'User Last Name','\0',NULL),(77,293,'User First Name','\0',NULL),(75,97,'Cell Count','',NULL),(78,98,'Identifier','',NULL),(79,218,'Specimen Identifier','\0',NULL),(79,219,'Event Timestamp','\0',NULL),(79,221,'Comments','\0',NULL),(80,292,'User Last Name','\0',NULL),(80,293,'User First Name','\0',NULL),(78,99,'Method','',NULL),(81,108,'Identifier','',NULL),(82,218,'Specimen Identifier','\0',NULL),(82,219,'Event Timestamp','\0',NULL),(82,221,'Comments','\0',NULL),(83,292,'User Last Name','\0',NULL),(83,293,'User First Name','\0',NULL),(81,109,'Gel Image URL','',NULL),(81,110,'Quality Index','',NULL),(81,111,'Lane Number','',NULL),(81,112,'Gel Number','',NULL),(81,113,'Absorbance At 260','',NULL),(81,114,'Absorbance At 280','',NULL),(81,115,'Ratio 28S to 18S','',NULL),(84,138,'Identifier','',NULL),(85,218,'Specimen Identifier','\0',NULL),(85,219,'Event Timestamp','\0',NULL),(85,221,'Comments','\0',NULL),(86,292,'User Last Name','\0',NULL),(86,293,'User First Name','\0',NULL),(84,139,'URL','',NULL),(84,140,'Name','',NULL),(87,150,'Identifier','',NULL),(88,218,'Specimen Identifier','\0',NULL),(88,219,'Event Timestamp','\0',NULL),(88,221,'Comments','\0',NULL),(89,292,'User Last Name','\0',NULL),(89,293,'User First Name','\0',NULL),(87,151,'Received Quality','',NULL),(90,236,'Identifier','',NULL),(91,218,'Specimen Identifier','\0',NULL),(91,219,'Event Timestamp','\0',NULL),(91,221,'Comments','\0',NULL),(92,292,'User Last Name','\0',NULL),(92,293,'User First Name','\0',NULL),(91,237,'GForce','\0',NULL),(91,238,'Duration In Minutes','\0',NULL),(93,266,'Identifier','',NULL),(94,218,'Specimen Identifier','\0',NULL),(94,219,'Event Timestamp','\0',NULL),(94,221,'Comments','\0',NULL),(95,292,'User Last Name','\0',NULL),(95,293,'User First Name','\0',NULL),(96,272,'Identifier','',NULL),(97,218,'Specimen Identifier','\0',NULL),(97,219,'Event Timestamp','\0',NULL),(97,221,'Comments','\0',NULL),(98,292,'User Last Name','\0',NULL),(98,293,'User First Name','\0',NULL),(96,273,'Neo Plastic Cellularity Percentage','',NULL),(96,274,'Necrosis Percentage','',NULL),(96,275,'Lymphocytic Percentage','',NULL),(96,276,'Total Cellularity Percentage','',NULL),(96,277,'Histological Quality','',NULL),(99,278,'Identifier','',NULL),(100,218,'Specimen Identifier','\0',NULL),(100,219,'Event Timestamp','\0',NULL),(100,221,'Comments','\0',NULL),(101,292,'User Last Name','\0',NULL),(101,293,'User First Name','\0',NULL),(99,284,'From Storage Container Identifier','',NULL),(99,283,'To Storage Container Identifier','',NULL),(99,279,'From Position Dimension One','',NULL),(99,280,'From Position Dimension Two','',NULL),(99,281,'To Position Dimension One','',NULL),(99,282,'To Position Dimension Two','',NULL),(102,156,'Identifier','',1),(102,157,'Affiliation','',2),(102,158,'Name of reporter','',3),(102,159,'Reporters email id','',4),(102,160,'Message Body','',5),(102,161,'Subject','',6),(102,162,'Reported Date','',7),(102,163,'Activity Status','',8),(105,24,'Identifier','\0',1),(105,25,'Name','\0',2),(105,26,'Comments','\0',3),(105,27,'Type','\0',4),(53,224,'Distribution Protocol Title','\0',1),(122,327,'Distribution Id','',1),(121,315,'Specimen Array Type Id','',2),(122,325,'Distribution Date','',3),(122,326,'Distribution Time','',4),(123,185,'Site Name','',5),(124,224,'Distribution Protocol Title','',6),(127,240,'SpecimenArray Name','',7),(125,307,'SpecimenArrayType Name','',8),(130,260,'Default Temperature In Centigrade','\0',9),(131,72,'Distributed Quantity','\0',10),(138,249,'Position Dimension One','',1),(138,250,'Position Dimension Two','',2),(139,249,'Position Dimension One','',1),(139,250,'Position Dimension Two','',2),(34,249,'Position Dimension One','',1),(34,250,'Position Dimension Two','',2),(140,249,'Position Dimension One','',1),(140,250,'Position Dimension Two','',2),(141,249,'Position Dimension One','',1),(141,250,'Position Dimension Two','',2),(142,249,'Position Dimension One','',1),(142,250,'Position Dimension Two','',2),(110,249,'Position Dimension One','',1),(110,250,'Position Dimension Two','',2),(114,249,'Position Dimension One','',1),(114,250,'Position Dimension Two','',2),(144,247,'Parent Container Id','',3),(143,333,'Parent Container Id','',3),(30,338,'Barcode','\0',2),(29,339,'Barcode','\0',7),(19,340,'Specimen Type','\0',12),(19,341,'Specimen Class','\0',13),(19,342,'Tissue Site','\0',14),(19,343,'Pathology status','\0',15),(19,344,'Quantity','\0',16),(147,345,'Concentration','\0',2);

/*Table structure for table `catissue_semantic_type` */

DROP TABLE IF EXISTS `catissue_semantic_type`;

CREATE TABLE `catissue_semantic_type` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `LABEL` text,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_semantic_type` */

/*Table structure for table `catissue_site` */

DROP TABLE IF EXISTS `catissue_site`;

CREATE TABLE `catissue_site` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  `TYPE` varchar(50) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `ADDRESS_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `FKB024C3436CD94566` (`ADDRESS_ID`),
  KEY `FKB024C3432206F20F` (`USER_ID`),
  KEY `INDX_CAT_SITE_TYPE` (`TYPE`),
  CONSTRAINT `FKB024C3432206F20F` FOREIGN KEY (`USER_ID`) REFERENCES `catissue_user` (`IDENTIFIER`),
  CONSTRAINT `FKB024C3436CD94566` FOREIGN KEY (`ADDRESS_ID`) REFERENCES `catissue_address` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_site` */

insert  into `catissue_site`(`IDENTIFIER`,`NAME`,`TYPE`,`EMAIL_ADDRESS`,`USER_ID`,`ACTIVITY_STATUS`,`ADDRESS_ID`) values (1,'In Transit','Repository','admin@admin.com',1,'Active',1);

/*Table structure for table `catissue_specimen` */

DROP TABLE IF EXISTS `catissue_specimen`;

CREATE TABLE `catissue_specimen` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `LABEL` varchar(255) DEFAULT NULL,
  `AVAILABLE` tinyint(1) DEFAULT NULL,
  `BARCODE` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `COMMENTS` text,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `SPECIMEN_COLLECTION_GROUP_ID` bigint(20) DEFAULT NULL,
  `REQ_SPECIMEN_ID` bigint(20) DEFAULT NULL,
  `AVAILABLE_QUANTITY` double DEFAULT NULL,
  `CREATED_ON_DATE` date DEFAULT NULL,
  `COLLECTION_STATUS` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `LABEL` (`LABEL`),
  UNIQUE KEY `BARCODE` (`BARCODE`),
  KEY `FK1674810433BF33C5` (`SPECIMEN_COLLECTION_GROUP_ID`),
  KEY `FK_REQ_SPECIMEN_ID` (`REQ_SPECIMEN_ID`),
  KEY `INDX_CATISSUE_SPECIMEN_AVQTY` (`AVAILABLE_QUANTITY`),
  CONSTRAINT `FK1674810433BF33C5` FOREIGN KEY (`SPECIMEN_COLLECTION_GROUP_ID`) REFERENCES `catissue_specimen_coll_group` (`IDENTIFIER`),
  CONSTRAINT `FK_PARENT_SPECIMEN` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_abstract_specimen` (`IDENTIFIER`),
  CONSTRAINT `FK_REQ_SPECIMEN_ID` FOREIGN KEY (`REQ_SPECIMEN_ID`) REFERENCES `catissue_cp_req_specimen` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen` */

insert  into `catissue_specimen`(`IDENTIFIER`,`LABEL`,`AVAILABLE`,`BARCODE`,`COMMENTS`,`ACTIVITY_STATUS`,`SPECIMEN_COLLECTION_GROUP_ID`,`REQ_SPECIMEN_ID`,`AVAILABLE_QUANTITY`,`CREATED_ON_DATE`,`COLLECTION_STATUS`) values (2,'1',1,'1',NULL,'Active',2,1,10,'2010-11-10','Collected'),(4,'2',1,'2',NULL,'Active',4,3,10,'2010-11-10','Collected'),(6,'3',1,'3',NULL,'Active',6,5,10,'2010-11-10','Collected');

/*Table structure for table `catissue_specimen_array_type` */

DROP TABLE IF EXISTS `catissue_specimen_array_type`;

CREATE TABLE `catissue_specimen_array_type` (
  `IDENTIFIER` bigint(20) NOT NULL,
  `SPECIMEN_CLASS` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKD36E0B9BBC7298A9` (`IDENTIFIER`),
  CONSTRAINT `FKD36E0B9BBC7298A9` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_container_type` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_array_type` */

insert  into `catissue_specimen_array_type`(`IDENTIFIER`,`SPECIMEN_CLASS`) values (2,NULL);

/*Table structure for table `catissue_specimen_char` */

DROP TABLE IF EXISTS `catissue_specimen_char`;

CREATE TABLE `catissue_specimen_char` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `TISSUE_SITE` varchar(150) DEFAULT NULL,
  `TISSUE_SIDE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `INDX_CATISSUE_SP_CHAR_TSITE` (`TISSUE_SITE`),
  KEY `INDX_CATISSUE_SP_CHAR_TSIDE` (`TISSUE_SIDE`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_char` */

insert  into `catissue_specimen_char`(`IDENTIFIER`,`TISSUE_SITE`,`TISSUE_SIDE`) values (1,'Not Specified','Not Specified'),(2,'Not Specified','Not Specified'),(3,'Not Specified','Not Specified'),(4,'Not Specified','Not Specified'),(5,'Not Specified','Not Specified'),(6,'Not Specified','Not Specified');

/*Table structure for table `catissue_specimen_coll_group` */

DROP TABLE IF EXISTS `catissue_specimen_coll_group`;

CREATE TABLE `catissue_specimen_coll_group` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `COMMENTS` text,
  `ENCOUNTER_TIMESTAMP` datetime DEFAULT NULL,
  `COLLECTION_PROTOCOL_REG_ID` bigint(20) DEFAULT NULL,
  `SURGICAL_PATHOLOGY_NUMBER` varchar(50) DEFAULT NULL,
  `COLLECTION_PROTOCOL_EVENT_ID` bigint(20) DEFAULT NULL,
  `COLLECTION_STATUS` varchar(50) DEFAULT NULL,
  `DATE_OFFSET` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `BARCODE` (`BARCODE`),
  KEY `FKDEBAF1677E07C4AC` (`COLLECTION_PROTOCOL_REG_ID`),
  KEY `FK_COLL_PROT_EVENT_SPEC_COLL_GROUP` (`COLLECTION_PROTOCOL_EVENT_ID`),
  KEY `FKDEBAF16753B01F66` (`COLLECTION_PROTOCOL_EVENT_ID`),
  CONSTRAINT `FKDEBAF16753B01F66` FOREIGN KEY (`COLLECTION_PROTOCOL_EVENT_ID`) REFERENCES `catissue_coll_prot_event` (`IDENTIFIER`),
  CONSTRAINT `FKDEBAF1677E07C4AC` FOREIGN KEY (`COLLECTION_PROTOCOL_REG_ID`) REFERENCES `catissue_coll_prot_reg` (`IDENTIFIER`),
  CONSTRAINT `FK_COLL_PROT_EVENT_SPEC_COLL_GROUP` FOREIGN KEY (`COLLECTION_PROTOCOL_EVENT_ID`) REFERENCES `catissue_coll_prot_event` (`IDENTIFIER`),
  CONSTRAINT `FK_PARENT_SPEC_COLL_GROUP` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_abs_speci_coll_group` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_coll_group` */

insert  into `catissue_specimen_coll_group`(`IDENTIFIER`,`NAME`,`BARCODE`,`COMMENTS`,`ENCOUNTER_TIMESTAMP`,`COLLECTION_PROTOCOL_REG_ID`,`SURGICAL_PATHOLOGY_NUMBER`,`COLLECTION_PROTOCOL_EVENT_ID`,`COLLECTION_STATUS`,`DATE_OFFSET`) values (2,'scg_1','1',NULL,NULL,1,NULL,1,'Pending',NULL),(4,'scg_2','2',NULL,NULL,2,NULL,3,'Pending',NULL),(6,'scg_3','3',NULL,NULL,3,NULL,5,'Pending',NULL);

/*Table structure for table `catissue_specimen_label_count` */

DROP TABLE IF EXISTS `catissue_specimen_label_count`;

CREATE TABLE `catissue_specimen_label_count` (
  `LABEL_COUNT` bigint(20) NOT NULL,
  PRIMARY KEY (`LABEL_COUNT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_label_count` */

insert  into `catissue_specimen_label_count`(`LABEL_COUNT`) values (0);

/*Table structure for table `catissue_specimen_protocol` */

DROP TABLE IF EXISTS `catissue_specimen_protocol`;

CREATE TABLE `catissue_specimen_protocol` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `PRINCIPAL_INVESTIGATOR_ID` bigint(20) DEFAULT NULL,
  `TITLE` varchar(255) NOT NULL,
  `SHORT_TITLE` varchar(255) DEFAULT NULL,
  `IRB_IDENTIFIER` varchar(255) DEFAULT NULL,
  `START_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `ENROLLMENT` int(11) DEFAULT NULL,
  `DESCRIPTION_URL` varchar(255) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `LABEL_FORMAT` varchar(255) DEFAULT NULL,
  `DERIV_LABEL_FORMAT` varchar(255) DEFAULT NULL,
  `ALIQUOT_LABEL_FORMAT` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `TITLE` (`TITLE`),
  KEY `FKB8481373870EB740` (`PRINCIPAL_INVESTIGATOR_ID`),
  KEY `INDX_SP_PR_SHORT_TITLE` (`SHORT_TITLE`),
  KEY `INDX_SP_PR_IRB_ID` (`IRB_IDENTIFIER`),
  KEY `INDX_SP_PR_START_DATE` (`START_DATE`),
  KEY `INDX_SP_PR_END_DATE` (`END_DATE`),
  CONSTRAINT `FKB8481373870EB740` FOREIGN KEY (`PRINCIPAL_INVESTIGATOR_ID`) REFERENCES `catissue_user` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_protocol` */

insert  into `catissue_specimen_protocol`(`IDENTIFIER`,`PRINCIPAL_INVESTIGATOR_ID`,`TITLE`,`SHORT_TITLE`,`IRB_IDENTIFIER`,`START_DATE`,`END_DATE`,`ENROLLMENT`,`DESCRIPTION_URL`,`ACTIVITY_STATUS`,`LABEL_FORMAT`,`DERIV_LABEL_FORMAT`,`ALIQUOT_LABEL_FORMAT`) values (1,11,'CP','CP1',NULL,NULL,NULL,NULL,NULL,'Active',NULL,NULL,NULL),(2,12,'CP2','CP2',NULL,NULL,NULL,NULL,NULL,'Active',NULL,NULL,NULL);

/*Table structure for table `catissue_specimen_requirement` */

DROP TABLE IF EXISTS `catissue_specimen_requirement`;

CREATE TABLE `catissue_specimen_requirement` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `SPECIMEN_CLASS` varchar(255) NOT NULL,
  `SPECIMEN_TYPE` varchar(50) DEFAULT NULL,
  `TISSUE_SITE` varchar(150) DEFAULT NULL,
  `PATHOLOGY_STATUS` varchar(50) DEFAULT NULL,
  `QUANTITY_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_requirement` */

/*Table structure for table `catissue_specimen_type` */

DROP TABLE IF EXISTS `catissue_specimen_type`;

CREATE TABLE `catissue_specimen_type` (
  `SPECIMEN_ARRAY_TYPE_ID` bigint(20) NOT NULL,
  `SPECIMEN_TYPE` varchar(50) DEFAULT NULL,
  KEY `FKFF69C195ECE89343` (`SPECIMEN_ARRAY_TYPE_ID`),
  CONSTRAINT `FKFF69C195ECE89343` FOREIGN KEY (`SPECIMEN_ARRAY_TYPE_ID`) REFERENCES `catissue_specimen_array_type` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_specimen_type` */

/*Table structure for table `catissue_storage_type` */

DROP TABLE IF EXISTS `catissue_storage_type`;

CREATE TABLE `catissue_storage_type` (
  `IDENTIFIER` bigint(20) NOT NULL,
  `DEFAULT_TEMPERATURE` double DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKE9A0629ABC7298A9` (`IDENTIFIER`),
  CONSTRAINT `FKE9A0629ABC7298A9` FOREIGN KEY (`IDENTIFIER`) REFERENCES `catissue_container_type` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_storage_type` */

insert  into `catissue_storage_type`(`IDENTIFIER`,`DEFAULT_TEMPERATURE`) values (1,NULL),(3,-80);

/*Table structure for table `catissue_storty_holds_sparrty` */

DROP TABLE IF EXISTS `catissue_storty_holds_sparrty`;

CREATE TABLE `catissue_storty_holds_sparrty` (
  `STORAGE_TYPE_ID` bigint(20) NOT NULL,
  `SPECIMEN_ARRAY_TYPE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`STORAGE_TYPE_ID`,`SPECIMEN_ARRAY_TYPE_ID`),
  KEY `STORAGE_TYPE_ID` (`STORAGE_TYPE_ID`),
  KEY `SPECIMEN_ARRAY_TYPE_ID` (`SPECIMEN_ARRAY_TYPE_ID`),
  CONSTRAINT `FK70F57E4459A3CE5C` FOREIGN KEY (`STORAGE_TYPE_ID`) REFERENCES `catissue_storage_type` (`IDENTIFIER`),
  CONSTRAINT `FK70F57E44ECE89343` FOREIGN KEY (`SPECIMEN_ARRAY_TYPE_ID`) REFERENCES `catissue_specimen_array_type` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `catissue_storty_holds_sparrty` */

/*Table structure for table `catissue_table_relation` */

DROP TABLE IF EXISTS `catissue_table_relation`;

CREATE TABLE `catissue_table_relation` (
  `RELATIONSHIP_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PARENT_TABLE_ID` bigint(20) DEFAULT NULL,
  `CHILD_TABLE_ID` bigint(20) DEFAULT NULL,
  `TABLES_IN_PATH` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RELATIONSHIP_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_table_relation` */

insert  into `catissue_table_relation`(`RELATIONSHIP_ID`,`PARENT_TABLE_ID`,`CHILD_TABLE_ID`,`TABLES_IN_PATH`) values (1,1,1,NULL),(2,6,6,NULL),(3,5,5,NULL),(4,7,7,NULL),(5,8,8,NULL),(6,3,3,NULL),(7,3,4,NULL),(8,21,21,NULL),(9,21,2,'70'),(10,21,69,'1'),(11,21,3,NULL),(12,10,10,NULL),(13,10,9,NULL),(14,10,11,NULL),(15,10,12,'11:18'),(16,10,18,'11'),(17,19,19,NULL),(18,19,9,NULL),(19,19,20,NULL),(21,23,23,NULL),(23,23,4,NULL),(24,23,5,NULL),(25,23,6,NULL),(26,23,7,NULL),(27,31,31,NULL),(28,31,32,NULL),(29,27,27,NULL),(30,35,35,NULL),(31,35,11,NULL),(32,35,3,NULL),(33,35,27,NULL),(34,33,33,NULL),(35,33,34,NULL),(36,38,38,NULL),(37,38,37,NULL),(40,10,23,'9'),(41,10,17,NULL),(43,19,23,'9'),(44,31,3,'32'),(45,27,9,'10'),(46,27,31,NULL),(47,35,26,NULL),(48,35,9,'27:10'),(50,33,28,NULL),(52,38,100,'37'),(53,38,9,NULL),(54,35,31,'27'),(55,38,34,'37:33'),(57,43,43,NULL),(58,43,63,NULL),(59,43,23,NULL),(60,44,44,NULL),(61,44,63,NULL),(62,44,23,NULL),(63,46,46,NULL),(64,46,63,NULL),(65,46,23,NULL),(66,47,47,NULL),(67,47,63,NULL),(68,47,23,NULL),(69,48,48,NULL),(70,48,63,NULL),(71,48,23,NULL),(72,49,49,NULL),(73,49,63,NULL),(74,49,23,NULL),(75,50,50,NULL),(76,50,63,NULL),(77,50,23,NULL),(78,51,51,NULL),(79,51,63,NULL),(80,51,23,NULL),(81,52,52,NULL),(82,52,63,NULL),(83,52,23,NULL),(84,54,54,NULL),(85,54,63,NULL),(86,54,23,NULL),(87,57,57,NULL),(88,57,63,NULL),(89,57,23,NULL),(90,64,64,NULL),(91,64,63,NULL),(92,64,23,NULL),(93,66,66,NULL),(94,66,63,NULL),(95,66,23,NULL),(96,67,67,NULL),(97,67,63,NULL),(98,67,23,NULL),(99,68,68,NULL),(100,68,63,NULL),(101,68,23,NULL),(102,59,59,NULL),(103,31,10,'27'),(104,10,35,'27'),(105,62,8,NULL),(106,33,8,'62'),(107,23,63,NULL),(108,1,69,NULL),(110,21,70,NULL),(111,71,71,NULL),(112,71,69,NULL),(113,72,72,NULL),(114,72,70,NULL),(115,72,2,'70'),(116,72,69,'71'),(121,75,72,'37'),(122,75,75,NULL),(123,75,3,NULL),(124,75,9,NULL),(125,75,69,'37:72:71'),(127,75,70,'37:72'),(129,72,71,NULL),(130,21,1,NULL),(131,75,37,NULL),(132,78,79,NULL),(133,78,80,NULL),(134,81,82,NULL),(135,81,83,NULL),(136,81,84,NULL),(137,35,92,NULL),(138,94,93,NULL),(139,95,93,NULL),(140,33,94,NULL),(141,72,95,'70'),(142,21,95,'70'),(143,94,94,NULL),(144,95,95,NULL),(145,21,94,NULL),(146,33,100,NULL),(147,33,99,NULL);

/*Table structure for table `catissue_user` */

DROP TABLE IF EXISTS `catissue_user`;

CREATE TABLE `catissue_user` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `LOGIN_NAME` varchar(255) NOT NULL,
  `START_DATE` date DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(50) DEFAULT NULL,
  `DEPARTMENT_ID` bigint(20) DEFAULT NULL,
  `CANCER_RESEARCH_GROUP_ID` bigint(20) DEFAULT NULL,
  `INSTITUTION_ID` bigint(20) DEFAULT NULL,
  `ADDRESS_ID` bigint(20) DEFAULT NULL,
  `CSM_USER_ID` bigint(20) DEFAULT NULL,
  `STATUS_COMMENT` text,
  `FIRST_TIME_LOGIN` bit(1) DEFAULT b'1',
  PRIMARY KEY (`IDENTIFIER`),
  UNIQUE KEY `LOGIN_NAME` (`LOGIN_NAME`),
  KEY `FKB025CFC71792AD22` (`INSTITUTION_ID`),
  KEY `FKB025CFC7FFA96920` (`CANCER_RESEARCH_GROUP_ID`),
  KEY `FKB025CFC76CD94566` (`ADDRESS_ID`),
  KEY `FKB025CFC7F30C2528` (`DEPARTMENT_ID`),
  KEY `INDX_USER_LNAME` (`LAST_NAME`),
  KEY `INDX_USER_FNAME` (`FIRST_NAME`),
  CONSTRAINT `FKB025CFC71792AD22` FOREIGN KEY (`INSTITUTION_ID`) REFERENCES `catissue_institution` (`IDENTIFIER`),
  CONSTRAINT `FKB025CFC76CD94566` FOREIGN KEY (`ADDRESS_ID`) REFERENCES `catissue_address` (`IDENTIFIER`),
  CONSTRAINT `FKB025CFC7F30C2528` FOREIGN KEY (`DEPARTMENT_ID`) REFERENCES `catissue_department` (`IDENTIFIER`),
  CONSTRAINT `FKB025CFC7FFA96920` FOREIGN KEY (`CANCER_RESEARCH_GROUP_ID`) REFERENCES `catissue_cancer_research_group` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `catissue_user` */

insert  into `catissue_user`(`IDENTIFIER`,`EMAIL_ADDRESS`,`FIRST_NAME`,`LAST_NAME`,`LOGIN_NAME`,`START_DATE`,`ACTIVITY_STATUS`,`DEPARTMENT_ID`,`CANCER_RESEARCH_GROUP_ID`,`INSTITUTION_ID`,`ADDRESS_ID`,`CSM_USER_ID`,`STATUS_COMMENT`,`FIRST_TIME_LOGIN`) values (1,'admin@admin.com','Admin','Admin','admin@admin.com',NULL,'Active',1,1,1,1,1,NULL,''),(10,'catissuecsm','catissue','csm','catissuecsm',NULL,'Active',1,1,1,1,10,NULL,''),(11,'catissuecsm1','catissue','csm','catissuecsm1',NULL,'Active',1,1,1,1,11,NULL,''),(12,'pooja','catissue','csm','pooja',NULL,'Active',1,1,1,1,12,NULL,'');

/*Table structure for table `commons_graph` */

DROP TABLE IF EXISTS `commons_graph`;

CREATE TABLE `commons_graph` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `commons_graph` */

/*Table structure for table `commons_graph_edge` */

DROP TABLE IF EXISTS `commons_graph_edge`;

CREATE TABLE `commons_graph_edge` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `SOURCE_VERTEX_CLASS` varchar(255) DEFAULT NULL,
  `SOURCE_VERTEX_ID` bigint(20) DEFAULT NULL,
  `TARGET_VERTEX_CLASS` varchar(255) DEFAULT NULL,
  `TARGET_VERTEX_ID` bigint(20) DEFAULT NULL,
  `EDGE_CLASS` varchar(255) DEFAULT NULL,
  `EDGE_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `commons_graph_edge` */

/*Table structure for table `commons_graph_to_edges` */

DROP TABLE IF EXISTS `commons_graph_to_edges`;

CREATE TABLE `commons_graph_to_edges` (
  `GRAPH_ID` bigint(20) NOT NULL,
  `EDGE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`GRAPH_ID`,`EDGE_ID`),
  UNIQUE KEY `EDGE_ID` (`EDGE_ID`),
  KEY `FKA6B0D8BAA0494B1D` (`GRAPH_ID`),
  KEY `FKA6B0D8BAFAEF80D` (`EDGE_ID`),
  CONSTRAINT `FKA6B0D8BAA0494B1D` FOREIGN KEY (`GRAPH_ID`) REFERENCES `commons_graph` (`IDENTIFIER`),
  CONSTRAINT `FKA6B0D8BAFAEF80D` FOREIGN KEY (`EDGE_ID`) REFERENCES `commons_graph_edge` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `commons_graph_to_edges` */

/*Table structure for table `commons_graph_to_vertices` */

DROP TABLE IF EXISTS `commons_graph_to_vertices`;

CREATE TABLE `commons_graph_to_vertices` (
  `GRAPH_ID` bigint(20) NOT NULL,
  `VERTEX_CLASS` varchar(255) DEFAULT NULL,
  `VERTEX_ID` bigint(20) DEFAULT NULL,
  KEY `FK2C4412F5A0494B1D` (`GRAPH_ID`),
  CONSTRAINT `FK2C4412F5A0494B1D` FOREIGN KEY (`GRAPH_ID`) REFERENCES `commons_graph` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `commons_graph_to_vertices` */

/*Table structure for table `csm_application` */

DROP TABLE IF EXISTS `csm_application`;

CREATE TABLE `csm_application` (
  `APPLICATION_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `APPLICATION_NAME` varchar(255) NOT NULL DEFAULT '',
  `APPLICATION_DESCRIPTION` varchar(200) NOT NULL DEFAULT '',
  `DECLARATIVE_FLAG` tinyint(1) DEFAULT NULL,
  `ACTIVE_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date NOT NULL DEFAULT '0000-00-00',
  `DATABASE_URL` varchar(100) DEFAULT NULL,
  `DATABASE_USER_NAME` varchar(100) DEFAULT NULL,
  `DATABASE_PASSWORD` varchar(100) DEFAULT NULL,
  `DATABASE_DIALECT` varchar(100) DEFAULT NULL,
  `DATABASE_DRIVER` varchar(100) DEFAULT NULL,
  `CSM_VERSION` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`APPLICATION_ID`),
  UNIQUE KEY `UQ_APPLICATION_NAME` (`APPLICATION_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `csm_application` */

insert  into `csm_application`(`APPLICATION_ID`,`APPLICATION_NAME`,`APPLICATION_DESCRIPTION`,`DECLARATIVE_FLAG`,`ACTIVE_FLAG`,`UPDATE_DATE`,`DATABASE_URL`,`DATABASE_USER_NAME`,`DATABASE_PASSWORD`,`DATABASE_DIALECT`,`DATABASE_DRIVER`,`CSM_VERSION`) values (1,'catissuecore','caTISSUE Core',0,0,'2005-08-22',NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `csm_filter_clause` */

DROP TABLE IF EXISTS `csm_filter_clause`;

CREATE TABLE `csm_filter_clause` (
  `FILTER_CLAUSE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLASS_NAME` varchar(100) NOT NULL,
  `FILTER_CHAIN` varchar(2000) NOT NULL,
  `TARGET_CLASS_NAME` varchar(100) NOT NULL,
  `TARGET_CLASS_ATTRIBUTE_NAME` varchar(100) NOT NULL,
  `TARGET_CLASS_ATTRIBUTE_TYPE` varchar(100) NOT NULL,
  `TARGET_CLASS_ALIAS` varchar(100) DEFAULT NULL,
  `TARGET_CLASS_ATTRIBUTE_ALIAS` varchar(100) DEFAULT NULL,
  `GENERATED_SQL_USER` varchar(4000) NOT NULL,
  `APPLICATION_ID` bigint(20) NOT NULL,
  `UPDATE_DATE` date NOT NULL,
  `GENERATED_SQL_GROUP` varchar(4000) NOT NULL,
  PRIMARY KEY (`FILTER_CLAUSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

/*Data for the table `csm_filter_clause` */

insert  into `csm_filter_clause`(`FILTER_CLAUSE_ID`,`CLASS_NAME`,`FILTER_CHAIN`,`TARGET_CLASS_NAME`,`TARGET_CLASS_ATTRIBUTE_NAME`,`TARGET_CLASS_ATTRIBUTE_TYPE`,`TARGET_CLASS_ALIAS`,`TARGET_CLASS_ATTRIBUTE_ALIAS`,`GENERATED_SQL_USER`,`APPLICATION_ID`,`UPDATE_DATE`,`GENERATED_SQL_GROUP`) values (31,'edu.wustl.catissuecore.domain.CollectionProtocol','edu.wustl.catissuecore.domain.CollectionProtocol','edu.wustl.catissuecore.domain.CollectionProtocol - self','id','java.lang.Long','','','IDENTIFIER in (select table_name_csm_.IDENTIFIER   from CATISSUE_COLLECTION_PROTOCOL table_name_csm_ where table_name_csm_.CP_TYPE in ( select pe.attribute_value from csm_protection_group pg, csm_protection_element pe, csm_pg_pe pgpe, csm_user_group_role_pg ugrpg, csm_user u, csm_role_privilege rp, csm_role r, csm_privilege p where ugrpg.role_id = r.role_id and ugrpg.user_id = u.user_id and ugrpg.protection_group_id = ANY (select pg1.protection_group_id from csm_protection_group pg1 where pg1.protection_group_id = pg.protection_group_id or pg1.protection_group_id = (select pg2.parent_protection_group_id from csm_protection_group pg2 where pg2.protection_group_id = pg.protection_group_id)) and pg.protection_group_id = pgpe.protection_group_id and pgpe.protection_element_id = pe.protection_element_id and r.role_id = rp.role_id and rp.privilege_id = p.privilege_id and pe.object_id= \'edu.wustl.catissuecore.domain.CollectionProtocol\' and pe.attribute=\'type\' and p.privilege_name=\'READ\' and u.login_name=:USER_NAME and pe.application_id=:APPLICATION_ID))',1,'2011-02-01','IDENTIFIER in (select table_name_csm_.IDENTIFIER   from CATISSUE_COLLECTION_PROTOCOL table_name_csm_ where table_name_csm_.CP_TYPE in ( select pe.attribute_value from csm_protection_group pg, csm_protection_element pe, csm_pg_pe pgpe, csm_user_group_role_pg ugrpg, csm_user u, csm_role_privilege rp, csm_role r, csm_privilege p where ugrpg.role_id = r.role_id and ugrpg.user_id = u.user_id and ugrpg.protection_group_id = ANY (select pg1.protection_group_id from csm_protection_group pg1 where pg1.protection_group_id = pg.protection_group_id or pg1.protection_group_id = (select pg2.parent_protection_group_id from csm_protection_group pg2 where pg2.protection_group_id = pg.protection_group_id)) and pg.protection_group_id = pgpe.protection_group_id and pgpe.protection_element_id = pe.protection_element_id and r.role_id = rp.role_id and rp.privilege_id = p.privilege_id and pe.object_id= \'edu.wustl.catissuecore.domain.CollectionProtocol\' and pe.attribute=\'type\' and p.privilege_name=\'READ\' and u.login_name=:USER_NAME and pe.application_id=:APPLICATION_ID))'),(33,'edu.wustl.catissuecore.domain.AbstractSpecimen','specimenCollectionGroup, collectionProtocolRegistration, collectionProtocol','edu.wustl.catissuecore.domain.CollectionProtocal - collectionProtocol','id','java.lang.Long','','','IDENTIFIER in (select table_name_csm_.IDENTIFIER   from catissue_specimen table_name_csm_ inner join catissue_specimen_coll_group group1_ on table_name_csm_.SPECIMEN_COLLECTION_GROUP_ID=group1_.IDENTIFIER inner join catissue_coll_prot_reg reg2_ on group1_.COLLECTION_PROTOCOL_REG_ID=reg2_.IDENTIFIER inner join catissue_collection_protocol proto3_ on reg2_.COLLECTION_PROTOCOL_ID=proto3_.IDENTIFIER where proto3_.CP_TYPE in ( select pe.attribute_value from csm_protection_group pg, csm_protection_element pe, csm_pg_pe pgpe, csm_user_group_role_pg ugrpg, csm_user u, csm_role_privilege rp, csm_role r, csm_privilege p where ugrpg.role_id = r.role_id and ugrpg.user_id = u.user_id and ugrpg.protection_group_id = ANY (select pg1.protection_group_id from csm_protection_group pg1 where pg1.protection_group_id = pg.protection_group_id or pg1.protection_group_id = (select pg2.parent_protection_group_id from csm_protection_group pg2 where pg2.protection_group_id = pg.protection_group_id)) and pg.protection_group_id = pgpe.protection_group_id and pgpe.protection_element_id = pe.protection_element_id and r.role_id = rp.role_id and rp.privilege_id = p.privilege_id and pe.object_id= \'edu.wustl.catissuecore.domain.CollectionProtocol\' and pe.attribute=\'type\' and p.privilege_name=\'READ\' and u.login_name=:USER_NAME and pe.application_id=:APPLICATION_ID))',1,'2011-02-02','IDENTIFIER in (select table_name_csm_.IDENTIFIER   from catissue_specimen table_name_csm_ inner join catissue_specimen_coll_group group1_ on table_name_csm_.SPECIMEN_COLLECTION_GROUP_ID=group1_.IDENTIFIER inner join catissue_coll_prot_reg reg2_ on group1_.COLLECTION_PROTOCOL_REG_ID=reg2_.IDENTIFIER inner join catissue_collection_protocol proto3_ on reg2_.COLLECTION_PROTOCOL_ID=proto3_.IDENTIFIER where proto3_.CP_TYPE in ( select pe.attribute_value from csm_protection_group pg, csm_protection_element pe, csm_pg_pe pgpe, csm_user_group_role_pg ugrpg, csm_user u, csm_role_privilege rp, csm_role r, csm_privilege p where ugrpg.role_id = r.role_id and ugrpg.user_id = u.user_id and ugrpg.protection_group_id = ANY (select pg1.protection_group_id from csm_protection_group pg1 where pg1.protection_group_id = pg.protection_group_id or pg1.protection_group_id = (select pg2.parent_protection_group_id from csm_protection_group pg2 where pg2.protection_group_id = pg.protection_group_id)) and pg.protection_group_id = pgpe.protection_group_id and pgpe.protection_element_id = pe.protection_element_id and r.role_id = rp.role_id and rp.privilege_id = p.privilege_id and pe.object_id= \'edu.wustl.catissuecore.domain.CollectionProtocol\' and pe.attribute=\'type\' and p.privilege_name=\'READ\' and u.login_name=:USER_NAME and pe.application_id=:APPLICATION_ID))');

/*Table structure for table `csm_group` */

DROP TABLE IF EXISTS `csm_group`;

CREATE TABLE `csm_group` (
  `GROUP_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `GROUP_NAME` varchar(255) NOT NULL DEFAULT '',
  `GROUP_DESC` varchar(200) DEFAULT NULL,
  `UPDATE_DATE` date NOT NULL DEFAULT '2005-01-01',
  `APPLICATION_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`GROUP_ID`),
  UNIQUE KEY `UQ_GROUP_GROUP_NAME` (`APPLICATION_ID`,`GROUP_NAME`),
  KEY `idx_APPLICATION_ID` (`APPLICATION_ID`),
  CONSTRAINT `csm_group_ibfk_1` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `csm_group` */

insert  into `csm_group`(`GROUP_ID`,`GROUP_NAME`,`GROUP_DESC`,`UPDATE_DATE`,`APPLICATION_ID`) values (1,'ADMINISTRATOR_GROUP','Group of Administrators','2005-01-01',1),(2,'SUPERVISOR_GROUP','Group of Supervisors','2005-01-01',1),(3,'TECHNICIAN_GROUP','Group of Technicians','2005-01-01',1),(4,'PUBLIC_GROUP','Group of Public Users','2005-01-01',1);

/*Table structure for table `csm_mapping` */

DROP TABLE IF EXISTS `csm_mapping`;

CREATE TABLE `csm_mapping` (
  `MAPPING_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `APPLICATION_ID` bigint(20) NOT NULL,
  `OBJECT_NAME` varchar(100) NOT NULL,
  `ATTRIBUTE_NAME` varchar(100) NOT NULL,
  `OBJECT_PACKAGE_NAME` varchar(100) DEFAULT NULL,
  `TABLE_NAME` varchar(100) DEFAULT NULL,
  `TABLE_NAME_GROUP` varchar(100) DEFAULT NULL,
  `TABLE_NAME_USER` varchar(100) DEFAULT NULL,
  `VIEW_NAME_GROUP` varchar(100) DEFAULT NULL,
  `VIEW_NAME_USER` varchar(100) DEFAULT NULL,
  `ACTIVE_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `MAINTAINED_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date DEFAULT '0000-00-00',
  PRIMARY KEY (`MAPPING_ID`),
  UNIQUE KEY `UQ_MP_OBJ_NAME_ATTRI_NAME_APP_ID` (`OBJECT_NAME`,`ATTRIBUTE_NAME`,`APPLICATION_ID`),
  KEY `FK_PE_APPLICATION` (`APPLICATION_ID`),
  CONSTRAINT `FK_PE_APPLICATION` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `csm_mapping` */

/*Table structure for table `csm_migrate_user` */

DROP TABLE IF EXISTS `csm_migrate_user`;

CREATE TABLE `csm_migrate_user` (
  `LOGIN_NAME` varchar(100) NOT NULL,
  `TARGET_IDP_NAME` varchar(100) DEFAULT NULL,
  `MIGRATED_LOGIN_NAME` varchar(100) DEFAULT NULL,
  `MIGRATION_STATUS` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`LOGIN_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `csm_migrate_user` */

/*Table structure for table `csm_pg_pe` */

DROP TABLE IF EXISTS `csm_pg_pe`;

CREATE TABLE `csm_pg_pe` (
  `PG_PE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PROTECTION_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `PROTECTION_ELEMENT_ID` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date DEFAULT '0000-00-00',
  PRIMARY KEY (`PG_PE_ID`),
  UNIQUE KEY `UQ_PROTECTION_GROUP_PROTECTION_ELEMENT_PROTECTION_GROUP_ID` (`PROTECTION_ELEMENT_ID`,`PROTECTION_GROUP_ID`),
  KEY `idx_PROTECTION_ELEMENT_ID` (`PROTECTION_ELEMENT_ID`),
  KEY `idx_PROTECTION_GROUP_ID` (`PROTECTION_GROUP_ID`),
  CONSTRAINT `csm_pg_pe_ibfk_1` FOREIGN KEY (`PROTECTION_ELEMENT_ID`) REFERENCES `csm_protection_element` (`PROTECTION_ELEMENT_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_pg_pe_ibfk_2` FOREIGN KEY (`PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=436 DEFAULT CHARSET=latin1;

/*Data for the table `csm_pg_pe` */

insert  into `csm_pg_pe`(`PG_PE_ID`,`PROTECTION_GROUP_ID`,`PROTECTION_ELEMENT_ID`,`UPDATE_DATE`) values (16,21,9,NULL),(17,2,10,NULL),(19,2,11,NULL),(20,2,12,NULL),(21,2,13,NULL),(22,2,14,NULL),(23,3,15,NULL),(24,3,16,NULL),(25,3,17,NULL),(26,3,18,NULL),(27,3,19,NULL),(28,1,20,NULL),(29,3,21,NULL),(30,3,22,NULL),(31,3,23,NULL),(32,3,24,NULL),(33,3,25,NULL),(34,3,26,NULL),(35,3,27,NULL),(36,3,28,NULL),(37,3,29,NULL),(38,3,30,NULL),(39,3,31,NULL),(40,3,32,NULL),(41,3,33,NULL),(42,3,34,NULL),(43,3,35,NULL),(44,3,36,NULL),(45,3,37,NULL),(46,3,38,NULL),(47,3,39,NULL),(48,3,40,NULL),(49,1,41,NULL),(50,1,42,NULL),(51,1,43,NULL),(52,1,44,NULL),(53,1,45,NULL),(54,1,46,NULL),(55,1,47,NULL),(56,1,48,NULL),(58,1,50,NULL),(59,1,51,NULL),(60,3,52,NULL),(61,3,53,NULL),(299,1,269,NULL),(302,1,272,NULL),(306,1,276,NULL),(312,3,281,NULL),(330,1,54,NULL),(331,1,55,NULL),(332,1,56,NULL),(335,44,304,'2007-01-04'),(336,44,305,'2007-01-04'),(337,44,306,'2007-01-04'),(338,44,307,'2007-01-04'),(339,44,308,'2007-01-04'),(340,44,309,'2007-01-04'),(341,44,310,'2007-01-04'),(342,44,311,'2007-01-04'),(343,44,312,'2007-01-04'),(344,44,313,'2007-01-04'),(348,1,304,'2006-11-27'),(349,2,304,'2006-11-27'),(350,3,304,'2006-11-27'),(351,1,305,'2006-11-27'),(352,2,305,'2006-11-27'),(353,3,305,'2006-11-27'),(354,1,306,'2006-11-27'),(355,2,306,'2006-11-27'),(356,3,306,'2006-11-27'),(357,1,307,'2006-11-27'),(358,2,307,'2006-11-27'),(359,3,307,'2006-11-27'),(360,1,308,'2006-11-27'),(361,2,308,'2006-11-27'),(362,3,308,'2006-11-27'),(363,1,309,'2006-11-27'),(364,2,309,'2006-11-27'),(365,3,309,'2006-11-27'),(366,1,310,'2006-11-27'),(367,2,310,'2006-11-27'),(368,3,310,'2006-11-27'),(369,1,311,'2006-11-27'),(370,2,311,'2006-11-27'),(371,3,311,'2006-11-27'),(372,1,312,'2006-11-27'),(373,2,312,'2006-11-27'),(374,3,312,'2006-11-27'),(375,1,313,'2006-11-27'),(376,2,313,'2006-11-27'),(377,3,313,'2006-11-27'),(378,1,300,'2006-11-27'),(379,2,300,'2006-11-27'),(380,3,300,'2006-11-27'),(381,1,301,'2006-11-27'),(382,2,301,'2006-11-27'),(383,3,301,'2006-11-27'),(384,1,302,'2006-11-27'),(385,2,302,'2006-11-27'),(386,3,302,'2006-11-27'),(387,3,303,'2007-01-18'),(388,1,315,'2006-11-27'),(389,1,316,'2006-11-27'),(390,1,317,'2006-11-27'),(391,1,318,'2006-11-27'),(392,1,319,'2006-11-27'),(399,1,326,'2008-05-28'),(400,1,327,'2008-05-28'),(401,1,328,'2008-05-28'),(402,1,329,'2008-05-28'),(403,1,330,'2008-05-28'),(404,1,331,'2008-05-28'),(405,1,332,'2008-05-28'),(406,1,333,'2008-05-28'),(407,1,334,'2008-05-28'),(408,1,335,'2008-05-28'),(409,1,336,'2008-07-22'),(412,46,1004,'0000-00-00'),(418,56,1010,'0000-00-00'),(420,58,1012,'0000-00-00'),(434,64,1026,'0000-00-00'),(435,65,1027,'0000-00-00');

/*Table structure for table `csm_privilege` */

DROP TABLE IF EXISTS `csm_privilege`;

CREATE TABLE `csm_privilege` (
  `PRIVILEGE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PRIVILEGE_NAME` varchar(100) NOT NULL DEFAULT '',
  `PRIVILEGE_DESCRIPTION` varchar(200) DEFAULT NULL,
  `UPDATE_DATE` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`PRIVILEGE_ID`),
  UNIQUE KEY `UQ_PRIVILEGE_NAME` (`PRIVILEGE_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

/*Data for the table `csm_privilege` */

insert  into `csm_privilege`(`PRIVILEGE_ID`,`PRIVILEGE_NAME`,`PRIVILEGE_DESCRIPTION`,`UPDATE_DATE`) values (1,'CREATE','This privilege grants permission to a user to create an entity. This entity can be an object, a database entry, or a resource such as a network connection','2005-08-22'),(2,'ACCESS','This privilege allows a user to access a particular resource.  Examples of resources include a network or database connection, socket, module of the application, or even the application itself','2005-08-22'),(3,'READ','This privilege permits the user to read data from a file, URL, database, an object, etc. This can be used at an entity level signifying that the user is allowed to read data about a particular entry','2005-08-22'),(4,'WRITE','This privilege allows a user to write data to a file, URL, database, an object, etc. This can be used at an entity level signifying that the user is allowed to write data about a particular entity','2005-08-22'),(5,'UPDATE','This privilege grants permission at an entity level and signifies that the user is allowed to update data for a particular entity. Entities may include an object, object attribute, database row etc','2005-08-22'),(6,'DELETE','This privilege permits a user to delete a logical entity. This entity can be an object, a database entry, a resource such as a network connection, etc','2005-08-22'),(7,'EXECUTE','This privilege allows a user to execute a particular resource. The resource can be a method, function, behavior of the application, URL, button etc','2005-08-22'),(8,'USE','This privilege allows a user to use a particular resource','2005-08-22'),(9,'ASSIGN_READ','This privilege allows a user to assign a read privilege to others','2005-08-22'),(10,'ASSIGN_USE','This privilege allows a user to assign a use privilege to others','2005-08-22'),(11,'IDENTIFIED_DATA_ACCESS','This privilege allows a user to view identified data of an object','2005-08-22'),(12,'READ_DENIED','This privilege doesnt permit the user to read data','2005-08-22'),(13,'USER_PROVISIONING','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR USER CREATION AND ASSIGNING PRIVILEGES TO THAT USER','2008-06-19'),(14,'REPOSITORY_ADMINISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT SITES','2008-06-19'),(15,'STORAGE_ADMINISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT STORAGE TYPES AND CONTAINERS','2008-06-19'),(16,'PROTOCOL_ADMINISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT COLLECTION AS WELL AS DISTRIBUTION PROTOCOLS','2008-06-19'),(17,'DEFINE_ANNOTATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT ANNOTATIONS','2008-06-19'),(18,'REGISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR REGISTERING PARTICIPANT AND CONSENTS','2008-06-19'),(20,'SPECIMEN_ACCESSION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT SPECIMEN,SPECIMEN COLLECTION GROUP AND CONSENTS','2008-06-19'),(21,'DISTRIBUTION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR DISTRIBUTION','2008-06-19'),(22,'QUERY','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR QUERY','2008-06-19'),(23,'PHI_ACCESS','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR VIEWING PHI DATA','2008-06-19'),(24,'PARTICIPANT_SCG_ANNOTATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT ANNOTATION TO PARTICIPANT OR SCG','2008-06-19'),(25,'SPECIMEN_ANNOTATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR FOR ADD EDIT SPECIMEN ANNOTATION','2008-06-19'),(26,'SPECIMEN_PROCESSING','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT ALIQUOT, DERIVATIVE, EVENTS','2008-06-19'),(27,'SPECIMEN_STORAGE','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT STORAGE AND TRANSFER EVENTS','2008-06-19'),(28,'GENERAL_SITE_ADMINISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT SITES','2008-06-19'),(29,'GENERAL_ADMINISTRATION','THIS PRIVILEGE GRANTS PERMISSION TO A USER FOR ADD EDIT DEPARTMENT,INSTITUTION,CANCER RESEARCH GROUP','2008-06-19'),(30,'SHIPMENT_PROCESSING','THIS PRIVILEGE GRANTS PERMISSION TO A USER TO PROCESS SHIPMENTS','2008-08-20');

/*Table structure for table `csm_protection_element` */

DROP TABLE IF EXISTS `csm_protection_element`;

CREATE TABLE `csm_protection_element` (
  `PROTECTION_ELEMENT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PROTECTION_ELEMENT_NAME` varchar(100) NOT NULL DEFAULT '',
  `PROTECTION_ELEMENT_DESCRIPTION` varchar(200) DEFAULT NULL,
  `OBJECT_ID` varchar(100) NOT NULL DEFAULT '',
  `ATTRIBUTE` varchar(100) DEFAULT NULL,
  `PROTECTION_ELEMENT_TYPE` varchar(100) DEFAULT NULL,
  `APPLICATION_ID` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date NOT NULL DEFAULT '2005-01-01',
  `ATTRIBUTE_VALUE` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PROTECTION_ELEMENT_ID`),
  UNIQUE KEY `UQ_PE_OBJECT_ID_ATTRIBUTE_APP_ID` (`PROTECTION_ELEMENT_NAME`,`ATTRIBUTE`,`APPLICATION_ID`),
  UNIQUE KEY `UQ_PE_PE_NAME_ATTRIBUTE_VALUE_APP_ID` (`OBJECT_ID`,`ATTRIBUTE`,`ATTRIBUTE_VALUE`,`APPLICATION_ID`),
  KEY `idx_APPLICATION_ID` (`APPLICATION_ID`),
  CONSTRAINT `csm_protection_element_ibfk_1` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1028 DEFAULT CHARSET=latin1;

/*Data for the table `csm_protection_element` */

insert  into `csm_protection_element`(`PROTECTION_ELEMENT_ID`,`PROTECTION_ELEMENT_NAME`,`PROTECTION_ELEMENT_DESCRIPTION`,`OBJECT_ID`,`ATTRIBUTE`,`PROTECTION_ELEMENT_TYPE`,`APPLICATION_ID`,`UPDATE_DATE`,`ATTRIBUTE_VALUE`) values (9,'edu.wustl.catissuecore.domain.User_1','User class','edu.wustl.catissuecore.domain.User_1',NULL,NULL,1,'2005-01-01',NULL),(10,'Participant','Participant class','edu.wustl.catissuecore.domain.Participant',NULL,NULL,1,'2005-01-01',NULL),(11,'ParticipantMedicalIdentifier','ParticipantMedicalIdentifier class','edu.wustl.catissuecore.domain.ParticipantMedicalIdentifier',NULL,NULL,1,'2005-01-01',NULL),(12,'ClinicalReport','ClinicalReport class','edu.wustl.catissuecore.domain.ClinicalReport',NULL,NULL,1,'2005-01-01',NULL),(13,'SpecimenCollectionGroup','SpecimenCollectionGroup class','edu.wustl.catissuecore.domain.SpecimenCollectionGroup',NULL,NULL,1,'2005-01-01',NULL),(14,'CollectionProtocolRegistration','CollectionProtocolRegistration class','edu.wustl.catissuecore.domain.CollectionProtocolRegistration',NULL,NULL,1,'2005-01-01',NULL),(15,'SpecimenCharacteristics','SpecimenCharacteristics class','edu.wustl.catissuecore.domain.SpecimenCharacteristics',NULL,NULL,1,'2005-01-01',NULL),(16,'FluidSpecimen','FluidSpecimen class','edu.wustl.catissuecore.domain.FluidSpecimen',NULL,NULL,1,'2005-01-01',NULL),(17,'TissueSpecimen','TissueSpecimen class','edu.wustl.catissuecore.domain.TissueSpecimen',NULL,NULL,1,'2005-01-01',NULL),(18,'CellSpecimen','CellSpecimen class','edu.wustl.catissuecore.domain.CellSpecimen',NULL,NULL,1,'2005-01-01',NULL),(19,'MolecularSpecimen','MolecularSpecimen class','edu.wustl.catissuecore.domain.MolecularSpecimen',NULL,NULL,1,'2005-01-01',NULL),(20,'Biohazard','Biohazard class','edu.wustl.catissuecore.domain.Biohazard',NULL,NULL,1,'2005-01-01',NULL),(21,'Specimen','Specimen class','edu.wustl.catissuecore.domain.Specimen',NULL,NULL,1,'2005-01-01',NULL),(22,'ExternalIdentifier','ExternalIdentifier class','edu.wustl.catissuecore.domain.ExternalIdentifier',NULL,NULL,1,'2005-01-01',NULL),(23,'EventParameters','EventParameters class','edu.wustl.catissuecore.domain.EventParameters',NULL,NULL,1,'2005-01-01',NULL),(24,'FluidSpecimenReviewEventParameters','FluidSpecimenReviewEventParameters class','edu.wustl.catissuecore.domain.FluidSpecimenReviewEventParameters',NULL,NULL,1,'2005-01-01',NULL),(25,'CellSpecimenReviewParameters','CellSpecimenReviewParameters class','edu.wustl.catissuecore.domain.CellSpecimenReviewParameters',NULL,NULL,1,'2005-01-01',NULL),(26,'TissueSpecimenReviewEventParameters','TissueSpecimenReviewEventParameters class','edu.wustl.catissuecore.domain.TissueSpecimenReviewEventParameters',NULL,NULL,1,'2005-01-01',NULL),(27,'MolecularSpecimenReviewParameters','MolecularSpecimenReviewParameters class','edu.wustl.catissuecore.domain.MolecularSpecimenReviewParameters',NULL,NULL,1,'2005-01-01',NULL),(28,'CheckInCheckOutEventParameter','CheckInCheckOutEventParameter class','edu.wustl.catissuecore.domain.CheckInCheckOutEventParameter',NULL,NULL,1,'2005-01-01',NULL),(29,'FrozenEventParameters','FrozenEventParameters class','edu.wustl.catissuecore.domain.FrozenEventParameters',NULL,NULL,1,'2005-01-01',NULL),(30,'EmbeddedEventParameters','EmbeddedEventParameters class','edu.wustl.catissuecore.domain.EmbeddedEventParameters',NULL,NULL,1,'2005-01-01',NULL),(31,'ReviewEventParameters','ReviewEventParameters class','edu.wustl.catissuecore.domain.ReviewEventParameters',NULL,NULL,1,'2005-01-01',NULL),(32,'SpunEventParameters','SpunEventParameters class','edu.wustl.catissuecore.domain.SpunEventParameters',NULL,NULL,1,'2005-01-01',NULL),(33,'ThawEventParameters','ThawEventParameters class','edu.wustl.catissuecore.domain.ThawEventParameters',NULL,NULL,1,'2005-01-01',NULL),(34,'SpecimenEventParameters','SpecimenEventParameters class','edu.wustl.catissuecore.domain.SpecimenEventParameters',NULL,NULL,1,'2005-01-01',NULL),(35,'ReceivedEventParameters','ReceivedEventParameters class','edu.wustl.catissuecore.domain.ReceivedEventParameters',NULL,NULL,1,'2005-01-01',NULL),(36,'DisposalEventParameters','DisposalEventParameters class','edu.wustl.catissuecore.domain.DisposalEventParameters',NULL,NULL,1,'2005-01-01',NULL),(37,'FixedEventParameters','FixedEventParameters class','edu.wustl.catissuecore.domain.FixedEventParameters',NULL,NULL,1,'2005-01-01',NULL),(38,'ProcedureEventParameters','ProcedureEventParameters class','edu.wustl.catissuecore.domain.ProcedureEventParameters',NULL,NULL,1,'2005-01-01',NULL),(39,'TransferEventParameters','TransferEventParameters class','edu.wustl.catissuecore.domain.TransferEventParameters',NULL,NULL,1,'2005-01-01',NULL),(40,'CollectionEventParameters','CollectionEventParameters class','edu.wustl.catissuecore.domain.CollectionEventParameters',NULL,NULL,1,'2005-01-01',NULL),(41,'Site','Site class','edu.wustl.catissuecore.domain.Site',NULL,NULL,1,'2005-01-01',NULL),(42,'StorageContainer','StorageContainer class','edu.wustl.catissuecore.domain.StorageContainer',NULL,NULL,1,'2005-01-01',NULL),(43,'StorageContainerDetails','StorageContainerDetails class','edu.wustl.catissuecore.domain.StorageContainerDetails',NULL,NULL,1,'2005-01-01',NULL),(44,'Capacity','Capacity class','edu.wustl.catissuecore.domain.Capacity',NULL,NULL,1,'2005-01-01',NULL),(45,'StorageType','StorageType class','edu.wustl.catissuecore.domain.StorageType',NULL,NULL,1,'2005-01-01',NULL),(46,'User','User class','edu.wustl.catissuecore.domain.User',NULL,NULL,1,'2005-01-01',NULL),(47,'Address','Address class','edu.wustl.catissuecore.domain.Address',NULL,NULL,1,'2005-01-01',NULL),(48,'CancerResearchGroup','CancerResearchGroup class','edu.wustl.catissuecore.domain.CancerResearchGroup',NULL,NULL,1,'2005-01-01',NULL),(50,'Department','Department class','edu.wustl.catissuecore.domain.Department',NULL,NULL,1,'2005-01-01',NULL),(51,'Institution','Institution class','edu.wustl.catissuecore.domain.Institution',NULL,NULL,1,'2005-01-01',NULL),(52,'Distribution','Distribution class','edu.wustl.catissuecore.domain.Distribution',NULL,NULL,1,'2005-01-01',NULL),(53,'DistributedItem','DistributedItem class','edu.wustl.catissuecore.domain.DistributedItem',NULL,NULL,1,'2005-01-01',NULL),(54,'CollectionProtocolEvent','CollectionProtocolEvent class','edu.wustl.catissuecore.domain.CollectionProtocolEvent',NULL,NULL,1,'2005-01-01',NULL),(55,'CollectionProtocol','CollectionProtocol class','edu.wustl.catissuecore.domain.CollectionProtocol',NULL,NULL,1,'2005-01-01',NULL),(56,'DistributionProtocol','DistributionProtocol class','edu.wustl.catissuecore.domain.DistributionProtocol',NULL,NULL,1,'2005-01-01',NULL),(57,'SpecimenProtocol','SpecimenProtocol class','edu.wustl.catissuecore.domain.SpecimenProtocol',NULL,NULL,1,'2005-01-01',NULL),(269,'edu.wustl.catissuecore.domain.ReportedProblem','edu.wustl.catissuecore.domain.ReportedProblem','edu.wustl.catissuecore.domain.ReportedProblem',NULL,NULL,1,'2005-08-31',NULL),(272,'edu.wustl.catissuecore.domain.SignUpUser','edu.wustl.catissuecore.domain.SignUpUser','edu.wustl.catissuecore.domain.SignUpUser',NULL,NULL,1,'2005-08-31',NULL),(276,'SpecimenArrayType','SpecimenArrayType Class','edu.wustl.catissuecore.domain.SpecimenArrayType',NULL,NULL,1,'2006-08-31',NULL),(281,'SpecimenArray','SpecimenArray Class','edu.wustl.catissuecore.domain.SpecimenArray',NULL,NULL,1,'2006-08-31',NULL),(294,'Local Extensions','Local Extensions class','edu.common.dynamicextensions.domain.integration.EntityMap',NULL,NULL,1,'2007-01-17',NULL),(300,'Consent Tier','ConsentTier Object','edu.wustl.catissuecore.domain.ConsentTier',NULL,NULL,1,'2006-11-27',NULL),(301,'Consent Tier Response','Consent Tier Response Object','edu.wustl.catissuecore.domain.ConsentTierResponse',NULL,NULL,1,'2006-11-27',NULL),(302,'Consent Tier Status','Consent Tier Status Object','edu.wustl.catissuecore.domain.ConsentTierStatus',NULL,NULL,1,'2006-11-27',NULL),(303,'ReturnEventParameters','ReturnEventParameters Class','edu.wustl.catissuecore.domain.ReturnEventParameters',NULL,NULL,1,'2007-01-17',NULL),(304,'Order','Order Object','edu.wustl.catissuecore.domain.OrderDetails',NULL,NULL,1,'2006-11-27',NULL),(305,'OrderItem','OrderItem Object','edu.wustl.catissuecore.domain.OrderItem',NULL,NULL,1,'2006-11-27',NULL),(306,'Derived Specimen Order Item','Derived Specimen Order Item Object','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem',NULL,NULL,1,'2006-11-27',NULL),(307,'Existing Specimen Array Order Item','Existing Specimen Array Order Item Object','edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem',NULL,NULL,1,'2006-11-27',NULL),(308,'Existing Specimen Order Item','Existing Specimen Order Item Object','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem',NULL,NULL,1,'2006-11-27',NULL),(309,'New Specimen Array Order Item','New Specimen Array Order Item Object','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem',NULL,NULL,1,'2006-11-27',NULL),(310,'New Specimen Order Item','New Specimen Order Item Object','edu.wustl.catissuecore.domain.NewSpecimenOrderItem',NULL,NULL,1,'2006-11-27',NULL),(311,'Pathological Case Order Item','Pathological Case Order Item Object','edu.wustl.catissuecore.domain.PathologicalCaseOrderItem',NULL,NULL,1,'2006-11-27',NULL),(312,'Specimen Array Order Item','Specimen Array Order Item Object','edu.wustl.catissuecore.domain.SpecimenArrayOrderItem',NULL,NULL,1,'2006-11-27',NULL),(313,'Specimen Order Item','Specimen Order Item Object','edu.wustl.catissuecore.domain.SpecimenOrderItem',NULL,NULL,1,'2006-11-27',NULL),(315,'IdentifiedSurgicalPathologyReport','IdentifiedSurgicalPathologyReport Object','edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport',NULL,NULL,1,'2006-11-27',NULL),(316,'DeidentifiedSurgicalPathologyReport','DeidentifiedSurgicalPathologyReport Object','edu.wustl.catissuecore.domain.pathology.DeidentifiedSurgicalPathologyReport',NULL,NULL,1,'2006-11-27',NULL),(317,'ReportLoaderQueue','ReportLoaderQueue Object','edu.wustl.catissuecore.domain.pathology.ReportLoaderQueue',NULL,NULL,1,'2006-11-27',NULL),(318,'Review Comments','PathologyReportReviewParameter Object','edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',NULL,NULL,1,'2006-11-27',NULL),(319,'Quarantine Comments','QuarantineEventParameter Object','edu.wustl.catissuecore.domain.pathology.QuarantineEventParameter',NULL,NULL,1,'2006-11-27',NULL),(326,'AbstractPosition','AbstractPosition Object','edu.wustl.catissuecore.domain.AbstractPosition',NULL,NULL,1,'2008-05-28',NULL),(327,'SpecimenPosition','SpecimenPosition Object','edu.wustl.catissuecore.domain.SpecimenPosition',NULL,NULL,1,'2008-05-28',NULL),(328,'ContainerPosition','ContainerPosition Object','edu.wustl.catissuecore.domain.ContainerPosition',NULL,NULL,1,'2008-05-28',NULL),(329,'AbstractSpecimen','AbstractSpecimen Object','edu.wustl.catissuecore.domain.AbstractSpecimen',NULL,NULL,1,'2008-05-28',NULL),(330,'SpecimenRequirement','SpecimenRequirement Object','edu.wustl.catissuecore.domain.SpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(331,'MolecularSpecimenRequirement','MolecularSpecimenRequirement Object','edu.wustl.catissuecore.domain.MolecularSpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(332,'FluidSpecimenRequirement','FluidSpecimenRequirement Object','edu.wustl.catissuecore.domain.FluidSpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(333,'CellSpecimenRequirement','CellSpecimenRequirement Object','edu.wustl.catissuecore.domain.CellSpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(334,'TissueSpecimenRequirement','TissueSpecimenRequirement Object','edu.wustl.catissuecore.domain.TissueSpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(335,'DistributionSpecimenRequirement','DistributionSpecimenRequirement Object','edu.wustl.catissuecore.domain.DistributionSpecimenRequirement',NULL,NULL,1,'2008-05-28',NULL),(336,'ADMIN_PROTECTION_ELEMENT','ADMIN_PROTECTION_ELEMENT Object','ADMIN_PROTECTION_ELEMENT',NULL,NULL,1,'2008-07-22',NULL),(1001,'catissuecore','CSM UPT Super Admin Application Protection Element','catissuecore','','',1,'2011-01-03',''),(1004,'edu.wustl.catissuecore.domain.Department1','edu.wustl.catissuecore.domain.Department','edu.wustl.catissuecore.domain.Department','name','',1,'2010-11-16','cbiit'),(1010,'edu.wustl.catissuecore.domain.Institution2','edu.wustl.catissuecore.domain.Institution2','edu.wustl.catissuecore.domain.Institution','name','',1,'2011-01-05','i2'),(1012,'edu.wustl.catissuecore.domain.Participant','edu.wustl.catissuecore.domain.Participant','edu.wustl.catissuecore.domain.Participant','id','',1,'2011-01-05','1'),(1026,'edu.wustl.catissuecore.domain.CollectionProtocol_1','edu.wustl.catissuecore.domain.CollectionProtocol','edu.wustl.catissuecore.domain.CollectionProtocol','type','',1,'2011-01-31','CP_1'),(1027,'edu.wustl.catissuecore.domain.CollectionProtocol_2','edu.wustl.catissuecore.domain.CollectionProtocol','edu.wustl.catissuecore.domain.CollectionProtocol','type','',1,'2011-01-31','CP_2');

/*Table structure for table `csm_protection_group` */

DROP TABLE IF EXISTS `csm_protection_group`;

CREATE TABLE `csm_protection_group` (
  `PROTECTION_GROUP_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PROTECTION_GROUP_NAME` varchar(100) NOT NULL DEFAULT '',
  `PROTECTION_GROUP_DESCRIPTION` varchar(200) DEFAULT NULL,
  `APPLICATION_ID` bigint(20) NOT NULL DEFAULT '0',
  `LARGE_ELEMENT_COUNT_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date NOT NULL DEFAULT '2005-01-01',
  `PARENT_PROTECTION_GROUP_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`PROTECTION_GROUP_ID`),
  UNIQUE KEY `UQ_PROTECTION_GROUP_PROTECTION_GROUP_NAME` (`APPLICATION_ID`,`PROTECTION_GROUP_NAME`),
  KEY `idx_APPLICATION_ID` (`APPLICATION_ID`),
  KEY `idx_PARENT_PROTECTION_GROUP_ID` (`PARENT_PROTECTION_GROUP_ID`),
  CONSTRAINT `csm_protection_group_ibfk_1` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_protection_group_ibfk_2` FOREIGN KEY (`PARENT_PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

/*Data for the table `csm_protection_group` */

insert  into `csm_protection_group`(`PROTECTION_GROUP_ID`,`PROTECTION_GROUP_NAME`,`PROTECTION_GROUP_DESCRIPTION`,`APPLICATION_ID`,`LARGE_ELEMENT_COUNT_FLAG`,`UPDATE_DATE`,`PARENT_PROTECTION_GROUP_ID`) values (1,'ADMINISTRATOR_PROTECTION_GROUP','Protection elements for class names of objects that belong to Administrative data',1,0,'2005-01-01',NULL),(2,'SUPERVISOR_PROTECTION_GROUP','Protection elements for class names of objects that belong to Supervisor\'s data',1,0,'2005-01-01',NULL),(3,'TECHNICIAN_PROTECTION_GROUP','Protection elements for class names of objects that belong to Technician data',1,0,'2005-01-01',NULL),(17,'SECURED_ADMINISTRATIVE_ACTIONS',NULL,1,0,'2005-01-01',NULL),(18,'SECURED_SUPERVISORY_ACTIONS',NULL,1,0,'2005-01-01',NULL),(19,'SECURED_TECHNICIAN_ACTIONS',NULL,1,0,'2005-01-01',NULL),(20,'PUBLIC_DATA_GROUP',NULL,1,0,'2005-01-01',NULL),(21,'ADMINISTRATORS_DATA_GROUP',NULL,1,0,'2005-01-01',NULL),(22,'SUPERVISORS_DATA_GROUP',NULL,1,0,'2005-01-01',NULL),(23,'TECHNICIANS_DATA_GROUP',NULL,1,0,'2005-01-01',NULL),(24,'SECURED_PUBLIC_ACTIONS',NULL,1,0,'2005-01-01',NULL),(44,'SCIENTIST_PROTECTION_GROUP',NULL,1,0,'2005-01-01',NULL),(45,'PUBLIC_QUERY_PROTECTION_GROUP',NULL,1,0,'2009-08-06',NULL),(46,'DepartmentInstances','',1,0,'2010-11-16',NULL),(56,'InstitutionProtection2','Group to protect edu.wustl.catissuecore.domain.Institution instances',1,0,'2011-01-05',NULL),(58,'Participant1','Group to protect edu.wustl.catissuecore.domain.Participant instances',1,0,'2011-01-05',NULL),(64,'SpecimenByCollectionProtocolGroup_1','Group to protect edu.wustl.catissuecore.domain.Specimen instances by CollectionProtocol',1,0,'2011-01-31',NULL),(65,'SpecimenByCollectionProtocolGroup_2','Group to protect edu.wustl.catissuecore.domain.Specimen instances by CollectionProtocol',1,0,'2011-01-31',NULL);

/*Table structure for table `csm_role` */

DROP TABLE IF EXISTS `csm_role`;

CREATE TABLE `csm_role` (
  `ROLE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(100) NOT NULL DEFAULT '',
  `ROLE_DESCRIPTION` varchar(200) DEFAULT NULL,
  `APPLICATION_ID` bigint(20) NOT NULL DEFAULT '0',
  `ACTIVE_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date NOT NULL DEFAULT '2005-01-01',
  PRIMARY KEY (`ROLE_ID`),
  UNIQUE KEY `UQ_ROLE_ROLE_NAME` (`APPLICATION_ID`,`ROLE_NAME`),
  KEY `idx_APPLICATION_ID` (`APPLICATION_ID`),
  CONSTRAINT `csm_role_ibfk_1` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `csm_application` (`APPLICATION_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `csm_role` */

insert  into `csm_role`(`ROLE_ID`,`ROLE_NAME`,`ROLE_DESCRIPTION`,`APPLICATION_ID`,`ACTIVE_FLAG`,`UPDATE_DATE`) values (1,'Administrator','Role for Administrator',1,0,'2005-01-01'),(2,'Supervisor','Role for Supervisor',1,0,'2005-01-01'),(3,'Technician','Role for Technician',1,0,'2005-01-01'),(4,'PI','Role for Principal Investigator',1,0,'2005-01-01'),(5,'READ_ONLY','Read Only Role',1,0,'2005-01-01'),(6,'USE_ONLY','Use Only Role',1,0,'2005-01-01'),(7,'Scientist','Role for Public',1,0,'2005-01-01'),(8,'UPDATE_ONLY','Update Only Role',1,0,'2005-01-01'),(9,'EXECUTE_ONLY','Execute Only Role',1,0,'2005-01-01'),(10,'READ_DENIED','Read Denied Role',1,0,'2005-01-01'),(11,'Coordinator','Role for Coordinator',1,0,'2005-01-01'),(12,'CREATE_ONLY','Create only role',1,0,'2005-01-01'),(13,'SUPERADMINISTRATOR','SUPER ADMINISTRATOR ROLE',1,0,'2008-06-19');

/*Table structure for table `csm_role_privilege` */

DROP TABLE IF EXISTS `csm_role_privilege`;

CREATE TABLE `csm_role_privilege` (
  `ROLE_PRIVILEGE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ROLE_ID` bigint(20) NOT NULL DEFAULT '0',
  `PRIVILEGE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ROLE_PRIVILEGE_ID`),
  UNIQUE KEY `UQ_ROLE_PRIVILEGE_ROLE_ID` (`PRIVILEGE_ID`,`ROLE_ID`),
  KEY `idx_PRIVILEGE_ID` (`PRIVILEGE_ID`),
  KEY `idx_ROLE_ID` (`ROLE_ID`),
  CONSTRAINT `csm_role_privilege_ibfk_1` FOREIGN KEY (`PRIVILEGE_ID`) REFERENCES `csm_privilege` (`PRIVILEGE_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_role_privilege_ibfk_2` FOREIGN KEY (`ROLE_ID`) REFERENCES `csm_role` (`ROLE_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

/*Data for the table `csm_role_privilege` */

insert  into `csm_role_privilege`(`ROLE_PRIVILEGE_ID`,`ROLE_ID`,`PRIVILEGE_ID`) values (1,1,1),(11,3,1),(30,12,1),(2,1,3),(8,2,3),(12,3,3),(16,4,3),(18,5,3),(22,6,3),(23,8,3),(28,11,3),(3,1,5),(13,3,5),(77,4,5),(20,8,5),(81,11,5),(78,4,6),(82,11,6),(4,1,7),(9,2,7),(14,3,7),(79,4,7),(21,9,7),(83,11,7),(5,1,8),(19,6,8),(6,1,9),(17,4,9),(7,1,10),(24,1,11),(25,2,11),(26,4,11),(29,11,11),(27,10,12),(47,1,13),(31,13,13),(48,1,14),(33,13,14),(49,1,15),(34,13,15),(50,1,16),(35,13,16),(32,13,17),(51,1,18),(61,2,18),(36,13,18),(52,1,20),(62,2,20),(37,13,20),(53,1,21),(63,2,21),(70,3,21),(38,13,21),(54,1,22),(64,2,22),(71,3,22),(75,7,22),(39,13,22),(55,1,23),(65,2,23),(80,4,23),(84,11,23),(40,13,23),(56,1,24),(66,2,24),(41,13,24),(57,1,25),(67,2,25),(72,3,25),(42,13,25),(58,1,26),(68,2,26),(73,3,26),(43,13,26),(59,1,27),(69,2,27),(74,3,27),(44,13,27),(60,1,28),(45,13,28),(76,1,29),(46,13,29),(85,1,30),(86,2,30);

/*Table structure for table `csm_user` */

DROP TABLE IF EXISTS `csm_user`;

CREATE TABLE `csm_user` (
  `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LOGIN_NAME` varchar(500) DEFAULT NULL,
  `FIRST_NAME` varchar(100) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(100) NOT NULL DEFAULT '',
  `ORGANIZATION` varchar(100) DEFAULT NULL,
  `DEPARTMENT` varchar(100) DEFAULT NULL,
  `TITLE` varchar(100) DEFAULT NULL,
  `PHONE_NUMBER` varchar(15) DEFAULT NULL,
  `PASSWORD` varchar(100) DEFAULT NULL,
  `EMAIL_ID` varchar(100) DEFAULT NULL,
  `START_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `UPDATE_DATE` date NOT NULL DEFAULT '0000-00-00',
  `MIGRATED_FLAG` tinyint(1) NOT NULL DEFAULT '0',
  `PREMGRT_LOGIN_NAME` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `UQ_LOGIN_NAME` (`LOGIN_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `csm_user` */

insert  into `csm_user`(`USER_ID`,`LOGIN_NAME`,`FIRST_NAME`,`LAST_NAME`,`ORGANIZATION`,`DEPARTMENT`,`TITLE`,`PHONE_NUMBER`,`PASSWORD`,`EMAIL_ID`,`START_DATE`,`END_DATE`,`UPDATE_DATE`,`MIGRATED_FLAG`,`PREMGRT_LOGIN_NAME`) values (1,'admin@admin.com','Admin','Admin',NULL,'1',NULL,NULL,'xxits++sTge8j2uyHEABIQ==','admin@admin.com','2005-08-30',NULL,'2005-08-30',0,NULL),(10,'catissuecsm','catissue','csm','','1','','','zJPWCwDeSgG8j2uyHEABIQ==','',NULL,NULL,'2010-11-05',0,''),(11,'catissuecsm1','catissue','csm','','1','','','zJPWCwDeSgG8j2uyHEABIQ==','',NULL,NULL,'2010-11-05',0,''),(12,'pooja','catissue','csm','','1','','','zJPWCwDeSgG8j2uyHEABIQ==','',NULL,NULL,'2010-11-05',0,'');

/*Table structure for table `csm_user_group` */

DROP TABLE IF EXISTS `csm_user_group`;

CREATE TABLE `csm_user_group` (
  `USER_GROUP_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` bigint(20) NOT NULL DEFAULT '0',
  `GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_GROUP_ID`),
  KEY `idx_USER_ID` (`USER_ID`),
  KEY `idx_GROUP_ID` (`GROUP_ID`),
  CONSTRAINT `csm_user_group_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `csm_group` (`GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_user_group_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `csm_user_group` */

insert  into `csm_user_group`(`USER_GROUP_ID`,`USER_ID`,`GROUP_ID`) values (1,1,1),(2,12,3);

/*Table structure for table `csm_user_group_role_pg` */

DROP TABLE IF EXISTS `csm_user_group_role_pg`;

CREATE TABLE `csm_user_group_role_pg` (
  `USER_GROUP_ROLE_PG_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` bigint(20) DEFAULT NULL,
  `GROUP_ID` bigint(20) DEFAULT NULL,
  `ROLE_ID` bigint(20) NOT NULL DEFAULT '0',
  `PROTECTION_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_DATE` date NOT NULL DEFAULT '2005-01-01',
  PRIMARY KEY (`USER_GROUP_ROLE_PG_ID`),
  KEY `idx_GROUP_ID` (`GROUP_ID`),
  KEY `idx_ROLE_ID` (`ROLE_ID`),
  KEY `idx_PROTECTION_GROUP_ID` (`PROTECTION_GROUP_ID`),
  KEY `idx_USER_ID` (`USER_ID`),
  CONSTRAINT `csm_user_group_role_pg_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `csm_group` (`GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_user_group_role_pg_ibfk_2` FOREIGN KEY (`PROTECTION_GROUP_ID`) REFERENCES `csm_protection_group` (`PROTECTION_GROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_user_group_role_pg_ibfk_3` FOREIGN KEY (`ROLE_ID`) REFERENCES `csm_role` (`ROLE_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_user_group_role_pg_ibfk_4` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;

/*Data for the table `csm_user_group_role_pg` */

insert  into `csm_user_group_role_pg`(`USER_GROUP_ROLE_PG_ID`,`USER_ID`,`GROUP_ID`,`ROLE_ID`,`PROTECTION_GROUP_ID`,`UPDATE_DATE`) values (3,NULL,4,5,1,'2005-01-01'),(4,NULL,1,1,1,'2005-01-01'),(5,NULL,1,1,2,'2005-01-01'),(6,NULL,1,1,3,'2005-01-01'),(20,NULL,1,1,17,'2005-01-01'),(21,NULL,1,1,18,'2005-01-01'),(22,NULL,1,1,19,'2005-01-01'),(23,NULL,1,1,20,'2005-01-01'),(24,NULL,1,1,21,'2005-01-01'),(25,NULL,1,1,22,'2005-01-01'),(26,NULL,1,1,23,'2005-01-01'),(27,NULL,2,1,2,'2005-01-01'),(28,NULL,2,1,3,'2005-01-01'),(33,NULL,2,1,22,'2005-01-01'),(34,NULL,2,1,23,'2005-01-01'),(35,NULL,2,2,1,'2005-01-01'),(40,NULL,2,2,18,'2005-01-01'),(41,NULL,2,2,19,'2005-01-01'),(46,NULL,2,2,21,'2005-01-01'),(47,NULL,3,3,3,'2005-01-01'),(50,NULL,3,3,19,'2005-01-01'),(51,NULL,3,5,1,'2005-01-01'),(52,NULL,3,5,2,'2005-01-01'),(56,NULL,3,5,21,'2005-01-01'),(57,NULL,3,5,22,'2005-01-01'),(61,NULL,4,5,2,'2005-01-01'),(62,NULL,4,5,3,'2005-01-01'),(69,NULL,4,5,20,'2005-01-01'),(70,NULL,1,1,24,'2005-08-24'),(71,NULL,2,2,24,'2005-08-24'),(72,NULL,3,3,24,'2005-08-24'),(73,NULL,4,9,24,'2005-08-24'),(74,NULL,2,2,20,'2006-01-18'),(75,NULL,3,3,20,'2005-08-24'),(102,NULL,4,12,44,'2005-01-01'),(103,10,NULL,5,46,'2010-11-16'),(113,11,NULL,5,56,'2011-01-05'),(115,11,NULL,5,58,'2011-01-05'),(117,12,NULL,5,46,'2010-11-16'),(125,10,NULL,5,64,'2011-01-31'),(126,11,NULL,5,65,'2011-01-31');

/*Table structure for table `csm_user_pe` */

DROP TABLE IF EXISTS `csm_user_pe`;

CREATE TABLE `csm_user_pe` (
  `USER_PROTECTION_ELEMENT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PROTECTION_ELEMENT_ID` bigint(20) NOT NULL DEFAULT '0',
  `USER_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_PROTECTION_ELEMENT_ID`),
  UNIQUE KEY `UQ_USER_PROTECTION_ELEMENT_PROTECTION_ELEMENT_ID` (`USER_ID`,`PROTECTION_ELEMENT_ID`),
  KEY `idx_USER_ID` (`USER_ID`),
  KEY `idx_PROTECTION_ELEMENT_ID` (`PROTECTION_ELEMENT_ID`),
  CONSTRAINT `csm_user_pe_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `csm_user` (`USER_ID`) ON DELETE CASCADE,
  CONSTRAINT `csm_user_pe_ibfk_2` FOREIGN KEY (`PROTECTION_ELEMENT_ID`) REFERENCES `csm_protection_element` (`PROTECTION_ELEMENT_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=325 DEFAULT CHARSET=latin1;

/*Data for the table `csm_user_pe` */

insert  into `csm_user_pe`(`USER_PROTECTION_ELEMENT_ID`,`PROTECTION_ELEMENT_ID`,`USER_ID`) values (300,1001,10),(30,1004,10),(323,1026,10),(307,1001,11),(306,1010,11),(309,1012,11),(324,1027,11),(301,1001,12);

/*Table structure for table `curated_path` */

DROP TABLE IF EXISTS `curated_path`;

CREATE TABLE `curated_path` (
  `curated_path_Id` bigint(20) NOT NULL DEFAULT '0',
  `entity_ids` varchar(1000) DEFAULT NULL,
  `selected` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`curated_path_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `curated_path` */

/*Table structure for table `curated_path_to_path` */

DROP TABLE IF EXISTS `curated_path_to_path`;

CREATE TABLE `curated_path_to_path` (
  `curated_path_Id` bigint(20) NOT NULL DEFAULT '0',
  `path_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`curated_path_Id`,`path_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `curated_path_to_path` */

/*Table structure for table `databasechangelog` */

DROP TABLE IF EXISTS `databasechangelog`;

CREATE TABLE `databasechangelog` (
  `ID` varchar(63) NOT NULL,
  `AUTHOR` varchar(63) NOT NULL,
  `FILENAME` varchar(200) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `MD5SUM` varchar(32) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`,`AUTHOR`,`FILENAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `databasechangelog` */

insert  into `databasechangelog`(`ID`,`AUTHOR`,`FILENAME`,`DATEEXECUTED`,`MD5SUM`,`DESCRIPTION`,`COMMENTS`,`TAG`,`LIQUIBASE`) values ('1','bda','c:/temp/caTissue/caTissue/db-upgrade.xml','2011-01-03 15:59:26','89e63c2c5352ca92251058451d5a31c2','Custom SQL','Need to have at least one changeset to allow tagging to work.','1.1','1.9.3');

/*Table structure for table `databasechangeloglock` */

DROP TABLE IF EXISTS `databasechangeloglock`;

CREATE TABLE `databasechangeloglock` (
  `ID` int(11) NOT NULL,
  `LOCKED` tinyint(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `databasechangeloglock` */

insert  into `databasechangeloglock`(`ID`,`LOCKED`,`LOCKGRANTED`,`LOCKEDBY`) values (1,0,NULL,NULL);

/*Table structure for table `de_e_1227` */

DROP TABLE IF EXISTS `de_e_1227`;

CREATE TABLE `de_e_1227` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1229` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1227` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1227` */

/*Table structure for table `de_e_1230` */

DROP TABLE IF EXISTS `de_e_1230`;

CREATE TABLE `de_e_1230` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1235` text,
  `DE_AT_1234` text,
  `DE_AT_1233` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1230` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1230` */

/*Table structure for table `de_e_1236` */

DROP TABLE IF EXISTS `de_e_1236`;

CREATE TABLE `de_e_1236` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1240` date DEFAULT NULL,
  `DE_AT_1239` date DEFAULT NULL,
  `DE_AT_1238` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1230_1232_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1264_1266_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1236` */

/*Table structure for table `de_e_1241` */

DROP TABLE IF EXISTS `de_e_1241`;

CREATE TABLE `de_e_1241` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1243` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1241` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1241E1230` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1230` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1241` */

/*Table structure for table `de_e_1244` */

DROP TABLE IF EXISTS `de_e_1244`;

CREATE TABLE `de_e_1244` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1248` text,
  `DE_AT_1247` text,
  `DE_AT_1246` int(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1244` */

/*Table structure for table `de_e_1249` */

DROP TABLE IF EXISTS `de_e_1249`;

CREATE TABLE `de_e_1249` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1253` text,
  `DE_AT_1252` text,
  `DE_AT_1251` date DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1249` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1249` */

/*Table structure for table `de_e_1254` */

DROP TABLE IF EXISTS `de_e_1254`;

CREATE TABLE `de_e_1254` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1257` text,
  `DE_AT_1256` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1254` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1254E1249` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1249` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1254` */

/*Table structure for table `de_e_1258` */

DROP TABLE IF EXISTS `de_e_1258`;

CREATE TABLE `de_e_1258` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1263` int(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1227_1260_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1258` */

/*Table structure for table `de_e_1264` */

DROP TABLE IF EXISTS `de_e_1264`;

CREATE TABLE `de_e_1264` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1270` text,
  `DE_AT_1269` text,
  `DE_AT_1268` double DEFAULT NULL,
  `DE_AT_1267` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1264` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1264` */

/*Table structure for table `de_e_1271` */

DROP TABLE IF EXISTS `de_e_1271`;

CREATE TABLE `de_e_1271` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1258_1262_IDENTIFIER` int(38) DEFAULT NULL,
  `DYEXTN_AS_844_1271` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1271E1264` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1264` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1271` */

/*Table structure for table `de_e_1274` */

DROP TABLE IF EXISTS `de_e_1274`;

CREATE TABLE `de_e_1274` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1258_1261_IDENTIFIER` int(38) DEFAULT NULL,
  `DYEXTN_AS_844_1274` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1274E1264` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1264` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1274` */

/*Table structure for table `de_e_1277` */

DROP TABLE IF EXISTS `de_e_1277`;

CREATE TABLE `de_e_1277` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1277` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1277E1254` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1254` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1277` */

/*Table structure for table `de_e_1279` */

DROP TABLE IF EXISTS `de_e_1279`;

CREATE TABLE `de_e_1279` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1282` text,
  `DE_AT_1281` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1279` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1279E1254` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1254` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1279` */

/*Table structure for table `de_e_1283` */

DROP TABLE IF EXISTS `de_e_1283`;

CREATE TABLE `de_e_1283` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1289` text,
  `DE_AT_1288` text,
  `DE_AT_1287` text,
  `DE_AT_1286` text,
  `DE_AT_1285` date DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1283` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1283` */

/*Table structure for table `de_e_1290` */

DROP TABLE IF EXISTS `de_e_1290`;

CREATE TABLE `de_e_1290` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1294` text,
  `DE_AT_1293` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1290` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1290` */

/*Table structure for table `de_e_1295` */

DROP TABLE IF EXISTS `de_e_1295`;

CREATE TABLE `de_e_1295` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1295` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1295E1249` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1249` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1295` */

/*Table structure for table `de_e_1297` */

DROP TABLE IF EXISTS `de_e_1297`;

CREATE TABLE `de_e_1297` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1299` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1297` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1297E1230` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1230` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1297` */

/*Table structure for table `de_e_1300` */

DROP TABLE IF EXISTS `de_e_1300`;

CREATE TABLE `de_e_1300` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_844_1300` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1300E1249` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1249` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1300` */

/*Table structure for table `de_e_1318` */

DROP TABLE IF EXISTS `de_e_1318`;

CREATE TABLE `de_e_1318` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1321` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1318` */

/*Table structure for table `de_e_1322` */

DROP TABLE IF EXISTS `de_e_1322`;

CREATE TABLE `de_e_1322` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1324` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1318_1320_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1322` */

/*Table structure for table `de_e_1325` */

DROP TABLE IF EXISTS `de_e_1325`;

CREATE TABLE `de_e_1325` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1331` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1325` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1325` */

/*Table structure for table `de_e_1332` */

DROP TABLE IF EXISTS `de_e_1332`;

CREATE TABLE `de_e_1332` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1335` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1325_1330_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1332` */

/*Table structure for table `de_e_1336` */

DROP TABLE IF EXISTS `de_e_1336`;

CREATE TABLE `de_e_1336` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1338` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1332_1334_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1336` */

/*Table structure for table `de_e_1339` */

DROP TABLE IF EXISTS `de_e_1339`;

CREATE TABLE `de_e_1339` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1343` text,
  `DE_AT_1342` text,
  `DE_AT_1341` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1325_1329_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1339` */

/*Table structure for table `de_e_1344` */

DROP TABLE IF EXISTS `de_e_1344`;

CREATE TABLE `de_e_1344` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1348` text,
  `DE_AT_1347` text,
  `DE_AT_1346` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1325_1328_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1344` */

/*Table structure for table `de_e_1349` */

DROP TABLE IF EXISTS `de_e_1349`;

CREATE TABLE `de_e_1349` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1356` text,
  `DE_AT_1355` double DEFAULT NULL,
  `DE_AT_1354` tinyint(1) DEFAULT NULL,
  `DE_AT_1353` text,
  `DE_AT_1352` text,
  `DE_AT_1351` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1349` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1349E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1349` */

/*Table structure for table `de_e_1357` */

DROP TABLE IF EXISTS `de_e_1357`;

CREATE TABLE `de_e_1357` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1357` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1357E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1357` */

/*Table structure for table `de_e_1359` */

DROP TABLE IF EXISTS `de_e_1359`;

CREATE TABLE `de_e_1359` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1362` text,
  `DE_AT_1361` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1359` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1359E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1359` */

/*Table structure for table `de_e_1363` */

DROP TABLE IF EXISTS `de_e_1363`;

CREATE TABLE `de_e_1363` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1363` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1363E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1363` */

/*Table structure for table `de_e_1365` */

DROP TABLE IF EXISTS `de_e_1365`;

CREATE TABLE `de_e_1365` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1368` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1365` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1365E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1365` */

/*Table structure for table `de_e_1369` */

DROP TABLE IF EXISTS `de_e_1369`;

CREATE TABLE `de_e_1369` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1374` int(38) DEFAULT NULL,
  `DE_AT_1373` int(38) DEFAULT NULL,
  `DE_AT_1372` int(38) DEFAULT NULL,
  `DE_AT_1371` int(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1369` */

/*Table structure for table `de_e_1375` */

DROP TABLE IF EXISTS `de_e_1375`;

CREATE TABLE `de_e_1375` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1375` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1375E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1375` */

/*Table structure for table `de_e_1377` */

DROP TABLE IF EXISTS `de_e_1377`;

CREATE TABLE `de_e_1377` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1380` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1377` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1377E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1377` */

/*Table structure for table `de_e_1381` */

DROP TABLE IF EXISTS `de_e_1381`;

CREATE TABLE `de_e_1381` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1385` int(38) DEFAULT NULL,
  `DE_AT_1384` int(38) DEFAULT NULL,
  `DE_AT_1383` int(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1381` */

/*Table structure for table `de_e_1386` */

DROP TABLE IF EXISTS `de_e_1386`;

CREATE TABLE `de_e_1386` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_4_1386` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1386E1325` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1325` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1386` */

/*Table structure for table `de_e_1400` */

DROP TABLE IF EXISTS `de_e_1400`;

CREATE TABLE `de_e_1400` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1403` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1325_1399_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1400` */

/*Table structure for table `de_e_1404` */

DROP TABLE IF EXISTS `de_e_1404`;

CREATE TABLE `de_e_1404` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1406` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1400_1402_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1404` */

/*Table structure for table `de_e_1408` */

DROP TABLE IF EXISTS `de_e_1408`;

CREATE TABLE `de_e_1408` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1412` text,
  `DE_AT_1411` text,
  `DE_AT_1410` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1377_1407_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1408` */

/*Table structure for table `de_e_1414` */

DROP TABLE IF EXISTS `de_e_1414`;

CREATE TABLE `de_e_1414` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1419` text,
  `DE_AT_1418` text,
  `DE_AT_1417` text,
  `DE_AT_1416` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1365_1413_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1414` */

/*Table structure for table `de_e_1421` */

DROP TABLE IF EXISTS `de_e_1421`;

CREATE TABLE `de_e_1421` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1425` text,
  `DE_AT_1424` text,
  `DE_AT_1423` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1290_1420_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1421` */

/*Table structure for table `de_e_1427` */

DROP TABLE IF EXISTS `de_e_1427`;

CREATE TABLE `de_e_1427` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1431` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1227_1426_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1427` */

/*Table structure for table `de_e_1432` */

DROP TABLE IF EXISTS `de_e_1432`;

CREATE TABLE `de_e_1432` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1427_1430_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1432E1274` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1274` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1432` */

/*Table structure for table `de_e_1434` */

DROP TABLE IF EXISTS `de_e_1434`;

CREATE TABLE `de_e_1434` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1427_1429_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1434E1271` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1271` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1434` */

/*Table structure for table `de_e_1437` */

DROP TABLE IF EXISTS `de_e_1437`;

CREATE TABLE `de_e_1437` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1439` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1620_1622_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1437` */

/*Table structure for table `de_e_1440` */

DROP TABLE IF EXISTS `de_e_1440`;

CREATE TABLE `de_e_1440` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1446` text,
  `DE_AT_1445` text,
  `DE_AT_1444` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1440` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1440` */

/*Table structure for table `de_e_1447` */

DROP TABLE IF EXISTS `de_e_1447`;

CREATE TABLE `de_e_1447` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1450` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1440_1443_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1447` */

/*Table structure for table `de_e_1451` */

DROP TABLE IF EXISTS `de_e_1451`;

CREATE TABLE `de_e_1451` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1453` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1447_1449_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1451` */

/*Table structure for table `de_e_1454` */

DROP TABLE IF EXISTS `de_e_1454`;

CREATE TABLE `de_e_1454` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1457` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1440_1442_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1454` */

/*Table structure for table `de_e_1458` */

DROP TABLE IF EXISTS `de_e_1458`;

CREATE TABLE `de_e_1458` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1460` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1454_1456_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1458` */

/*Table structure for table `de_e_1461` */

DROP TABLE IF EXISTS `de_e_1461`;

CREATE TABLE `de_e_1461` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1461` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1461E1440` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1440` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1461` */

/*Table structure for table `de_e_1468` */

DROP TABLE IF EXISTS `de_e_1468`;

CREATE TABLE `de_e_1468` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1472` text,
  `DE_AT_1471` text,
  `DE_AT_1470` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1461_1467_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1468` */

/*Table structure for table `de_e_1473` */

DROP TABLE IF EXISTS `de_e_1473`;

CREATE TABLE `de_e_1473` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1478` tinyint(1) DEFAULT NULL,
  `DE_AT_1477` double DEFAULT NULL,
  `DE_AT_1476` double DEFAULT NULL,
  `DE_AT_1475` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1461_1466_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1473` */

/*Table structure for table `de_e_1479` */

DROP TABLE IF EXISTS `de_e_1479`;

CREATE TABLE `de_e_1479` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1483` text,
  `DE_AT_1482` text,
  `DE_AT_1481` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1461_1465_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1479` */

/*Table structure for table `de_e_1484` */

DROP TABLE IF EXISTS `de_e_1484`;

CREATE TABLE `de_e_1484` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1461_1464_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1484` */

/*Table structure for table `de_e_1489` */

DROP TABLE IF EXISTS `de_e_1489`;

CREATE TABLE `de_e_1489` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1496` text,
  `DE_AT_1495` bigint(38) DEFAULT NULL,
  `DE_AT_1494` bigint(38) DEFAULT NULL,
  `DE_AT_1493` bigint(38) DEFAULT NULL,
  `DE_AT_1492` bigint(38) DEFAULT NULL,
  `DE_AT_1491` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1484_1488_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1489` */

/*Table structure for table `de_e_1497` */

DROP TABLE IF EXISTS `de_e_1497`;

CREATE TABLE `de_e_1497` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1500` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1484_1487_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1497` */

/*Table structure for table `de_e_1501` */

DROP TABLE IF EXISTS `de_e_1501`;

CREATE TABLE `de_e_1501` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1504` text,
  `DE_AT_1503` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1497_1499_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1501` */

/*Table structure for table `de_e_1505` */

DROP TABLE IF EXISTS `de_e_1505`;

CREATE TABLE `de_e_1505` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1507` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1484_1486_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1505` */

/*Table structure for table `de_e_1508` */

DROP TABLE IF EXISTS `de_e_1508`;

CREATE TABLE `de_e_1508` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1512` text,
  `DE_AT_1511` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1461_1463_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1508` */

/*Table structure for table `de_e_1513` */

DROP TABLE IF EXISTS `de_e_1513`;

CREATE TABLE `de_e_1513` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1515` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1508_1510_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1513` */

/*Table structure for table `de_e_1516` */

DROP TABLE IF EXISTS `de_e_1516`;

CREATE TABLE `de_e_1516` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1516` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1516E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1516` */

/*Table structure for table `de_e_1518` */

DROP TABLE IF EXISTS `de_e_1518`;

CREATE TABLE `de_e_1518` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1523` text,
  `DE_AT_1522` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1518` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1518E1516` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1516` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1518` */

/*Table structure for table `de_e_1524` */

DROP TABLE IF EXISTS `de_e_1524`;

CREATE TABLE `de_e_1524` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1526` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1518_1521_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1524` */

/*Table structure for table `de_e_1527` */

DROP TABLE IF EXISTS `de_e_1527`;

CREATE TABLE `de_e_1527` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1532` text,
  `DE_AT_1531` text,
  `DE_AT_1530` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1518_1520_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1527` */

/*Table structure for table `de_e_1533` */

DROP TABLE IF EXISTS `de_e_1533`;

CREATE TABLE `de_e_1533` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1535` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1527_1529_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1533` */

/*Table structure for table `de_e_1536` */

DROP TABLE IF EXISTS `de_e_1536`;

CREATE TABLE `de_e_1536` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1538` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1536` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1536E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1536` */

/*Table structure for table `de_e_1539` */

DROP TABLE IF EXISTS `de_e_1539`;

CREATE TABLE `de_e_1539` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1539` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1539E1536` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1536` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1539` */

/*Table structure for table `de_e_1541` */

DROP TABLE IF EXISTS `de_e_1541`;

CREATE TABLE `de_e_1541` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1544` text,
  `DE_AT_1543` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1788_1790_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1541` */

/*Table structure for table `de_e_1545` */

DROP TABLE IF EXISTS `de_e_1545`;

CREATE TABLE `de_e_1545` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1550` double DEFAULT NULL,
  `DE_AT_1549` text,
  `DE_AT_1548` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1545` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1545E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1545` */

/*Table structure for table `de_e_1551` */

DROP TABLE IF EXISTS `de_e_1551`;

CREATE TABLE `de_e_1551` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1555` text,
  `DE_AT_1554` text,
  `DE_AT_1553` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1545_1547_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1551` */

/*Table structure for table `de_e_1556` */

DROP TABLE IF EXISTS `de_e_1556`;

CREATE TABLE `de_e_1556` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1558` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1600_1602_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1749_1751_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1556` */

/*Table structure for table `de_e_1559` */

DROP TABLE IF EXISTS `de_e_1559`;

CREATE TABLE `de_e_1559` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1561` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1559` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1559E1516` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1516` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1559` */

/*Table structure for table `de_e_1562` */

DROP TABLE IF EXISTS `de_e_1562`;

CREATE TABLE `de_e_1562` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1565` text,
  `DE_AT_1564` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1615_1617_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1562` */

/*Table structure for table `de_e_1566` */

DROP TABLE IF EXISTS `de_e_1566`;

CREATE TABLE `de_e_1566` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1569` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1797_1799_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1566` */

/*Table structure for table `de_e_1570` */

DROP TABLE IF EXISTS `de_e_1570`;

CREATE TABLE `de_e_1570` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1573` text,
  `DE_AT_1572` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1566_1568_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1570` */

/*Table structure for table `de_e_1574` */

DROP TABLE IF EXISTS `de_e_1574`;

CREATE TABLE `de_e_1574` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1576` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1797_1800_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1574` */

/*Table structure for table `de_e_1577` */

DROP TABLE IF EXISTS `de_e_1577`;

CREATE TABLE `de_e_1577` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1583` text,
  `DE_AT_1582` text,
  `DE_AT_1581` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1577` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1577E1440` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1440` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1577` */

/*Table structure for table `de_e_1584` */

DROP TABLE IF EXISTS `de_e_1584`;

CREATE TABLE `de_e_1584` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1588` text,
  `DE_AT_1587` text,
  `DE_AT_1586` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1577_1580_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1584` */

/*Table structure for table `de_e_1589` */

DROP TABLE IF EXISTS `de_e_1589`;

CREATE TABLE `de_e_1589` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1592` text,
  `DE_AT_1591` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1577_1579_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1589` */

/*Table structure for table `de_e_1593` */

DROP TABLE IF EXISTS `de_e_1593`;

CREATE TABLE `de_e_1593` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1599` text,
  `DE_AT_1598` text,
  `DE_AT_1597` text,
  `DE_AT_1596` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1593` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1593E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1593` */

/*Table structure for table `de_e_1600` */

DROP TABLE IF EXISTS `de_e_1600`;

CREATE TABLE `de_e_1600` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1604` text,
  `DE_AT_1603` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1735_1747_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1600` */

/*Table structure for table `de_e_1605` */

DROP TABLE IF EXISTS `de_e_1605`;

CREATE TABLE `de_e_1605` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1607` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1735_1746_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1605` */

/*Table structure for table `de_e_1608` */

DROP TABLE IF EXISTS `de_e_1608`;

CREATE TABLE `de_e_1608` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1611` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1631_1633_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1608` */

/*Table structure for table `de_e_1612` */

DROP TABLE IF EXISTS `de_e_1612`;

CREATE TABLE `de_e_1612` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1614` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1608_1610_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1648_1650_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1612` */

/*Table structure for table `de_e_1615` */

DROP TABLE IF EXISTS `de_e_1615`;

CREATE TABLE `de_e_1615` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1619` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1705_1707_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1615` */

/*Table structure for table `de_e_1620` */

DROP TABLE IF EXISTS `de_e_1620`;

CREATE TABLE `de_e_1620` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1624` double DEFAULT NULL,
  `DE_AT_1623` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1615_1618_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1620` */

/*Table structure for table `de_e_1625` */

DROP TABLE IF EXISTS `de_e_1625`;

CREATE TABLE `de_e_1625` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1630` double DEFAULT NULL,
  `DE_AT_1629` tinyint(1) DEFAULT NULL,
  `DE_AT_1628` bigint(38) DEFAULT NULL,
  `DE_AT_1627` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1625` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1625E1545` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1545` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1625` */

/*Table structure for table `de_e_1631` */

DROP TABLE IF EXISTS `de_e_1631`;

CREATE TABLE `de_e_1631` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1639` text,
  `DE_AT_1638` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1631` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1631E1593` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1593` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1631` */

/*Table structure for table `de_e_1640` */

DROP TABLE IF EXISTS `de_e_1640`;

CREATE TABLE `de_e_1640` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1643` tinyint(1) DEFAULT NULL,
  `DE_AT_1642` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1788_1792_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1640` */

/*Table structure for table `de_e_1644` */

DROP TABLE IF EXISTS `de_e_1644`;

CREATE TABLE `de_e_1644` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1647` text,
  `DE_AT_1646` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1631_1636_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1644` */

/*Table structure for table `de_e_1648` */

DROP TABLE IF EXISTS `de_e_1648`;

CREATE TABLE `de_e_1648` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1651` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1631_1634_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1648` */

/*Table structure for table `de_e_1652` */

DROP TABLE IF EXISTS `de_e_1652`;

CREATE TABLE `de_e_1652` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1658` double DEFAULT NULL,
  `DE_AT_1657` double DEFAULT NULL,
  `DE_AT_1656` text,
  `DE_AT_1655` bigint(38) DEFAULT NULL,
  `DE_AT_1654` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1652` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1652E1545` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1545` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1652` */

/*Table structure for table `de_e_1659` */

DROP TABLE IF EXISTS `de_e_1659`;

CREATE TABLE `de_e_1659` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1662` text,
  `DE_AT_1661` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1667_1670_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1659` */

/*Table structure for table `de_e_1663` */

DROP TABLE IF EXISTS `de_e_1663`;

CREATE TABLE `de_e_1663` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1666` text,
  `DE_AT_1665` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1680_1682_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1663` */

/*Table structure for table `de_e_1667` */

DROP TABLE IF EXISTS `de_e_1667`;

CREATE TABLE `de_e_1667` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1672` text,
  `DE_AT_1671` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1754_1758_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1667` */

/*Table structure for table `de_e_1673` */

DROP TABLE IF EXISTS `de_e_1673`;

CREATE TABLE `de_e_1673` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1675` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1667_1669_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1673` */

/*Table structure for table `de_e_1676` */

DROP TABLE IF EXISTS `de_e_1676`;

CREATE TABLE `de_e_1676` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1676` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1676E1545` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1545` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1676` */

/*Table structure for table `de_e_1680` */

DROP TABLE IF EXISTS `de_e_1680`;

CREATE TABLE `de_e_1680` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1684` text,
  `DE_AT_1683` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1676_1679_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1680` */

/*Table structure for table `de_e_1685` */

DROP TABLE IF EXISTS `de_e_1685`;

CREATE TABLE `de_e_1685` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1689` text,
  `DE_AT_1688` tinyint(1) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1676_1678_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1685` */

/*Table structure for table `de_e_1690` */

DROP TABLE IF EXISTS `de_e_1690`;

CREATE TABLE `de_e_1690` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1692` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1685_1687_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1690` */

/*Table structure for table `de_e_1693` */

DROP TABLE IF EXISTS `de_e_1693`;

CREATE TABLE `de_e_1693` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1696` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1715_1718_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1693` */

/*Table structure for table `de_e_1697` */

DROP TABLE IF EXISTS `de_e_1697`;

CREATE TABLE `de_e_1697` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1700` double DEFAULT NULL,
  `DE_AT_1699` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1693_1695_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1723_1725_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1727_1729_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1731_1733_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1697` */

/*Table structure for table `de_e_1701` */

DROP TABLE IF EXISTS `de_e_1701`;

CREATE TABLE `de_e_1701` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1704` text,
  `DE_AT_1703` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1705_1708_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1701` */

/*Table structure for table `de_e_1705` */

DROP TABLE IF EXISTS `de_e_1705`;

CREATE TABLE `de_e_1705` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1705` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1705E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1705` */

/*Table structure for table `de_e_1709` */

DROP TABLE IF EXISTS `de_e_1709`;

CREATE TABLE `de_e_1709` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1714` text,
  `DE_AT_1713` text,
  `DE_AT_1712` text,
  `DE_AT_1711` bigint(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1754_1759_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1709` */

/*Table structure for table `de_e_1715` */

DROP TABLE IF EXISTS `de_e_1715`;

CREATE TABLE `de_e_1715` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1722` double DEFAULT NULL,
  `DE_AT_1721` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1715` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1715E1593` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1593` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1715` */

/*Table structure for table `de_e_1723` */

DROP TABLE IF EXISTS `de_e_1723`;

CREATE TABLE `de_e_1723` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1726` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1715_1720_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1723` */

/*Table structure for table `de_e_1727` */

DROP TABLE IF EXISTS `de_e_1727`;

CREATE TABLE `de_e_1727` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1730` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1715_1719_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1727` */

/*Table structure for table `de_e_1731` */

DROP TABLE IF EXISTS `de_e_1731`;

CREATE TABLE `de_e_1731` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1734` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1697_1733_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1715_1717_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1731` */

/*Table structure for table `de_e_1735` */

DROP TABLE IF EXISTS `de_e_1735`;

CREATE TABLE `de_e_1735` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_AT_1744` text,
  `DE_AT_1743` text,
  `DE_AT_1742` text,
  `DE_AT_1741` text,
  `DE_AT_1740` tinyint(1) DEFAULT NULL,
  `DE_AT_1739` double DEFAULT NULL,
  `DE_AT_1738` text,
  `DE_AT_1737` text,
  `DE_AT_1736` text,
  `DYEXTN_AS_379_1735` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1735E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1735` */

/*Table structure for table `de_e_1749` */

DROP TABLE IF EXISTS `de_e_1749`;

CREATE TABLE `de_e_1749` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1753` text,
  `DE_AT_1752` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1735_1745_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1749` */

/*Table structure for table `de_e_1754` */

DROP TABLE IF EXISTS `de_e_1754`;

CREATE TABLE `de_e_1754` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1761` text,
  `DE_AT_1760` int(38) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1754` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1754E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1754` */

/*Table structure for table `de_e_1762` */

DROP TABLE IF EXISTS `de_e_1762`;

CREATE TABLE `de_e_1762` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1764` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1754_1756_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1762` */

/*Table structure for table `de_e_1765` */

DROP TABLE IF EXISTS `de_e_1765`;

CREATE TABLE `de_e_1765` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1769` text,
  `DE_AT_1768` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1788_1793_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1765` */

/*Table structure for table `de_e_1770` */

DROP TABLE IF EXISTS `de_e_1770`;

CREATE TABLE `de_e_1770` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1772` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1765_1767_IDENTIFIER` int(38) DEFAULT NULL,
  `DE_E_1784_1786_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1770` */

/*Table structure for table `de_e_1773` */

DROP TABLE IF EXISTS `de_e_1773`;

CREATE TABLE `de_e_1773` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1773` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1773E1461` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1461` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1773` */

/*Table structure for table `de_e_1777` */

DROP TABLE IF EXISTS `de_e_1777`;

CREATE TABLE `de_e_1777` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1780` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1773_1776_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1777` */

/*Table structure for table `de_e_1781` */

DROP TABLE IF EXISTS `de_e_1781`;

CREATE TABLE `de_e_1781` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1783` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1777_1779_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1781` */

/*Table structure for table `de_e_1784` */

DROP TABLE IF EXISTS `de_e_1784`;

CREATE TABLE `de_e_1784` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1787` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1788_1791_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1784` */

/*Table structure for table `de_e_1788` */

DROP TABLE IF EXISTS `de_e_1788`;

CREATE TABLE `de_e_1788` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1788` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1788E1593` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1593` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1788` */

/*Table structure for table `de_e_1794` */

DROP TABLE IF EXISTS `de_e_1794`;

CREATE TABLE `de_e_1794` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1796` double DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1794` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1794E1545` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1545` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1794` */

/*Table structure for table `de_e_1797` */

DROP TABLE IF EXISTS `de_e_1797`;

CREATE TABLE `de_e_1797` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1802` text,
  `DE_AT_1801` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DYEXTN_AS_379_1797` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1797E1536` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1536` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1797` */

/*Table structure for table `de_e_1828` */

DROP TABLE IF EXISTS `de_e_1828`;

CREATE TABLE `de_e_1828` (
  `ACTIVITY_STATUS` text,
  `DE_AT_1833` double DEFAULT NULL,
  `DE_AT_1832` double DEFAULT NULL,
  `DE_AT_1831` double DEFAULT NULL,
  `DE_AT_1830` tinyint(1) DEFAULT NULL,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1773_1827_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1828` */

/*Table structure for table `de_e_1836` */

DROP TABLE IF EXISTS `de_e_1836`;

CREATE TABLE `de_e_1836` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1754_1835_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1836E1473` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1473` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1836` */

/*Table structure for table `de_e_1838` */

DROP TABLE IF EXISTS `de_e_1838`;

CREATE TABLE `de_e_1838` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1754_1834_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1838E1473` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1473` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1838` */

/*Table structure for table `de_e_1841` */

DROP TABLE IF EXISTS `de_e_1841`;

CREATE TABLE `de_e_1841` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1593_1840_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1841E1473` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1473` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1841` */

/*Table structure for table `de_e_1845` */

DROP TABLE IF EXISTS `de_e_1845`;

CREATE TABLE `de_e_1845` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1631_1844_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1845E1640` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1640` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1845` */

/*Table structure for table `de_e_1847` */

DROP TABLE IF EXISTS `de_e_1847`;

CREATE TABLE `de_e_1847` (
  `ACTIVITY_STATUS` text,
  `IDENTIFIER` bigint(38) NOT NULL DEFAULT '0',
  `DE_E_1631_1843_IDENTIFIER` int(38) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  CONSTRAINT `FKE1847E1640` FOREIGN KEY (`IDENTIFIER`) REFERENCES `de_e_1640` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `de_e_1847` */

/*Table structure for table `dyextn_abstract_form_context` */

DROP TABLE IF EXISTS `dyextn_abstract_form_context`;

CREATE TABLE `dyextn_abstract_form_context` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `FORM_LABEL` varchar(255) DEFAULT NULL,
  `CONTAINER_ID` bigint(20) DEFAULT NULL,
  `HIDE_FORM` bit(1) DEFAULT b'0',
  `ACTIVITY_STATUS` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_abstract_form_context` */

insert  into `dyextn_abstract_form_context`(`IDENTIFIER`,`FORM_LABEL`,`CONTAINER_ID`,`HIDE_FORM`,`ACTIVITY_STATUS`) values (1,NULL,1,'\0',NULL),(2,NULL,2,'\0',NULL),(3,NULL,3,'\0',NULL),(4,NULL,5,'\0',NULL),(5,NULL,6,'\0',NULL),(6,NULL,7,'\0',NULL),(7,NULL,8,'\0',NULL),(8,NULL,9,'\0',NULL),(9,NULL,10,'\0',NULL),(10,NULL,13,'\0',NULL),(11,NULL,12,'\0',NULL),(12,NULL,11,'\0',NULL),(13,NULL,14,'\0',NULL),(14,NULL,15,'\0',NULL),(15,NULL,16,'\0',NULL),(16,NULL,21,'\0',NULL),(17,NULL,22,'\0',NULL),(18,NULL,23,'\0',NULL),(19,NULL,24,'\0',NULL),(20,NULL,25,'\0',NULL),(21,NULL,26,'\0',NULL),(22,NULL,27,'\0',NULL),(23,NULL,28,'\0',NULL),(24,NULL,29,'\0',NULL),(25,NULL,42,'\0',NULL),(26,NULL,45,'\0',NULL),(27,NULL,56,'\0',NULL),(28,NULL,58,'\0',NULL),(29,NULL,63,'\0',NULL),(30,NULL,64,'\0',NULL),(31,NULL,65,'\0',NULL),(32,NULL,66,'\0',NULL),(33,NULL,72,'\0',NULL),(34,NULL,73,'\0',NULL),(35,NULL,74,'\0',NULL),(36,NULL,78,'\0',NULL),(37,NULL,79,'\0',NULL),(38,NULL,80,'\0',NULL),(39,NULL,84,'\0',NULL),(40,NULL,89,'\0',NULL),(41,NULL,92,'\0',NULL),(42,NULL,98,'\0',NULL),(43,NULL,99,'\0',NULL),(44,NULL,105,'\0',NULL),(45,NULL,110,'\0',NULL),(46,NULL,116,'\0',NULL);

/*Table structure for table `dyextn_abstract_metadata` */

DROP TABLE IF EXISTS `dyextn_abstract_metadata`;

CREATE TABLE `dyextn_abstract_metadata` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_DATE` date DEFAULT NULL,
  `DESCRIPTION` text,
  `LAST_UPDATED` date DEFAULT NULL,
  `NAME` text,
  `PUBLIC_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=1959 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_abstract_metadata` */

insert  into `dyextn_abstract_metadata`(`IDENTIFIER`,`CREATED_DATE`,`DESCRIPTION`,`LAST_UPDATED`,`NAME`,`PUBLIC_ID`) values (1,'2007-10-10','Catissue Suite','2007-10-10','Catissue Suite',NULL),(2,'2007-10-10','Base class for defining all domain objects in the system.','2007-10-10','edu.wustl.catissuecore.domain.AbstractDomainObject',NULL),(3,NULL,'System generated unique identifier.',NULL,'id','954196821'),(4,'2007-10-10','A single unit of tissue, body fluid, or derivative biological macromolecule that is collected or created from a Participant','2007-10-10','edu.wustl.catissuecore.domain.Specimen',NULL),(6,NULL,NULL,NULL,'AssociationName_20',NULL),(7,NULL,NULL,NULL,'AssociationName_19',NULL),(8,NULL,NULL,NULL,'AssociationName_18',NULL),(13,NULL,NULL,NULL,'AssociationName_13',NULL),(14,NULL,NULL,NULL,'AssociationName_12',NULL),(15,NULL,'System generated unique identifier.',NULL,'id','954196821'),(17,NULL,NULL,NULL,'collectionStatus','-292159954'),(18,NULL,'Histopathological character of the specimen e.g. Non-Malignant, Malignant, Non-Malignant Diseased, Pre-Malignant.',NULL,'pathologicalStatus','267670153'),(19,NULL,'Is this specimen still physically available in the tissue bank?',NULL,'isAvailable','267670148'),(21,NULL,'Barcode assigned to the specimen.',NULL,'barcode','267670149'),(22,NULL,NULL,NULL,'createdOn','-292159956'),(23,NULL,'Type of specimen. e.g. Serum, Plasma, Blood, Fresh Tissue etc.',NULL,'specimenType','267670156'),(24,NULL,'Human readable unique label/name assigned to specimen.',NULL,'label','267670151'),(25,NULL,'Defines whether this Specimen record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','267670147'),(26,NULL,'Shows specimen\'s heredity status e.g. Original, Derivative, Aliquot',NULL,'lineage','267670152'),(27,NULL,'Comments on specimen.',NULL,'comment','267670150'),(40,'2007-10-10','An object that can be used to hold things.','2007-10-10','edu.wustl.catissuecore.domain.Container',NULL),(41,NULL,NULL,NULL,'AssociationName_4',NULL),(45,NULL,'A written explanation about container.',NULL,'comment','1594949321'),(46,NULL,'Is no space available in the container to store more specimens?',NULL,'full','1594949322'),(47,NULL,'A machine-readable unique name/information assigned to the container.',NULL,'barcode','1594949320'),(50,NULL,'Activity status of the container.',NULL,'activityStatus','1594949319'),(51,NULL,'A human readable unique name assigned to the container.',NULL,'name','1594949323'),(52,NULL,'System generated unique identifier.',NULL,'id','954196821'),(53,'2007-10-10','A collection of specimens arranged in an ordered pattern.  ','2007-10-10','edu.wustl.catissuecore.domain.SpecimenArray',NULL),(54,NULL,NULL,NULL,'AssociationName_7',NULL),(56,NULL,NULL,NULL,'AssociationName_5',NULL),(57,NULL,'System generated unique identifier.',NULL,'id','954196821'),(58,NULL,'A human readable unique name assigned to the container.',NULL,'name','1594949323'),(59,NULL,'Activity status of the container.',NULL,'activityStatus','1594949319'),(60,NULL,'Whether this specimen array is available for distribution or any other purpose.',NULL,'available','1924296045'),(63,NULL,'A machine-readable unique name/information assigned to the container.',NULL,'barcode','1594949320'),(64,NULL,'Is no space available in the container to store more specimens?',NULL,'full','1594949322'),(65,NULL,'A written explanation about container.',NULL,'comment','1594949321'),(66,NULL,NULL,NULL,'AssociationName_1',NULL),(70,'2007-10-10','A physically discreet container that is used to store a specimen  e.g. Box, Freezer etc','2007-10-10','edu.wustl.catissuecore.domain.StorageContainer',NULL),(71,NULL,NULL,NULL,'AssociationName_9',NULL),(72,NULL,NULL,NULL,'AssociationName_8',NULL),(73,NULL,NULL,NULL,'AssociationName_7',NULL),(74,NULL,NULL,NULL,'AssociationName_6',NULL),(76,NULL,'System generated unique identifier.',NULL,'id','954196821'),(77,NULL,'A human readable unique name assigned to the container.',NULL,'name','1594949323'),(78,NULL,'Activity status of the container.',NULL,'activityStatus','1594949319'),(81,NULL,'A machine-readable unique name/information assigned to the container.',NULL,'barcode','1594949320'),(82,NULL,'Is no space available in the container to store more specimens?',NULL,'full','1594949322'),(83,NULL,'A written explanation about container.',NULL,'comment','1594949321'),(84,NULL,'Intended temperature of the storage container.',NULL,'tempratureInCentigrade','-345713105'),(85,NULL,NULL,NULL,'AssociationName_1',NULL),(86,NULL,NULL,NULL,'AssociationName_2',NULL),(89,'2007-10-10','A physical location associated with biospecimen collection, storage, processing, or utilization','2007-10-10','edu.wustl.catissuecore.domain.Site',NULL),(90,NULL,NULL,NULL,'AssociationName_2',NULL),(91,NULL,NULL,NULL,'AssociationName_1',NULL),(92,NULL,'Defines whether this Site record can be queried (Active) or not queried (Inactive) by any actor.',NULL,'activityStatus','1591666435'),(93,NULL,'Name of the physical location.',NULL,'name','1591666437'),(94,NULL,'System generated unique identifier.',NULL,'id','954196821'),(95,NULL,'Email address of the site.',NULL,'emailAddress','1591666436'),(96,NULL,'Function of the site (e.g. Collection site, repository, or laboratory)',NULL,'type','1591666438'),(97,'2007-10-10','A person who interacts with the system and/or involved in the process of biospecimen collection, processing, or utilization','2007-10-10','edu.wustl.catissuecore.domain.User',NULL),(98,NULL,NULL,NULL,'AssociationName_5',NULL),(99,NULL,'Last name of the User',NULL,'lastName','665011496'),(100,NULL,'Common Security Module linking attribute',NULL,'csmUserId','665011493'),(101,NULL,'System generated unique identifier.',NULL,'id','954196821'),(102,NULL,'Date, on which user was added to the system',NULL,'startDate','665011498'),(103,NULL,'Defines whether the user record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','665011491'),(104,NULL,'First Name of the User',NULL,'firstName','665011495'),(105,NULL,'Comments given by the approver.',NULL,'comments','665011492'),(106,NULL,'Login name for login into the system',NULL,'loginName','665011497'),(107,NULL,'Email address of the user',NULL,'emailAddress','665011494'),(108,NULL,NULL,NULL,'AssociationName_1',NULL),(109,NULL,NULL,NULL,'AssociationName_2',NULL),(110,NULL,NULL,NULL,'AssociationName_3',NULL),(111,NULL,NULL,NULL,'AssociationName_4',NULL),(112,'2007-10-10','This class maintains all the passwords corresponding to a user','2007-10-10','edu.wustl.catissuecore.domain.Password',NULL),(113,NULL,'Password for login into the system',NULL,'password','-2034531248'),(114,NULL,'Date on which this password was set',NULL,'updateDate','-2034531247'),(115,NULL,'System generated unique identifier.',NULL,'id','954196821'),(116,'2007-10-10','A set of attributes that defines the physical location of a User or Site','2007-10-10','edu.wustl.catissuecore.domain.Address',NULL),(117,NULL,'Fax number',NULL,'faxNumber','-253668781'),(118,NULL,'City',NULL,'city','-253668783'),(119,NULL,'State',NULL,'state','-253668779'),(120,NULL,'Zip code',NULL,'zipCode','-253668777'),(121,NULL,'Phone number',NULL,'phoneNumber','-253668780'),(122,NULL,'Country',NULL,'country','-253668782'),(123,NULL,'Multi-Line street address.',NULL,'street','-253668778'),(124,NULL,'System generated unique identifier.',NULL,'id','954196821'),(125,'2007-10-10','An institution to which a user belongs to.','2007-10-10','edu.wustl.catissuecore.domain.Institution',NULL),(126,NULL,'Name of the Institution.',NULL,'name','698955384'),(127,NULL,'System generated unique identifier.',NULL,'id','954196821'),(128,'2007-10-10','AÂ collection of scientist and/or clinician users with a common research objective related to biospecimen collection and utilization','2007-10-10','edu.wustl.catissuecore.domain.CancerResearchGroup',NULL),(129,NULL,'Name of the cancer research group.',NULL,'name','-898302170'),(130,NULL,'System generated unique identifier.',NULL,'id','954196821'),(131,'2007-10-10','A department to which a user belongs to','2007-10-10','edu.wustl.catissuecore.domain.Department',NULL),(132,NULL,'Name of the department',NULL,'name','938157387'),(133,NULL,'System generated unique identifier.',NULL,'id','954196821'),(134,'2007-10-10','A generic term which defines the template for different container types.','2007-10-10','edu.wustl.catissuecore.domain.ContainerType',NULL),(135,NULL,NULL,NULL,'AssociationName_1',NULL),(136,NULL,'Defines whether this continerType record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','-773971968'),(137,NULL,'Human understandable name assigned to dimension one.',NULL,'oneDimensionLabel','-773971965'),(138,NULL,'A written explanation about the container type.',NULL,'comment','-773971967'),(139,NULL,'Human understandable name assigned to dimension two.',NULL,'twoDimensionLabel','-773971964'),(140,NULL,'A human readable unique name assigned to container type.',NULL,'name','-773971966'),(141,NULL,'System generated unique identifier.',NULL,'id','954196821'),(142,'2007-10-10','Capacity defined for a storage container','2007-10-10','edu.wustl.catissuecore.domain.Capacity',NULL),(143,NULL,'Number of objects that can be stored in dimension one.',NULL,'oneDimensionCapacity','-1898352979'),(144,NULL,'Number of objects that can be stored in dimension two.',NULL,'twoDimensionCapacity','-1898352978'),(145,NULL,'System generated unique identifier.',NULL,'id','954196821'),(146,'2007-10-10','Defines a template for a storage container. The template can be used to define multiple storage containers.','2007-10-10','edu.wustl.catissuecore.domain.StorageType',NULL),(147,NULL,NULL,NULL,'AssociationName_3',NULL),(148,NULL,NULL,NULL,'AssociationName_2',NULL),(149,NULL,NULL,NULL,'AssociationName_1',NULL),(150,NULL,'Defines whether this continerType record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','-773971968'),(151,NULL,'Human understandable name assigned to dimension one.',NULL,'oneDimensionLabel','-773971965'),(152,NULL,'A written explanation about the container type.',NULL,'comment','-773971967'),(153,NULL,'Intended temperature of the storage container template.',NULL,'defaultTempratureInCentigrade','-1825881256'),(154,NULL,'Human understandable name assigned to dimension two.',NULL,'twoDimensionLabel','-773971964'),(155,NULL,'A human readable unique name assigned to container type.',NULL,'name','-773971966'),(156,NULL,'System generated unique identifier.',NULL,'id','954196821'),(157,'2007-10-10','Defines a template for a specimen array. The template can be used to define multiple SpecimenArray.','2007-10-10','edu.wustl.catissuecore.domain.SpecimenArrayType',NULL),(158,NULL,NULL,NULL,'AssociationName_1',NULL),(159,NULL,'Defines whether this continerType record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','-773971968'),(160,NULL,'Human understandable name assigned to dimension one.',NULL,'oneDimensionLabel','-773971965'),(161,NULL,'A written explanation about the container type.',NULL,'comment','-773971967'),(162,NULL,'Human understandable name assigned to dimension two.',NULL,'twoDimensionLabel','-773971964'),(163,NULL,'Defines the class of specimens that an array can hold. E.g. Molecular, Tissue, Fluid or Cell.',NULL,'specimenClass','-1260035607'),(164,NULL,'A human readable unique name assigned to container type.',NULL,'name','-773971966'),(165,NULL,'System generated unique identifier.',NULL,'id','954196821'),(166,'2007-10-10','A set of procedures that govern the collection and/or distribution of biospecimens','2007-10-10','edu.wustl.catissuecore.domain.SpecimenProtocol',NULL),(167,NULL,NULL,NULL,'AssociationName_1',NULL),(168,NULL,'Date on which the protocol is activated.',NULL,'startDate','81095906'),(169,NULL,'Full title assigned to the protocol',NULL,'title','81095907'),(170,NULL,'Defines whether this SpecimenProtocol record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','81095900'),(171,NULL,'IRB approval number.',NULL,'irbIdentifier','81095904'),(172,NULL,'Number of anticipated cases need for the protocol.',NULL,'enrollment','81095903'),(173,NULL,'Abbreviated title assigned to the protocol',NULL,'shortTitle','81095905'),(174,NULL,'URL to the document that describes detailed information for the biospecimen protocol.',NULL,'descriptionURL','81095901'),(175,NULL,'Date on which the protocol is marked as closed.',NULL,'endDate','81095902'),(176,NULL,'System generated unique identifier.',NULL,'id','954196821'),(177,'2007-10-10','A set of written procedures that describe how a biospecimen is prospectively collected from a participant.','2007-10-10','edu.wustl.catissuecore.domain.CollectionProtocol',NULL),(178,NULL,NULL,NULL,'AssociationName_4',NULL),(179,NULL,'System generated unique identifier.',NULL,'id','954196821'),(180,NULL,'Date on which the protocol is marked as closed.',NULL,'endDate','81095902'),(181,NULL,'URL to the document that describes detailed information for the biospecimen protocol.',NULL,'descriptionURL','81095901'),(182,NULL,'Abbreviated title assigned to the protocol',NULL,'shortTitle','81095905'),(183,NULL,'Number of anticipated cases need for the protocol.',NULL,'enrollment','81095903'),(184,NULL,'IRB approval number.',NULL,'irbIdentifier','81095904'),(185,NULL,'Check whether all aliquotes in specimens which belong to that CP in same container or not.',NULL,'aliquotInSameContainer','1316884367'),(186,NULL,'Defines whether this SpecimenProtocol record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','81095900'),(187,NULL,'Full title assigned to the protocol',NULL,'title','81095907'),(188,NULL,'Date on which the protocol is activated.',NULL,'startDate','81095906'),(189,NULL,NULL,NULL,'AssociationName_1',NULL),(190,NULL,NULL,NULL,'AssociationName_2',NULL),(191,NULL,NULL,NULL,'AssociationName_3',NULL),(192,'2007-10-10','An abbreviated set of written procedures that describe how a previously collected specimen will be utilized.  Note that specimen may be collected with one collection protocol and then later utilized by multiple different studies (Distribution protocol).','2007-10-10','edu.wustl.catissuecore.domain.DistributionProtocol',NULL),(193,NULL,NULL,NULL,'AssociationName_1',NULL),(194,NULL,'Date on which the protocol is activated.',NULL,'startDate','81095906'),(195,NULL,'Full title assigned to the protocol',NULL,'title','81095907'),(196,NULL,'Defines whether this SpecimenProtocol record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','81095900'),(197,NULL,'IRB approval number.',NULL,'irbIdentifier','81095904'),(198,NULL,'Number of anticipated cases need for the protocol.',NULL,'enrollment','81095903'),(199,NULL,'Abbreviated title assigned to the protocol',NULL,'shortTitle','81095905'),(200,NULL,'System generated unique identifier.',NULL,'id','954196821'),(201,NULL,'Date on which the protocol is marked as closed.',NULL,'endDate','81095902'),(202,NULL,'URL to the document that describes detailed information for the biospecimen protocol.',NULL,'descriptionURL','81095901'),(203,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ConsentTier',NULL),(204,NULL,NULL,NULL,'statement','442140730'),(205,NULL,'System generated unique identifier.',NULL,'id','954196821'),(220,'2007-10-10','The combined anatomic state of a specimen','2007-10-10','edu.wustl.catissuecore.domain.SpecimenCharacteristics',NULL),(221,NULL,'For bilateral sites, left or right',NULL,'tissueSide','2067377962'),(222,NULL,'The anatomical site from which a specimen is derived.',NULL,'tissueSite','2067377963'),(223,NULL,'System generated unique identifier.',NULL,'id','954196821'),(224,'2007-10-10','A molecular derivative (I.e. RNA / DNA / Protein Lysate) obtained from a specimen.','2007-10-10','edu.wustl.catissuecore.domain.MolecularSpecimen',NULL),(226,NULL,NULL,NULL,'AssociationName_20',NULL),(227,NULL,NULL,NULL,'AssociationName_19',NULL),(228,NULL,NULL,NULL,'AssociationName_18',NULL),(235,NULL,NULL,NULL,'AssociationName_11',NULL),(236,NULL,'System generated unique identifier.',NULL,'id','954196821'),(238,NULL,NULL,NULL,'collectionStatus','-292159954'),(240,NULL,'Is this specimen still physically available in the tissue bank?',NULL,'isAvailable','267670148'),(242,NULL,'Barcode assigned to the specimen.',NULL,'barcode','267670149'),(243,NULL,NULL,NULL,'createdOn','-292159956'),(245,NULL,'Human readable unique label/name assigned to specimen.',NULL,'label','267670151'),(246,NULL,'Defines whether this Specimen record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','267670147'),(248,NULL,'Comments on specimen.',NULL,'comment','267670150'),(249,NULL,'Concentration of liquid molecular specimen measured in microgram per microlitter.',NULL,'concentrationInMicrogramPerMicroliter','-1373132179'),(261,'2007-10-10','A biospecimen composed ofÂ purified single cells not in the context of a tissue or other biospecimen fluid','2007-10-10','edu.wustl.catissuecore.domain.CellSpecimen',NULL),(263,NULL,NULL,NULL,'AssociationName_20',NULL),(264,NULL,NULL,NULL,'AssociationName_19',NULL),(265,NULL,NULL,NULL,'AssociationName_18',NULL),(272,NULL,'System generated unique identifier.',NULL,'id','954196821'),(274,NULL,NULL,NULL,'collectionStatus','-292159954'),(276,NULL,'Is this specimen still physically available in the tissue bank?',NULL,'isAvailable','267670148'),(278,NULL,'Barcode assigned to the specimen.',NULL,'barcode','267670149'),(279,NULL,NULL,NULL,'createdOn','-292159956'),(281,NULL,'Human readable unique label/name assigned to specimen.',NULL,'label','267670151'),(282,NULL,'Defines whether this Specimen record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','267670147'),(284,NULL,'Comments on specimen.',NULL,'comment','267670150'),(296,NULL,NULL,NULL,'AssociationName_11',NULL),(297,'2007-10-10','A single unit of tissue specimen that is collected or created from a participant','2007-10-10','edu.wustl.catissuecore.domain.TissueSpecimen',NULL),(299,NULL,NULL,NULL,'AssociationName_20',NULL),(300,NULL,NULL,NULL,'AssociationName_19',NULL),(301,NULL,NULL,NULL,'AssociationName_18',NULL),(308,NULL,'System generated unique identifier.',NULL,'id','954196821'),(310,NULL,NULL,NULL,'collectionStatus','-292159954'),(312,NULL,'Is this specimen still physically available in the tissue bank?',NULL,'isAvailable','267670148'),(314,NULL,'Barcode assigned to the specimen.',NULL,'barcode','267670149'),(315,NULL,NULL,NULL,'createdOn','-292159956'),(317,NULL,'Human readable unique label/name assigned to specimen.',NULL,'label','267670151'),(318,NULL,'Defines whether this Specimen record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','267670147'),(320,NULL,'Comments on specimen.',NULL,'comment','267670150'),(332,NULL,NULL,NULL,'AssociationName_11',NULL),(333,'2007-10-10','A single unit of bodily fluid specimen that is collected or created from a Participant.','2007-10-10','edu.wustl.catissuecore.domain.FluidSpecimen',NULL),(335,NULL,NULL,NULL,'AssociationName_20',NULL),(336,NULL,NULL,NULL,'AssociationName_19',NULL),(337,NULL,NULL,NULL,'AssociationName_18',NULL),(344,NULL,'System generated unique identifier.',NULL,'id','954196821'),(346,NULL,NULL,NULL,'collectionStatus','-292159954'),(348,NULL,'Is this specimen still physically available in the tissue bank?',NULL,'isAvailable','267670148'),(350,NULL,'Barcode assigned to the specimen.',NULL,'barcode','267670149'),(351,NULL,NULL,NULL,'createdOn','-292159956'),(353,NULL,'Human readable unique label/name assigned to specimen.',NULL,'label','267670151'),(354,NULL,'Defines whether this Specimen record can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','267670147'),(356,NULL,'Comments on specimen.',NULL,'comment','267670150'),(368,NULL,NULL,NULL,'AssociationName_11',NULL),(369,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ConsentTierStatus',NULL),(370,NULL,NULL,NULL,'AssociationName_1',NULL),(371,NULL,NULL,NULL,'status','430779936'),(372,NULL,'System generated unique identifier.',NULL,'id','954196821'),(373,'2007-10-10','Represents a group of specimens collected from the same participant in the same accession event.','2007-10-10','edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',NULL),(374,NULL,NULL,NULL,'AssociationName_1',NULL),(375,NULL,'Participant\'s clinical diagnosis at this collection event (e.g. Prostate Adenocarcinoma).',NULL,'clinicalDiagnosis','764396574'),(376,NULL,'The clinical status of the participant at the time of specimen collection. (e.g. New DX, pre-RX, pre-OP, post-OP, remission, relapse)',NULL,'clinicalStatus','764396575'),(377,NULL,'Defines whether this record can be queried (Active) or not queried (Inactive) by any actor.',NULL,'activityStatus','764396573'),(378,NULL,'System generated unique identifier.',NULL,'id','954196821'),(379,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.SpecimenCollectionGroup',NULL),(380,NULL,NULL,NULL,'AssociationName_23',NULL),(381,NULL,NULL,NULL,'AssociationName_22',NULL),(382,NULL,NULL,NULL,'AssociationName_21',NULL),(383,NULL,NULL,NULL,'AssociationName_20',NULL),(384,NULL,NULL,NULL,'AssociationName_19',NULL),(385,NULL,NULL,NULL,'AssociationName_18',NULL),(386,NULL,NULL,NULL,'AssociationName_5',NULL),(387,NULL,NULL,NULL,'AssociationName_4',NULL),(388,NULL,NULL,NULL,'AssociationName_3',NULL),(389,NULL,NULL,NULL,'AssociationName_2',NULL),(390,NULL,NULL,NULL,'AssociationName_1',NULL),(392,NULL,NULL,NULL,'name','1689506864'),(393,NULL,'The clinical status of the participant at the time of specimen collection. (e.g. New DX, pre-RX, pre-OP, post-OP, remission, relapse)',NULL,'clinicalStatus','764396575'),(394,NULL,NULL,NULL,'surgicalPathologyNumber','1689506866'),(395,NULL,NULL,NULL,'collectionStatus','1689506867'),(396,NULL,NULL,NULL,'comment','1689506865'),(397,NULL,'Defines whether this record can be queried (Active) or not queried (Inactive) by any actor.',NULL,'activityStatus','764396573'),(398,NULL,'System generated unique identifier.',NULL,'id','954196821'),(399,NULL,NULL,NULL,'AssociationName_6',NULL),(400,NULL,NULL,NULL,'AssociationName_7',NULL),(401,NULL,NULL,NULL,'AssociationName_8',NULL),(402,NULL,NULL,NULL,'AssociationName_9',NULL),(403,NULL,NULL,NULL,'AssociationName_10',NULL),(404,NULL,NULL,NULL,'AssociationName_11',NULL),(405,NULL,NULL,NULL,'AssociationName_12',NULL),(406,NULL,NULL,NULL,'AssociationName_13',NULL),(407,NULL,NULL,NULL,'AssociationName_14',NULL),(408,NULL,NULL,NULL,'AssociationName_15',NULL),(409,NULL,NULL,NULL,'AssociationName_16',NULL),(410,NULL,NULL,NULL,'AssociationName_17',NULL),(411,'2007-10-10',NULL,'2007-10-10','Deprecated_EventParameters',NULL),(412,NULL,NULL,NULL,'timestamp','1342932196'),(413,NULL,NULL,NULL,'comment','1342932195'),(414,NULL,'System generated unique identifier.',NULL,'id','954196821'),(415,'2007-10-10','Attributes associated with a specific specimen event','2007-10-10','edu.wustl.catissuecore.domain.SpecimenEventParameters',NULL),(421,NULL,NULL,NULL,'AssociationName_1',NULL),(422,NULL,NULL,NULL,'timestamp','1342932196'),(423,NULL,NULL,NULL,'comment','1342932195'),(424,NULL,'System generated unique identifier.',NULL,'id','954196821'),(425,'2007-10-10','Parameters/information required to capture in any event performed on a specimen','2007-10-10','edu.wustl.catissuecore.domain.SpunEventParameters',NULL),(431,NULL,NULL,NULL,'AssociationName_1',NULL),(432,NULL,NULL,NULL,'timestamp','1342932196'),(433,NULL,'Duration for which specimen is spun.',NULL,'durationInMinutes','-1869761580'),(434,NULL,NULL,NULL,'comment','1342932195'),(435,NULL,'Rotational force applied to specimen.',NULL,'gravityForce','-1869761579'),(436,NULL,'System generated unique identifier.',NULL,'id','954196821'),(437,'2007-10-10','An abbreviated set of written procedures that describe how a previously collected specimen will be utilized.  Note that specimen may be collected with one collection protocol and then later utilized by multiple different studies (Distribution protocol)','2007-10-10','edu.wustl.catissuecore.domain.EmbeddedEventParameters',NULL),(443,NULL,NULL,NULL,'AssociationName_1',NULL),(444,NULL,NULL,NULL,'timestamp','1342932196'),(445,NULL,'Type of medium in which specimen is embedded.',NULL,'embeddingMedium','-1726269120'),(446,NULL,NULL,NULL,'comment','1342932195'),(447,NULL,'System generated unique identifier.',NULL,'id','954196821'),(448,'2007-10-10','Attributes associated with a thawing event of a specimen','2007-10-10','edu.wustl.catissuecore.domain.ThawEventParameters',NULL),(454,NULL,NULL,NULL,'AssociationName_1',NULL),(455,NULL,NULL,NULL,'timestamp','1342932196'),(456,NULL,NULL,NULL,'comment','1342932195'),(457,NULL,'System generated unique identifier.',NULL,'id','954196821'),(458,'2007-10-10','Attributes associated with a fixation event of a specimen.','2007-10-10','edu.wustl.catissuecore.domain.FixedEventParameters',NULL),(464,NULL,NULL,NULL,'AssociationName_1',NULL),(465,NULL,NULL,NULL,'timestamp','1342932196'),(466,NULL,'Type of the fixation.',NULL,'fixationType','-1038307716'),(467,NULL,'Duration, measured in minutes, for which fixation is performed on specimen.',NULL,'durationInMinutes','-1038307717'),(468,NULL,NULL,NULL,'comment','1342932195'),(469,NULL,'System generated unique identifier.',NULL,'id','954196821'),(470,'2007-10-10','Attributes associated with moving specimen from one storage location to another','2007-10-10','edu.wustl.catissuecore.domain.TransferEventParameters',NULL),(473,NULL,'System generated unique identifier.',NULL,'id','954196821'),(474,NULL,'Reference to dimensional position one of the specimen in new storage container after transfer.',NULL,'toPositionDimensionOne','1083378935'),(475,NULL,'Reference to dimensional position one of the specimen in previous storage container before transfer.',NULL,'fromPositionDimensionOne','1083378933'),(476,NULL,'Reference to dimensional position two of the specimen in new storage container after transfer.',NULL,'toPositionDimensionTwo','1083378936'),(477,NULL,NULL,NULL,'comment','1342932195'),(478,NULL,'Reference to dimensional position two of the specimen in previous storage container before transfer.',NULL,'fromPositionDimensionTwo','1083378934'),(479,NULL,NULL,NULL,'timestamp','1342932196'),(480,NULL,NULL,NULL,'AssociationName_1',NULL),(481,NULL,NULL,NULL,'AssociationName_2',NULL),(482,NULL,NULL,NULL,'AssociationName_3',NULL),(486,'2007-10-10','Attributes associated with the received event of a specimen','2007-10-10','edu.wustl.catissuecore.domain.ReceivedEventParameters',NULL),(492,NULL,NULL,NULL,'AssociationName_1',NULL),(493,NULL,NULL,NULL,'timestamp','1342932196'),(494,NULL,'Grossly evaluated quality of the received specimen.',NULL,'receivedQuality','-958585133'),(495,NULL,NULL,NULL,'comment','1342932195'),(496,NULL,'System generated unique identifier.',NULL,'id','954196821'),(497,'2007-10-10','A binary event to indicate whether a specimen has been removed from or returned to its recorded storage location','2007-10-10','edu.wustl.catissuecore.domain.CheckInCheckOutEventParameter',NULL),(503,NULL,NULL,NULL,'AssociationName_1',NULL),(504,NULL,NULL,NULL,'timestamp','1342932196'),(505,NULL,NULL,NULL,'comment','1342932195'),(506,NULL,'Type of the movement e.g. Check-in or Check-out.',NULL,'storageStatus','-1525879905'),(507,NULL,'System generated unique identifier.',NULL,'id','954196821'),(508,'2007-10-10','Attributes related to quality review event of a specimen','2007-10-10','edu.wustl.catissuecore.domain.ReviewEventParameters',NULL),(514,NULL,NULL,NULL,'AssociationName_1',NULL),(515,NULL,NULL,NULL,'timestamp','1342932196'),(516,NULL,NULL,NULL,'comment','1342932195'),(517,NULL,'System generated unique identifier.',NULL,'id','954196821'),(518,'2007-10-10','Attributes associated with a review event of a molecular specimen.','2007-10-10','edu.wustl.catissuecore.domain.MolecularSpecimenReviewParameters',NULL),(522,NULL,'System generated unique identifier.',NULL,'id','954196821'),(523,NULL,'A reference to the location of an electrophoretic gel image of the specimen.',NULL,'gelImageURL','1623057499'),(524,NULL,' A unit less ratio of the full-length 28S to 18S ribosomal RNA mass that is detected in a mammalian cellular RNA sample.',NULL,'ratio28STo18S','1623057503'),(525,NULL,NULL,NULL,'comment','1342932195'),(526,NULL,'The lane number within the electrophoretic gel image that corresponds to the specimen.',NULL,'laneNumber','1623057501'),(527,NULL,'A number corresponding to the gel on which the specimen was analyzed for QA purposes.',NULL,'gelNumber','1623057500'),(528,NULL,'A normalized quality score that indicates the integrity of the specimen.',NULL,'qualityIndex','1623057502'),(529,NULL,'Absorbance of the specimen at 280 nanometers.',NULL,'absorbanceAt280','1623057498'),(530,NULL,'Absorbance of the specimen at 260 nanometers.',NULL,'absorbanceAt260','1623057497'),(531,NULL,NULL,NULL,'timestamp','1342932196'),(532,NULL,NULL,NULL,'AssociationName_1',NULL),(535,'2007-10-10','Attributes associated with a review event of a tissue specimen','2007-10-10','edu.wustl.catissuecore.domain.TissueSpecimenReviewEventParameters',NULL),(537,NULL,'Histological Quality of the specimen.',NULL,'histologicalQuality','-1289839130'),(538,NULL,'System generated unique identifier.',NULL,'id','954196821'),(539,NULL,'Percentage of total cellularity of the specimen.  Note that TOTCELL-NEOCELL-LYMPHCELL= % cellularity of other stromal, etc. cell types.  Also Note that 100-TOTCELL-NECROSIS= % of tissue containing a cellular material',NULL,'totalCellularityPercentage','-1289839126'),(540,NULL,'Percentage of histologically evident neoplastic cells present in the tissue specimen.',NULL,'neoplasticCellularityPercentage','-1289839127'),(541,NULL,NULL,NULL,'comment','1342932195'),(542,NULL,'Percentage of specimen that is histologically necrotic.',NULL,'necrosisPercentage','-1289839128'),(543,NULL,'Percentage of histologically evident lymphocytes in the tissue specimen.',NULL,'lymphocyticPercentage','-1289839129'),(544,NULL,NULL,NULL,'timestamp','1342932196'),(545,NULL,NULL,NULL,'AssociationName_1',NULL),(550,'2007-10-10','Attributes associated with a review event of a cell specimen','2007-10-10','edu.wustl.catissuecore.domain.CellSpecimenReviewParameters',NULL),(556,NULL,NULL,NULL,'AssociationName_1',NULL),(557,NULL,NULL,NULL,'timestamp','1342932196'),(558,NULL,NULL,NULL,'comment','1342932195'),(559,NULL,'Percentage of histologically evident neoplastic cells present in the specimen.',NULL,'neoplasticCellularityPercentage','1641846667'),(560,NULL,'Percentage of viable cells in the specimen.',NULL,'viableCellPercentage','1641846668'),(561,NULL,'System generated unique identifier.',NULL,'id','954196821'),(562,'2007-10-10','Attributes associated with a review event of a fluid specimen.','2007-10-10','edu.wustl.catissuecore.domain.FluidSpecimenReviewEventParameters',NULL),(568,NULL,NULL,NULL,'AssociationName_1',NULL),(569,NULL,NULL,NULL,'timestamp','1342932196'),(570,NULL,NULL,NULL,'comment','1342932195'),(571,NULL,'Number of cell present in fluid specimen.',NULL,'cellCount','-337597097'),(572,NULL,'System generated unique identifier.',NULL,'id','954196821'),(573,'2007-10-10','Attributes related to disposal event of a specimen','2007-10-10','edu.wustl.catissuecore.domain.DisposalEventParameters',NULL),(579,NULL,NULL,NULL,'AssociationName_1',NULL),(580,NULL,NULL,NULL,'timestamp','1342932196'),(581,NULL,NULL,NULL,'comment','1342932195'),(582,NULL,'The reason for which the specimen is disposed.',NULL,'reason','171271555'),(583,NULL,'System generated unique identifier.',NULL,'id','954196821'),(584,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.ClinicalProcedureEventParameterSet',NULL),(585,NULL,NULL,NULL,'AssociationName_6',NULL),(586,NULL,NULL,NULL,'AssociationName_5',NULL),(587,NULL,NULL,NULL,'AssociationName_4',NULL),(588,NULL,NULL,NULL,'AssociationName_3',NULL),(589,NULL,NULL,NULL,'AssociationName_2',NULL),(590,NULL,NULL,NULL,'AssociationName_1',NULL),(591,NULL,NULL,NULL,'timestamp','1342932196'),(592,NULL,NULL,NULL,'comment','1342932195'),(593,NULL,NULL,NULL,'procedureName','-1608958318'),(594,NULL,'System generated unique identifier.',NULL,'id','954196821'),(595,'2007-10-10','Attributes associated with a customized procedure that is applied on a specimen to process it','2007-10-10','edu.wustl.catissuecore.domain.ProcedureEventParameters',NULL),(601,NULL,NULL,NULL,'AssociationName_1',NULL),(602,NULL,NULL,NULL,'timestamp','1342932196'),(603,NULL,'URL to the document that describes detail information of customized process.',NULL,'url','1848736750'),(604,NULL,'Name of the customized procedure.',NULL,'name','1848736749'),(605,NULL,NULL,NULL,'comment','1342932195'),(606,NULL,'System generated unique identifier.',NULL,'id','954196821'),(607,'2007-10-10','Attributes associated with a freezing event of a specimen.','2007-10-10','edu.wustl.catissuecore.domain.FrozenEventParameters',NULL),(613,NULL,NULL,NULL,'AssociationName_1',NULL),(614,NULL,NULL,NULL,'timestamp','1342932196'),(615,NULL,'Method applied on specimen to freeze it.',NULL,'method','-2072430174'),(616,NULL,NULL,NULL,'comment','1342932195'),(617,NULL,'System generated unique identifier.',NULL,'id','954196821'),(618,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ReturnEventParameters',NULL),(619,NULL,NULL,NULL,'AssociationName_6',NULL),(620,NULL,NULL,NULL,'AssociationName_5',NULL),(621,NULL,NULL,NULL,'AssociationName_4',NULL),(622,NULL,NULL,NULL,'AssociationName_3',NULL),(623,NULL,NULL,NULL,'AssociationName_2',NULL),(624,NULL,NULL,NULL,'AssociationName_1',NULL),(625,NULL,NULL,NULL,'timestamp','1342932196'),(626,NULL,NULL,NULL,'comment','1342932195'),(627,NULL,'System generated unique identifier.',NULL,'id','954196821'),(628,'2007-10-10','Attributes associated with the collection event of a specimen from participant','2007-10-10','edu.wustl.catissuecore.domain.CollectionEventParameters',NULL),(634,NULL,NULL,NULL,'AssociationName_1',NULL),(635,NULL,NULL,NULL,'timestamp','1342932196'),(636,NULL,NULL,NULL,'comment','1342932195'),(637,NULL,'Container type in which specimen is collected (e.g. clot tube, KEDTA, ACD, sterile specimen cup)',NULL,'container','-1851892381'),(638,NULL,'Method of specimen collection from participant (e.g. needle biopsy, central venous line, bone marrow aspiration)',NULL,'collectionProcedure','-1851892382'),(639,NULL,'System generated unique identifier.',NULL,'id','954196821'),(640,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport',NULL),(641,NULL,NULL,NULL,'AssociationName_5',NULL),(642,NULL,NULL,NULL,'AssociationName_4',NULL),(643,NULL,NULL,NULL,'AssociationName_3',NULL),(644,NULL,NULL,NULL,'AssociationName_2',NULL),(645,NULL,NULL,NULL,'AssociationName_1',NULL),(646,NULL,NULL,NULL,'collectionDateTime','-1194750317'),(647,NULL,NULL,NULL,'isFlagForReview','-1194750318'),(648,NULL,NULL,NULL,'activityStatus','-1194750319'),(649,NULL,'System generated unique identifier.',NULL,'id','954196821'),(650,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.ReportContent',NULL),(651,NULL,NULL,NULL,'data','62027063'),(652,NULL,'System generated unique identifier.',NULL,'id','954196821'),(653,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.TextContent',NULL),(654,NULL,NULL,NULL,'AssociationName_1',NULL),(655,NULL,NULL,NULL,'data','62027063'),(656,NULL,'System generated unique identifier.',NULL,'id','954196821'),(657,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.ReportSection',NULL),(658,NULL,NULL,NULL,'documentFragment','-1730492489'),(659,NULL,NULL,NULL,'endOffSet','-1730492491'),(660,NULL,NULL,NULL,'name','-1730492490'),(661,NULL,NULL,NULL,'startOffSet','-1730492492'),(662,NULL,'System generated unique identifier.',NULL,'id','954196821'),(663,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.BinaryContent',NULL),(664,NULL,NULL,NULL,'data','62027063'),(665,NULL,'System generated unique identifier.',NULL,'id','954196821'),(666,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',NULL),(667,NULL,NULL,NULL,'timestamp','1342932196'),(668,NULL,NULL,NULL,'comment','1342932195'),(669,NULL,NULL,NULL,'reviewerRole','-651113568'),(670,NULL,'System generated unique identifier.',NULL,'id','954196821'),(671,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.XMLContent',NULL),(672,NULL,NULL,NULL,'data','62027063'),(673,NULL,'System generated unique identifier.',NULL,'id','954196821'),(674,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport',NULL),(675,NULL,NULL,NULL,'AssociationName_6',NULL),(676,NULL,NULL,NULL,'AssociationName_5',NULL),(677,NULL,NULL,NULL,'AssociationName_4',NULL),(678,NULL,NULL,NULL,'AssociationName_3',NULL),(679,NULL,NULL,NULL,'AssociationName_2',NULL),(680,NULL,NULL,NULL,'AssociationName_1',NULL),(681,NULL,NULL,NULL,'collectionDateTime','-1194750317'),(682,NULL,NULL,NULL,'isFlagForReview','-1194750318'),(683,NULL,NULL,NULL,'activityStatus','-1194750319'),(684,NULL,'System generated unique identifier.',NULL,'id','954196821'),(685,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.DeidentifiedSurgicalPathologyReport',NULL),(686,NULL,NULL,NULL,'AssociationName_7',NULL),(687,NULL,NULL,NULL,'AssociationName_6',NULL),(688,NULL,NULL,NULL,'AssociationName_5',NULL),(689,NULL,NULL,NULL,'AssociationName_4',NULL),(690,NULL,NULL,NULL,'AssociationName_3',NULL),(691,NULL,NULL,NULL,'AssociationName_2',NULL),(692,NULL,NULL,NULL,'AssociationName_1',NULL),(693,NULL,NULL,NULL,'collectionDateTime','-1194750317'),(694,NULL,NULL,NULL,'isFlagForReview','-1194750318'),(695,NULL,NULL,NULL,'isQuanrantined','208328075'),(696,NULL,NULL,NULL,'activityStatus','-1194750319'),(697,NULL,'System generated unique identifier.',NULL,'id','954196821'),(698,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.ConceptReferent',NULL),(699,NULL,NULL,NULL,'AssociationName_2',NULL),(700,NULL,NULL,NULL,'AssociationName_1',NULL),(701,NULL,NULL,NULL,'isNegated','-205967396'),(702,NULL,NULL,NULL,'isModifier','-205967397'),(703,NULL,NULL,NULL,'startOffset','-205967399'),(704,NULL,'System generated unique identifier.',NULL,'id','954196821'),(705,NULL,NULL,NULL,'endOffset','-205967398'),(706,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.ConceptReferentClassification',NULL),(707,NULL,NULL,NULL,'name','-390351776'),(708,NULL,'System generated unique identifier.',NULL,'id','954196821'),(709,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.Concept',NULL),(710,NULL,NULL,NULL,'AssociationName_1',NULL),(711,NULL,NULL,NULL,'name','1663297633'),(712,NULL,NULL,NULL,'conceptUniqueIdentifier','1663297632'),(713,NULL,'System generated unique identifier.',NULL,'id','954196821'),(714,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.SemanticType',NULL),(715,NULL,NULL,NULL,'label','-350595627'),(716,NULL,'System generated unique identifier.',NULL,'id','954196821'),(717,'2007-10-10','Represent the point of time at which one or more specimens are collected from a participant with respect to the collection protocol.','2007-10-10','edu.wustl.catissuecore.domain.CollectionProtocolEvent',NULL),(718,NULL,NULL,NULL,'AssociationName_1',NULL),(719,NULL,NULL,NULL,'collectionPointLabel','1509710862'),(720,NULL,'Defines the relative time point in days, with respect to the registration date of participant on this protocol, when the specimen should be collected from participant.',NULL,'studyCalendarEventPoint','1509710861'),(721,NULL,'System generated unique identifier.',NULL,'id','954196821'),(729,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.OrderItem',NULL),(735,NULL,NULL,NULL,'AssociationName_2',NULL),(737,NULL,NULL,NULL,'description','-993611043'),(738,NULL,NULL,NULL,'status','-993611044'),(739,NULL,'System generated unique identifier.',NULL,'id','954196821'),(740,'2007-10-10','Represents the item, specimen, that is distributed in a distribution event.','2007-10-10','edu.wustl.catissuecore.domain.DistributedItem',NULL),(741,NULL,'System generated unique identifier.',NULL,'id','954196821'),(742,NULL,NULL,NULL,'AssociationName_1',NULL),(748,NULL,NULL,NULL,'AssociationName_7',NULL),(753,NULL,NULL,NULL,'AssociationName_12',NULL),(754,'2007-10-10','An event that results in transfer of a specimen from a repository to a laboratory or another repository','2007-10-10','edu.wustl.catissuecore.domain.Distribution',NULL),(755,NULL,NULL,NULL,'AssociationName_3',NULL),(756,NULL,NULL,NULL,'AssociationName_2',NULL),(757,NULL,NULL,NULL,'AssociationName_1',NULL),(758,NULL,'Text comments on event',NULL,'comment','-2023216065'),(759,NULL,'Date and time of the distribution',NULL,'timestamp','-2023216064'),(760,NULL,'Defines whether this distribution can be queried (Active) or not queried (Inactive) by any actor',NULL,'activityStatus','-2023216066'),(761,NULL,'System generated unique identifier.',NULL,'id','954196821'),(762,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.OrderDetails',NULL),(763,NULL,NULL,NULL,'AssociationName_2',NULL),(764,NULL,NULL,NULL,'AssociationName_1',NULL),(765,NULL,NULL,NULL,'name','1287989791'),(766,NULL,NULL,NULL,'status','1287989793'),(767,NULL,NULL,NULL,'requestedDate','1287989792'),(768,NULL,NULL,NULL,'comment','1287989794'),(769,NULL,'System generated unique identifier.',NULL,'id','954196821'),(770,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.SpecimenOrderItem',NULL),(776,NULL,NULL,NULL,'AssociationName_2',NULL),(778,NULL,NULL,NULL,'description','-993611043'),(779,NULL,NULL,NULL,'status','-993611044'),(780,NULL,'System generated unique identifier.',NULL,'id','954196821'),(781,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.NewSpecimenOrderItem',NULL),(787,NULL,NULL,NULL,'AssociationName_2',NULL),(789,NULL,NULL,NULL,'description','-993611043'),(790,NULL,NULL,NULL,'specimenClass','-538097170'),(791,NULL,NULL,NULL,'specimenType','-538097171'),(792,NULL,NULL,NULL,'status','-993611044'),(793,NULL,'System generated unique identifier.',NULL,'id','954196821'),(794,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.PathologicalCaseOrderItem',NULL),(799,NULL,'System generated unique identifier.',NULL,'id','954196821'),(800,NULL,NULL,NULL,'status','-993611044'),(801,NULL,NULL,NULL,'pathologicalStatus','773892354'),(802,NULL,NULL,NULL,'specimenType','-538097171'),(803,NULL,NULL,NULL,'specimenClass','-538097170'),(804,NULL,NULL,NULL,'description','-993611043'),(805,NULL,NULL,NULL,'tissueSite','773892355'),(807,NULL,NULL,NULL,'AssociationName_2',NULL),(808,NULL,NULL,NULL,'AssociationName_3',NULL),(809,NULL,NULL,NULL,'AssociationName_4',NULL),(812,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem',NULL),(817,NULL,'System generated unique identifier.',NULL,'id','954196821'),(818,NULL,NULL,NULL,'status','-993611044'),(819,NULL,NULL,NULL,'specimenType','-538097171'),(820,NULL,NULL,NULL,'specimenClass','-538097170'),(821,NULL,NULL,NULL,'description','-993611043'),(823,NULL,NULL,NULL,'AssociationName_2',NULL),(824,NULL,NULL,NULL,'AssociationName_3',NULL),(825,NULL,NULL,NULL,'AssociationName_4',NULL),(826,NULL,NULL,NULL,'AssociationName_5',NULL),(827,NULL,NULL,NULL,'AssociationName_6',NULL),(828,NULL,NULL,NULL,'AssociationName_7',NULL),(830,'2007-10-10','A registration of a Participant to a Collection Protocol','2007-10-10','edu.wustl.catissuecore.domain.CollectionProtocolRegistration',NULL),(831,NULL,NULL,NULL,'AssociationName_5',NULL),(832,NULL,NULL,NULL,'AssociationName_4',NULL),(833,NULL,NULL,NULL,'AssociationName_3',NULL),(834,NULL,NULL,NULL,'AssociationName_2',NULL),(835,NULL,NULL,NULL,'AssociationName_1',NULL),(836,NULL,'Defines whether this  record can be queried (Active) or not queried (Inactive) by any actor.',NULL,'activityStatus','594242662'),(837,NULL,'A unique number given by a User to a Participant registered to a Collection Protocol.',NULL,'protocolParticipantIdentifier','594242663'),(838,NULL,'System generated unique identifier.',NULL,'id','954196821'),(839,NULL,'Date on which the Participant is registered to the Collection Protocol.',NULL,'registrationDate','594242664'),(840,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ConsentTierResponse',NULL),(841,NULL,NULL,NULL,'AssociationName_1',NULL),(842,NULL,NULL,NULL,'response','-1307552339'),(843,NULL,'System generated unique identifier.',NULL,'id','954196821'),(844,'2007-10-10','The patient whose sample is collected and is under medical investigation.','2007-10-10','edu.wustl.catissuecore.domain.Participant',NULL),(845,NULL,'Participant\'s ethnicity status',NULL,'ethnicity','342735700'),(846,NULL,'Participants last name',NULL,'lastName','342735703'),(847,NULL,'The birth date of the participant',NULL,'birthDate','342735698'),(848,NULL,'System generated unique identifier.',NULL,'id','954196821'),(849,NULL,'Vital status (Alive, Dead, Unknown) of the participant.',NULL,'vitalStatus','2034872095'),(850,NULL,'Participants first name',NULL,'firstName','342735701'),(851,NULL,'Participant\'s middle name',NULL,'middleName','342735704'),(852,NULL,'The assemblage of properties that distinguish people on the basis of their societal roles. e.g. Male, Female',NULL,'gender','342735702'),(853,NULL,'Social Security Number of participant.',NULL,'socialSecurityNumber','2034872094'),(854,NULL,'The activity status of the participant',NULL,'activityStatus','342735697'),(855,NULL,'Death date of the participant',NULL,'deathDate','342735699'),(856,NULL,'The genetic constitution of the individual; the characterization of the genes. XX Genotype, XY Genotype etc.',NULL,'sexGenotype','342735706'),(857,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.SpecimenArrayOrderItem',NULL),(863,NULL,NULL,NULL,'AssociationName_2',NULL),(865,NULL,NULL,NULL,'description','-993611043'),(866,NULL,NULL,NULL,'status','-993611044'),(867,NULL,'System generated unique identifier.',NULL,'id','954196821'),(868,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem',NULL),(873,NULL,NULL,NULL,'status','-993611044'),(874,NULL,'System generated unique identifier.',NULL,'id','954196821'),(875,NULL,NULL,NULL,'description','-993611043'),(876,NULL,NULL,NULL,'name','995916914'),(878,NULL,NULL,NULL,'AssociationName_2',NULL),(879,NULL,NULL,NULL,'AssociationName_3',NULL),(880,NULL,NULL,NULL,'AssociationName_4',NULL),(881,NULL,NULL,NULL,'AssociationName_5',NULL),(882,NULL,NULL,NULL,'AssociationName_6',NULL),(883,NULL,NULL,NULL,'AssociationName_7',NULL),(884,NULL,NULL,NULL,'AssociationName_8',NULL),(886,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem',NULL),(889,NULL,'System generated unique identifier.',NULL,'id','954196821'),(890,NULL,NULL,NULL,'status','-993611044'),(891,NULL,NULL,NULL,'description','-993611043'),(892,NULL,NULL,NULL,'AssociationName_1',NULL),(893,NULL,NULL,NULL,'AssociationName_2',NULL),(894,NULL,NULL,NULL,'AssociationName_3',NULL),(895,NULL,NULL,NULL,'AssociationName_4',NULL),(896,NULL,NULL,NULL,'AssociationName_5',NULL),(898,NULL,NULL,NULL,'AssociationName_7',NULL),(902,'2007-10-10','A pre-existing, externally defined identifier associated with a specimen.','2007-10-10','edu.wustl.catissuecore.domain.ExternalIdentifier',NULL),(903,NULL,NULL,NULL,'AssociationName_5',NULL),(904,NULL,NULL,NULL,'AssociationName_4',NULL),(905,NULL,NULL,NULL,'AssociationName_3',NULL),(906,NULL,NULL,NULL,'AssociationName_2',NULL),(907,NULL,NULL,NULL,'AssociationName_1',NULL),(908,NULL,'Name of the legacy identifier.',NULL,'name','-431369380'),(909,NULL,'Value of the legacy identifier.',NULL,'value','-431369379'),(910,NULL,'System generated unique identifier.',NULL,'id','954196821'),(911,'2007-10-10','A detailed log of query entered by user.Queries which are used to fetch the data will be stored here only.','2007-10-10','edu.wustl.catissuecore.domain.AuditEventQueryLog',NULL),(912,NULL,NULL,NULL,'AssociationName_1',NULL),(913,NULL,'System Generated Unique Identifier',NULL,'id','29383513'),(914,NULL,'Query details enetered by user stored as log details',NULL,'queryDetails','29383514'),(915,'2007-10-10','A detailed log of an auditEventLog, AuditEventDetails captures the changes with one attribute of software object/entity.','2007-10-10','Deprecated_AuditEvent',NULL),(916,NULL,NULL,NULL,'AssociationName_1',NULL),(917,NULL,'Date and time of the event.',NULL,'timestamp','673208993'),(918,NULL,'User id who performed the changes in the system.',NULL,'userId','673208994'),(919,NULL,'IP address or domain name of the computer system from which the event is performed.',NULL,'ipAddress','673208992'),(920,NULL,'System generated unique identifier.',NULL,'id','954196821'),(921,'2007-10-10','A detailed log of an audit event, as in one audit event multiple software objects/entities can be modified. AuditEventLog captures the changes with one software object/entity.','2007-10-10','Deprecated_AuditEventLog',NULL),(922,NULL,'Type of the event e.g. Add, edit, delete.',NULL,'eventType','1567171779'),(923,NULL,'Identifier of the software object/entity, available in the system, for which changes are tracked in the AuditEventLog.',NULL,'objectIdentifier','1567171780'),(924,NULL,'System generated unique identifier.',NULL,'id','954196821'),(925,NULL,'Name of the software object/entity in the system for which changes are tracked in the AuditEventLog.',NULL,'objectName','1567171781'),(926,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.pathology.QuarantineEventParameter',NULL),(927,NULL,NULL,NULL,'AssociationName_1',NULL),(928,NULL,NULL,NULL,'timestamp','1342932196'),(929,NULL,NULL,NULL,'comment','1342932195'),(930,NULL,NULL,NULL,'quarantineStatus','914480659'),(931,NULL,'System generated unique identifier.',NULL,'id','954196821'),(932,'2007-10-10','Represents the required properties of a specimen while collecting and distributing it. SpecimenRequirement are defined in collection and distribution protocol.','2007-10-10','edu.wustl.catissuecore.domain.DistributionSpecimenRequirement',NULL),(933,NULL,NULL,NULL,'AssociationName_6',NULL),(939,NULL,'Anatomic site from which the specimen should be derived.',NULL,'tissueSite','766103332'),(940,NULL,'Type of the specimen required. e.g. Serum, Plasma, Blood, Fresh Tissue etc.',NULL,'specimenType','766103331'),(941,NULL,'Required type of the specimen e.g. Tissue, Molecular, Fluid or Cell.',NULL,'specimenClass','766103330'),(942,NULL,'System generated unique identifier.',NULL,'id','954196821'),(943,NULL,'Histopathological character of the specimen required at the time of collection/distribution. e.g. Non-Malignant, Malignant, Non-Malignant Diseased, Pre-Malignant.',NULL,'pathologyStatus','766103329'),(944,'2007-10-10','A medical record identification number that refers to a Participant','2007-10-10','edu.wustl.catissuecore.domain.ParticipantMedicalIdentifier',NULL),(945,NULL,NULL,NULL,'AssociationName_2',NULL),(946,NULL,NULL,NULL,'AssociationName_1',NULL),(947,NULL,'Participant\'s medical record number used in their medical treatment.',NULL,'medicalRecordNumber','-1016853852'),(948,NULL,'System generated unique identifier.',NULL,'id','954196821'),(949,'2007-10-10','An entity that defines the contents of a specimen array. It represents what all and how different specimens are arranged in a specimen array.','2007-10-10','edu.wustl.catissuecore.domain.SpecimenArrayContent',NULL),(950,NULL,NULL,NULL,'AssociationName_11',NULL),(952,NULL,'System generated unique identifier.',NULL,'id','954196821'),(953,NULL,'Reference to dimensional position two, of the specimen in a two dimensional specimen array.',NULL,'positionDimensionTwo','1875387783'),(954,NULL,'Reference to dimensional position one, of the specimen in a two dimensional specimen array.',NULL,'positionDimensionOne','1875387782'),(955,NULL,'Concentration of liquid molecular specimen in the array measured in microgram per microlitter.',NULL,'concentrationInMicrogramPerMicroliter','1875387781'),(961,NULL,NULL,NULL,'AssociationName_6',NULL),(965,'2007-10-10','An attribute of a specimen that renders it potentially harmful to a user','2007-10-10','edu.wustl.catissuecore.domain.Biohazard',NULL),(966,NULL,NULL,NULL,'AssociationName_5',NULL),(967,NULL,NULL,NULL,'AssociationName_4',NULL),(968,NULL,NULL,NULL,'AssociationName_3',NULL),(969,NULL,NULL,NULL,'AssociationName_2',NULL),(970,NULL,NULL,NULL,'AssociationName_1',NULL),(971,NULL,'Comments about the biohazard.',NULL,'comment','-1980709029'),(972,NULL,'Name of the biohazardous agent.',NULL,'name','-1980709028'),(973,NULL,'System generated unique identifier.',NULL,'id','954196821'),(974,NULL,'Type of biohazard (Infectious, Radioactive, Toxic, Carcinogen, Mutagen).',NULL,'type','-1980709027'),(975,'2007-10-10','Attributes associated with an AuditEvent','2007-10-10','Deprecated_AuditEventDetails',NULL),(976,NULL,NULL,NULL,'AssociationName_1',NULL),(977,NULL,'Value of the attribute before change.',NULL,'previousValue','1902279357'),(978,NULL,'Attribute name on which event is performed.',NULL,'elementName','1902279356'),(979,NULL,'System generated unique identifier.',NULL,'id','954196821'),(980,NULL,'Value of the attribute after change.',NULL,'currentValue','1902279355'),(981,'2007-10-10',NULL,'2007-10-10','edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem',NULL),(987,NULL,NULL,NULL,'AssociationName_3',NULL),(988,NULL,NULL,NULL,'AssociationName_2',NULL),(990,NULL,NULL,NULL,'description','-993611043'),(991,NULL,NULL,NULL,'status','-993611044'),(992,NULL,'System generated unique identifier.',NULL,'id','954196821'),(993,NULL,NULL,NULL,'AssociationName_1965',NULL),(994,NULL,NULL,NULL,'AssociationName_1902',NULL),(996,NULL,NULL,NULL,'AssociationName_2618',NULL),(999,NULL,NULL,NULL,'AssociationName_2584',NULL),(1005,NULL,NULL,NULL,'AssociationName_134',NULL),(1029,NULL,NULL,NULL,'AssociationName_2177',NULL),(1030,NULL,NULL,NULL,'AssociationName_4830',NULL),(1031,NULL,NULL,NULL,'AssociationName_1717',NULL),(1033,NULL,NULL,NULL,'AssociationName_3177',NULL),(1034,NULL,NULL,NULL,'AssociationName_2965',NULL),(1035,NULL,NULL,NULL,'AssociationName_2902',NULL),(1038,NULL,NULL,NULL,'AssociationName_3618',NULL),(1041,NULL,NULL,NULL,'AssociationName_3584',NULL),(1060,NULL,NULL,NULL,'AssociationName_3965',NULL),(1061,NULL,NULL,NULL,'AssociationName_3902',NULL),(1065,NULL,NULL,NULL,'AssociationName_4618',NULL),(1068,NULL,NULL,NULL,'AssociationName_4584',NULL),(1086,NULL,NULL,NULL,'AssociationName_4965',NULL),(1087,NULL,NULL,NULL,'AssociationName_4902',NULL),(1092,NULL,NULL,NULL,'AssociationName_5618',NULL),(1095,NULL,NULL,NULL,'AssociationName_5584',NULL),(1112,NULL,NULL,NULL,'AssociationName_5965',NULL),(1113,NULL,NULL,NULL,'AssociationName_5902',NULL),(1119,NULL,NULL,NULL,'AssociationName_6618',NULL),(1122,NULL,NULL,NULL,'AssociationName_6584',NULL),(1138,NULL,NULL,NULL,'AssociationName_194',NULL),(1139,NULL,NULL,NULL,'AssociationName_19224',NULL),(1140,NULL,NULL,NULL,'AssociationName_19261',NULL),(1141,NULL,NULL,NULL,'AssociationName_19297',NULL),(1142,NULL,NULL,NULL,'AssociationName_19333',NULL),(1143,NULL,NULL,NULL,'AssociationName_2830',NULL),(1144,NULL,NULL,NULL,'AssociationName_204',NULL),(1145,NULL,NULL,NULL,'AssociationName_20224',NULL),(1146,NULL,NULL,NULL,'AssociationName_20261',NULL),(1147,NULL,NULL,NULL,'AssociationName_20297',NULL),(1148,NULL,NULL,NULL,'AssociationName_20333',NULL),(1149,NULL,NULL,NULL,'AssociationName_3685',NULL),(1150,NULL,NULL,NULL,'AssociationName_1379',NULL),(1151,NULL,NULL,NULL,'AssociationName_17379',NULL),(1152,NULL,NULL,NULL,'AssociationName_16379',NULL),(1153,NULL,NULL,NULL,'AssociationName_15379',NULL),(1154,NULL,NULL,NULL,'AssociationName_14379',NULL),(1155,NULL,NULL,NULL,'AssociationName_13379',NULL),(1156,NULL,NULL,NULL,'AssociationName_12379',NULL),(1157,NULL,NULL,NULL,'AssociationName_11379',NULL),(1158,NULL,NULL,NULL,'AssociationName_6379',NULL),(1159,NULL,NULL,NULL,'AssociationName_10379',NULL),(1160,NULL,NULL,NULL,'AssociationName_9379',NULL),(1161,NULL,NULL,NULL,'AssociationName_8379',NULL),(1162,NULL,NULL,NULL,'AssociationName_7379',NULL),(1163,NULL,NULL,NULL,'AssociationName_2379',NULL),(1164,NULL,NULL,NULL,'AssociationName_3379',NULL),(1165,NULL,NULL,NULL,'AssociationName_4379',NULL),(1166,NULL,NULL,NULL,'AssociationName_5379',NULL),(1167,NULL,NULL,NULL,'AssociationName_18379',NULL),(1168,NULL,NULL,NULL,'AssociationName_19379',NULL),(1169,NULL,NULL,NULL,'AssociationName_3674',NULL),(1170,NULL,NULL,NULL,'AssociationName_2685',NULL),(1171,NULL,NULL,NULL,'AssociationName_2640',NULL),(1172,NULL,NULL,NULL,'AssociationName_1653',NULL),(1173,NULL,NULL,NULL,'AssociationName_5674',NULL),(1174,NULL,NULL,NULL,'AssociationName_5685',NULL),(1175,NULL,NULL,NULL,'AssociationName_4640',NULL),(1176,NULL,NULL,NULL,'AssociationName_21379',NULL),(1177,NULL,NULL,NULL,'AssociationName_1926',NULL),(1178,NULL,NULL,NULL,'AssociationName_7685',NULL),(1179,NULL,NULL,NULL,'AssociationName_1698',NULL),(1180,NULL,NULL,NULL,'AssociationName_2698',NULL),(1182,NULL,NULL,NULL,'AssociationName_22379',NULL),(1188,NULL,NULL,NULL,'AssociationName_12740',NULL),(1189,NULL,NULL,NULL,'AssociationName_2981',NULL),(1190,NULL,NULL,NULL,'AssociationName_7886',NULL),(1191,NULL,NULL,NULL,'AssociationName_7868',NULL),(1192,NULL,NULL,NULL,'AssociationName_2729',NULL),(1193,NULL,NULL,NULL,'AssociationName_2770',NULL),(1194,NULL,NULL,NULL,'AssociationName_2781',NULL),(1195,NULL,NULL,NULL,'AssociationName_2794',NULL),(1196,NULL,NULL,NULL,'AssociationName_2812',NULL),(1197,NULL,NULL,NULL,'AssociationName_2857',NULL),(1198,NULL,NULL,NULL,'AssociationName_2868',NULL),(1199,NULL,NULL,NULL,'AssociationName_4868',NULL),(1200,NULL,NULL,NULL,'AssociationName_6868',NULL),(1201,NULL,NULL,NULL,'AssociationName_5868',NULL),(1202,NULL,NULL,NULL,'AssociationName_1944',NULL),(1203,NULL,NULL,NULL,'AssociationName_5830',NULL),(1204,NULL,NULL,NULL,'AssociationName_3868',NULL),(1205,NULL,NULL,NULL,'AssociationName_1911',NULL),(1206,NULL,NULL,NULL,'AssociationName_1975',NULL),(1207,NULL,NULL,NULL,'AssociationName_1915',NULL),(1208,'2007-10-17','DataListEntityGroup','2007-10-17','DataListEntityGroup',NULL),(1209,NULL,NULL,NULL,'availableQuantity',NULL),(1210,NULL,NULL,NULL,'initialQuantity',NULL),(1211,NULL,NULL,NULL,'availableQuantity',NULL),(1213,NULL,NULL,NULL,'availableQuantity',NULL),(1215,NULL,NULL,NULL,'availableQuantity',NULL),(1217,NULL,NULL,NULL,'availableQuantity',NULL),(1219,NULL,NULL,NULL,'offset',NULL),(1220,NULL,NULL,NULL,'offset',NULL),(1221,NULL,NULL,NULL,'type',NULL),(1222,NULL,NULL,NULL,'sequenceNumber',NULL),(1223,NULL,NULL,NULL,'studyCalendarEventPoint',NULL),(1224,NULL,NULL,NULL,'collectionProtocolSelfAssociation',NULL),(1225,NULL,NULL,NULL,'collectionProtocolSelfAssociation',NULL),(1226,'2008-01-21','','2008-01-21','clinical_annotation',NULL),(1227,'2008-01-21','TreatmentRegimen','2008-01-22','TreatmentRegimen',NULL),(1228,NULL,NULL,NULL,'id',NULL),(1229,NULL,'',NULL,'treatmentRegimen',NULL),(1230,'2008-01-21','EnvironmentalExposuresHealthAnnotation','2008-01-24','EnvironmentalExposuresHealthAnnotation',NULL),(1231,NULL,NULL,NULL,'id',NULL),(1232,NULL,NULL,NULL,'Duration',NULL),(1233,NULL,'',NULL,'yearsAgentFree',NULL),(1234,NULL,'',NULL,'otherAgent',NULL),(1235,NULL,'',NULL,'agent',NULL),(1236,'2008-01-21','Duration','2008-01-24','Duration',NULL),(1237,NULL,NULL,NULL,'id',NULL),(1238,NULL,'',NULL,'durationInDays',NULL),(1239,NULL,'',NULL,'endDate',NULL),(1240,NULL,'',NULL,'startDate',NULL),(1241,'2008-01-21','AlcoholHealthAnnotation','2008-01-22','AlcoholHealthAnnotation',NULL),(1242,NULL,NULL,NULL,'id',NULL),(1243,NULL,'',NULL,'drinksPerWeek',NULL),(1244,'2008-01-21','GeneralHealthDiagnosis','2008-01-21','DeprecatedAnnotation1',NULL),(1245,NULL,NULL,NULL,'id',NULL),(1246,NULL,NULL,NULL,'ageAtDiagnosis',NULL),(1247,NULL,NULL,NULL,'otherClinicalDiagnosis',NULL),(1248,NULL,NULL,NULL,'clinicalDiagnosis',NULL),(1249,'2008-01-21','HealthExaminationAnnotation','2008-01-23','HealthExaminationAnnotation',NULL),(1250,NULL,NULL,NULL,'id',NULL),(1251,NULL,'',NULL,'dateOfExamination',NULL),(1252,NULL,'',NULL,'otherProcedure',NULL),(1253,NULL,'',NULL,'nameOfProcedure',NULL),(1254,'2008-01-21','RecurrenceHealthExaminationAnnotation','2008-01-23','RecurrenceHealthExaminationAnnotation',NULL),(1255,NULL,NULL,NULL,'id',NULL),(1256,NULL,'',NULL,'otherClinicalDiagnosis',NULL),(1257,NULL,'',NULL,'clinicalDiagnosis',NULL),(1258,'2008-01-21','TreatmentOrder','2008-01-21','DeprecatedAnnotation2',NULL),(1259,NULL,NULL,NULL,'id',NULL),(1260,NULL,NULL,NULL,'Treatment Order',NULL),(1261,NULL,NULL,NULL,'ChemoRXAnnotation',NULL),(1262,NULL,NULL,NULL,'DeprecatedAnnotation3',NULL),(1263,NULL,NULL,NULL,'cycle',NULL),(1264,'2008-01-21','TreatmentAnnotation','2008-01-23','TreatmentAnnotation',NULL),(1265,NULL,NULL,NULL,'id',NULL),(1266,NULL,NULL,NULL,'Duration',NULL),(1267,NULL,'',NULL,'doseUnits',NULL),(1268,NULL,'',NULL,'dose',NULL),(1269,NULL,'',NULL,'otherAgent',NULL),(1270,NULL,'',NULL,'agent',NULL),(1271,'2008-01-21','RadRXAnnotationSet','2008-01-22','RadRXAnnotation',NULL),(1272,NULL,NULL,NULL,'id',NULL),(1274,'2008-01-21','ChemoRXAnnotation','2008-01-22','ChemoRXAnnotation',NULL),(1275,NULL,NULL,NULL,'id',NULL),(1277,'2008-01-21','LocalRecurrenceHealthExaminationAnnotation','2008-01-22','LocalRecurrenceHealthExaminationAnnotation',NULL),(1278,NULL,NULL,NULL,'id',NULL),(1279,'2008-01-21','DistantRecurrenceHealthExaminationAnnotation','2008-01-23','DistantRecurrenceHealthExaminationAnnotation',NULL),(1280,NULL,NULL,NULL,'id',NULL),(1281,NULL,'',NULL,'otherTissueSite',NULL),(1282,NULL,'',NULL,'tissueSite',NULL),(1283,'2008-01-21','LabAnnotation','2008-01-23','LabAnnotation',NULL),(1284,NULL,NULL,NULL,'id',NULL),(1285,NULL,'',NULL,'testDate',NULL),(1286,NULL,'',NULL,'resultUnits',NULL),(1287,NULL,'',NULL,'result',NULL),(1288,NULL,'',NULL,'otherLabTestName',NULL),(1289,NULL,'',NULL,'labTestName',NULL),(1290,'2008-01-21','FamilyHistoryAnnotation','2008-01-23','FamilyHistoryAnnotation',NULL),(1291,NULL,NULL,NULL,'id',NULL),(1293,NULL,'',NULL,'otherRelation',NULL),(1294,NULL,'',NULL,'relation',NULL),(1295,'2008-01-21','NoEvidentDiseaseHealthAnnotation','2008-01-22','NoEvidentDiseaseHealthAnnotation',NULL),(1296,NULL,NULL,NULL,'id',NULL),(1297,'2008-01-21','SmokingHealthAnnotation','2008-01-22','SmokingHealthAnnotation',NULL),(1298,NULL,NULL,NULL,'id',NULL),(1299,NULL,'',NULL,'packsPerDay',NULL),(1300,'2008-01-21','NewDiagnosisHealthAnnotation','2008-01-22','NewDiagnosisHealthAnnotation',NULL),(1301,NULL,NULL,NULL,'id',NULL),(1302,NULL,NULL,NULL,'844_1',NULL),(1303,NULL,NULL,NULL,'844_2',NULL),(1304,NULL,NULL,NULL,'844_3',NULL),(1305,NULL,NULL,NULL,'844_5',NULL),(1306,NULL,NULL,NULL,'844_6',NULL),(1307,NULL,NULL,NULL,'844_7',NULL),(1308,NULL,NULL,NULL,'844_8',NULL),(1309,NULL,NULL,NULL,'844_9',NULL),(1310,NULL,NULL,NULL,'844_10',NULL),(1311,NULL,NULL,NULL,'844_13',NULL),(1312,NULL,NULL,NULL,'844_12',NULL),(1313,NULL,NULL,NULL,'844_11',NULL),(1314,NULL,NULL,NULL,'844_14',NULL),(1315,NULL,NULL,NULL,'844_15',NULL),(1316,NULL,NULL,NULL,'844_16',NULL),(1317,'2008-01-21','pathology_specimen','2008-01-21','pathology_specimen',NULL),(1318,'2008-01-21','AdditionalPathologicFinding','2008-01-21','AdditionalPathologicFinding',NULL),(1319,NULL,NULL,NULL,'id',NULL),(1320,NULL,NULL,NULL,'otherGradingSystemName',NULL),(1321,NULL,NULL,NULL,'comments',NULL),(1322,'2008-01-21','SpecimenDetails','2008-01-21','SpecimenDetails1',NULL),(1323,NULL,NULL,NULL,'id',NULL),(1324,NULL,NULL,NULL,'detail',NULL),(1325,'2008-01-21','SpecimenBaseSolidTissuePathologyAnnotation','2008-01-30','SpecimenBaseSolidTissuePathologyAnnotation',NULL),(1326,NULL,NULL,NULL,'id',NULL),(1328,NULL,NULL,NULL,'SpecimenHistologicGrade',NULL),(1329,NULL,NULL,NULL,'SpecimenInvasion',NULL),(1330,NULL,NULL,NULL,'SpecimenHistologicType',NULL),(1331,NULL,'',NULL,'comments',NULL),(1332,'2008-01-21','SpecimenHistologicType','2008-01-30','SpecimenHistologicType',NULL),(1333,NULL,NULL,NULL,'id',NULL),(1334,NULL,NULL,NULL,'SpecimenHistologicVariantType',NULL),(1335,NULL,'',NULL,'type',NULL),(1336,'2008-01-21','SpecimenHistologicVariantType','2008-01-30','SpecimenHistologicVariantType',NULL),(1337,NULL,NULL,NULL,'id',NULL),(1338,NULL,'',NULL,'otherHistologicType',NULL),(1339,'2008-01-21','SpecimenInvasion','2008-01-30','SpecimenInvasion',NULL),(1340,NULL,NULL,NULL,'id',NULL),(1341,NULL,'',NULL,'perineuralInvasion',NULL),(1342,NULL,'',NULL,'venousInvasion',NULL),(1343,NULL,'',NULL,'lymphaticInvasion',NULL),(1344,'2008-01-21','SpecimenHistologicGrade','2008-01-30','SpecimenHistologicGrade',NULL),(1345,NULL,NULL,NULL,'id',NULL),(1346,NULL,'',NULL,'grade',NULL),(1347,NULL,'',NULL,'otherGradingSystemName',NULL),(1348,NULL,'',NULL,'gradingSystemName',NULL),(1349,'2008-01-21','MelanomaSpecimenPathologyAnnotation','2008-01-30','MelanomaSpecimenPathologyAnnotation',NULL),(1350,NULL,NULL,NULL,'id',NULL),(1351,NULL,'',NULL,'mitoticIndex',NULL),(1352,NULL,'',NULL,'tumorRegression',NULL),(1353,NULL,'',NULL,'tumorInfiltratingLymphocytes',NULL),(1354,NULL,'',NULL,'depthOfInvasionCannotBeDetermined',NULL),(1355,NULL,'',NULL,'depthOfInvasion',NULL),(1356,NULL,'',NULL,'ulceration',NULL),(1357,'2008-01-21','KidneySpecimenPathologyAnnotation','2008-01-22','KidneySpecimenPathologyAnnotation',NULL),(1358,NULL,NULL,NULL,'id',NULL),(1359,'2008-01-21','ColorectalSpecimenPathologyAnnotation','2008-01-22','ColorectalSpecimenPathologyAnnotation',NULL),(1360,NULL,NULL,NULL,'id',NULL),(1361,NULL,'',NULL,'intratumoralPeritumoralLymphocyticResponse',NULL),(1362,NULL,'',NULL,'tumorBorderConfiguration',NULL),(1363,'2008-01-21','CNSSpecimenPathologyAnnotation','2008-01-22','CNSSpecimenPathologyAnnotation',NULL),(1364,NULL,NULL,NULL,'id',NULL),(1365,'2008-01-21','BreastSpecimenPathologyAnnotation','2008-01-22','BreastSpecimenPathologyAnnotation',NULL),(1366,NULL,NULL,NULL,'id',NULL),(1368,NULL,'',NULL,'mitoticCountIfOtherGradingSystemUsed',NULL),(1369,'2008-01-21','SpecimenNottinghamHistologicScore','2008-01-21','SpecimenNottinghamHistologicScore',NULL),(1370,NULL,NULL,NULL,'id',NULL),(1371,NULL,NULL,NULL,'totalNottinghamScore',NULL),(1372,NULL,NULL,NULL,'mitoticCountScore',NULL),(1373,NULL,NULL,NULL,'nuclearPleomorphismScore',NULL),(1374,NULL,NULL,NULL,'tubuleFormationScore',NULL),(1375,'2008-01-21','PancreasSpecimenPathologyAnnotation','2008-01-22','PancreasSpecimenPathologyAnnotation',NULL),(1376,NULL,NULL,NULL,'id',NULL),(1377,'2008-01-21','ProstateSpecimenPathologyAnnotation','2008-01-22','ProstateSpecimenPathologyAnnotation',NULL),(1378,NULL,NULL,NULL,'id',NULL),(1380,NULL,'',NULL,'proportionOrPercentOfProstaticTissueInvolvedByTumor',NULL),(1381,'2008-01-21','SpecimenGleasonScore','2008-01-21','SpecimenGleasonScore',NULL),(1382,NULL,NULL,NULL,'id',NULL),(1383,NULL,NULL,NULL,'tertiaryPatternScore',NULL),(1384,NULL,NULL,NULL,'secondaryPatternScore',NULL),(1385,NULL,NULL,NULL,'primaryPatternScore',NULL),(1386,'2008-01-21','LungSpecimenPathologyAnnotation','2008-01-22','LungSpecimenPathologyAnnotation',NULL),(1387,NULL,NULL,NULL,'id',NULL),(1388,NULL,NULL,NULL,'Nottingham Histologic Score1365',NULL),(1389,NULL,NULL,NULL,'Gleason Score1377',NULL),(1390,NULL,NULL,NULL,'4_21',NULL),(1391,NULL,NULL,NULL,'4_22',NULL),(1392,NULL,NULL,NULL,'4_23',NULL),(1393,NULL,NULL,NULL,'4_24',NULL),(1394,NULL,NULL,NULL,'4_25',NULL),(1395,NULL,NULL,NULL,'4_26',NULL),(1396,NULL,NULL,NULL,'4_27',NULL),(1397,NULL,NULL,NULL,'4_28',NULL),(1398,NULL,NULL,NULL,'4_29',NULL),(1399,NULL,NULL,NULL,'Additional Finding',NULL),(1400,'2008-01-21','','2008-01-30','SpecimenAdditionalFinding',NULL),(1401,NULL,NULL,NULL,'id',NULL),(1402,NULL,NULL,NULL,'Details',NULL),(1403,NULL,'',NULL,'pathologicFinding',NULL),(1404,'2008-01-21','','2008-01-30','SpecimenDetails',NULL),(1405,NULL,NULL,NULL,'id',NULL),(1406,NULL,'',NULL,'details',NULL),(1407,NULL,NULL,NULL,'GleasonScore',NULL),(1408,'2008-01-21','','2008-01-22','ProstateSpecimenGleasonScore',NULL),(1409,NULL,NULL,NULL,'id',NULL),(1410,NULL,'',NULL,'tertiaryPatternScore',NULL),(1411,NULL,'',NULL,'secondaryPatternScore',NULL),(1412,NULL,'',NULL,'primaryPatternScore',NULL),(1413,NULL,NULL,NULL,'NottinghamHistologicScore',NULL),(1414,'2008-01-21','','2008-01-22','BreastSpecimenNottinghamHistologicScore',NULL),(1415,NULL,NULL,NULL,'id',NULL),(1416,NULL,'',NULL,'totalNottinghamScore',NULL),(1417,NULL,'',NULL,'mitoticCountScore',NULL),(1418,NULL,'',NULL,'nuclearPleomorphismScore',NULL),(1419,NULL,'',NULL,'tubuleFormationScore',NULL),(1420,NULL,NULL,NULL,'GeneralHealthDiagnosis',NULL),(1421,'2008-01-21','','2008-01-23','GeneralHealthDiagnosis',NULL),(1422,NULL,NULL,NULL,'id',NULL),(1423,NULL,'',NULL,'ageAtDiagnosis',NULL),(1424,NULL,'',NULL,'otherClinicalDiagnosis',NULL),(1425,NULL,'',NULL,'clinicalDiagnosis',NULL),(1426,NULL,NULL,NULL,'TreatmentOrder',NULL),(1427,'2008-01-21','','2008-01-22','TreatmentOrder',NULL),(1428,NULL,NULL,NULL,'id',NULL),(1429,NULL,NULL,NULL,'RadRXAnnotationSet',NULL),(1430,NULL,NULL,NULL,'ChemoRXAnnotation',NULL),(1431,NULL,'',NULL,'cycle',NULL),(1432,'2008-01-21','','2008-01-22','Chemotherapy',NULL),(1433,NULL,NULL,NULL,'id',NULL),(1434,'2008-01-21','','2008-01-22','RadRXAnnotationSet',NULL),(1435,NULL,NULL,NULL,'id',NULL),(1436,'2008-01-22','','2008-01-22','pathology_scg',NULL),(1437,'2008-01-22','CarcinomaInSituStatus','2008-01-22','CarcinomaInSituStatus',NULL),(1438,NULL,NULL,NULL,'id',NULL),(1439,NULL,'',NULL,'status',NULL),(1440,'2008-01-22','BasePathologyAnnotation','2008-01-30','BasePathologyAnnotation',NULL),(1441,NULL,NULL,NULL,'id',NULL),(1442,NULL,NULL,NULL,'Additional Finding',NULL),(1443,NULL,NULL,NULL,'HistologicType',NULL),(1444,NULL,'',NULL,'comment',NULL),(1445,NULL,'',NULL,'otherSpecimenProcedure',NULL),(1446,NULL,'',NULL,'specimenProcedure',NULL),(1447,'2008-01-22','HistologicType','2008-01-30','HistologicType',NULL),(1448,NULL,NULL,NULL,'id',NULL),(1449,NULL,NULL,NULL,'HistologicVariantType',NULL),(1450,NULL,'',NULL,'type',NULL),(1451,'2008-01-22','HistologicVariantType','2008-01-30','HistologicVariantType',NULL),(1452,NULL,NULL,NULL,'id',NULL),(1453,NULL,'',NULL,'otherHistologicType',NULL),(1454,'2008-01-22','AdditionalFinding','2008-01-30','AdditionalFinding',NULL),(1455,NULL,NULL,NULL,'id',NULL),(1456,NULL,NULL,NULL,'Details',NULL),(1457,NULL,'',NULL,'pathologicFinding',NULL),(1458,'2008-01-22','Details','2008-01-30','Details',NULL),(1459,NULL,NULL,NULL,'id',NULL),(1460,NULL,'',NULL,'detail',NULL),(1461,'2008-01-22','BaseSolidTissuePathologyAnnotation','2008-01-30','BaseSolidTissuePathologyAnnotation',NULL),(1462,NULL,NULL,NULL,'id',NULL),(1463,NULL,NULL,NULL,'Tumor Tissue Site',NULL),(1464,NULL,NULL,NULL,'PathologicalStaging',NULL),(1465,NULL,NULL,NULL,'HistologicGrade',NULL),(1466,NULL,NULL,NULL,'Size',NULL),(1467,NULL,NULL,NULL,'Invasion',NULL),(1468,'2008-01-22','Invasion','2008-01-30','Invasion',NULL),(1469,NULL,NULL,NULL,'id',NULL),(1470,NULL,'',NULL,'perineuralInvasion',NULL),(1471,NULL,'',NULL,'venousInvasion',NULL),(1472,NULL,'',NULL,'lymphaticInvasion',NULL),(1473,'2008-01-22','Size','2008-01-30','TumorSize',NULL),(1474,NULL,NULL,NULL,'id',NULL),(1475,NULL,'',NULL,'greatestDimension',NULL),(1476,NULL,'',NULL,'additionalDimensionTwo',NULL),(1477,NULL,'',NULL,'additionalDimensionOne',NULL),(1478,NULL,'',NULL,'cannotBeDetermined',NULL),(1479,'2008-01-22','HistologicGrade','2008-01-30','HistologicGrade',NULL),(1480,NULL,NULL,NULL,'id',NULL),(1481,NULL,'',NULL,'grade',NULL),(1482,NULL,'',NULL,'otherGradingSystemName',NULL),(1483,NULL,'',NULL,'gradingSystemName',NULL),(1484,'2008-01-22','PathologicalStaging','2008-01-30','PathologicalStaging',NULL),(1485,NULL,NULL,NULL,'id',NULL),(1486,NULL,NULL,NULL,'PrimaryTumorStage',NULL),(1487,NULL,NULL,NULL,'DistantMetastasis',NULL),(1488,NULL,NULL,NULL,'Regional Lymph Node',NULL),(1489,'2008-01-22','RegionalLymphNode','2008-01-30','RegionalLymphNode',NULL),(1490,NULL,NULL,NULL,'id',NULL),(1491,NULL,'',NULL,'mattedNodes',NULL),(1492,NULL,'',NULL,'numberPositiveMicroscopically',NULL),(1493,NULL,'',NULL,'numberPositiveMacroscopically',NULL),(1494,NULL,'',NULL,'numberInvolved',NULL),(1495,NULL,'',NULL,'numberExamined',NULL),(1496,NULL,'',NULL,'lymphNodeStage',NULL),(1497,'2008-01-22','DistantMetastasis','2008-01-30','DistantMetastasis',NULL),(1498,NULL,NULL,NULL,'id',NULL),(1499,NULL,NULL,NULL,'MetastasisTissueSite',NULL),(1500,NULL,'',NULL,'metastasisStage',NULL),(1501,'2008-01-22','MetastasisTissueSite','2008-01-30','MetastasisTissueSite',NULL),(1502,NULL,NULL,NULL,'id',NULL),(1503,NULL,'',NULL,'otherTissueSite',NULL),(1504,NULL,'',NULL,'tissueSite',NULL),(1505,'2008-01-22','PrimaryTumorStage','2008-01-30','PrimaryTumorStage',NULL),(1506,NULL,NULL,NULL,'id',NULL),(1507,NULL,'',NULL,'primaryTumorStage',NULL),(1508,'2008-01-22','TumorTissueSite','2008-01-30','TumorTissueSite',NULL),(1509,NULL,NULL,NULL,'id',NULL),(1510,NULL,NULL,NULL,'TissueSide',NULL),(1511,NULL,'',NULL,'otherSite',NULL),(1512,NULL,'',NULL,'site',NULL),(1513,'2008-01-22','TissueSide','2008-01-30','TissueSide',NULL),(1514,NULL,NULL,NULL,'id',NULL),(1515,NULL,'',NULL,'side',NULL),(1516,'2008-01-22','LungPathologyAnnotation','2008-01-23','LungPathologyAnnotation',NULL),(1517,NULL,NULL,NULL,'id',NULL),(1518,'2008-01-22','LungResectionBasedPathologyAnnotation','2008-01-23','LungResectionBasedPathologyAnnotation',NULL),(1519,NULL,NULL,NULL,'id',NULL),(1520,NULL,NULL,NULL,'LungResectionMargin',NULL),(1521,NULL,NULL,NULL,'DirectExtensionOfTumor',NULL),(1522,NULL,'',NULL,'arterialInvasion',NULL),(1523,NULL,'',NULL,'otherTumorExtensions',NULL),(1524,'2008-01-22','DirectExtensionOfTumor','2008-01-23','DirectExtensionOfTumor',NULL),(1525,NULL,NULL,NULL,'id',NULL),(1526,NULL,'',NULL,'extensionOfTumor',NULL),(1527,'2008-01-22','LungResectionMargin','2008-01-23','LungResectionMargin',NULL),(1528,NULL,NULL,NULL,'id',NULL),(1529,NULL,NULL,NULL,'LungResectionMarginsUninvolved',NULL),(1530,NULL,'',NULL,'otherLocation',NULL),(1531,NULL,'',NULL,'marginLocation',NULL),(1532,NULL,'',NULL,'marginStatus',NULL),(1533,'2008-01-22','LungResectionMarginsUninvolved','2008-01-23','LungResectionMarginsUninvolved',NULL),(1534,NULL,NULL,NULL,'id',NULL),(1535,NULL,'',NULL,'closestDistanceToTumor',NULL),(1536,'2008-01-22','KidneyPathologyAnnotation','2008-01-22','KidneyPathologyAnnotation',NULL),(1537,NULL,NULL,NULL,'id',NULL),(1538,NULL,'',NULL,'percentOfSarcomatoidElement',NULL),(1539,'2008-01-22','KidneyBiopsyBasedPathologyAnnotation','2008-01-22','KidneyBiopsyBasedPathologyAnnotation',NULL),(1540,NULL,NULL,NULL,'id',NULL),(1541,'2008-01-22','SpecimenIntegrity','2008-01-30','SpecimenIntegrity',NULL),(1542,NULL,NULL,NULL,'id',NULL),(1543,NULL,'',NULL,'numberOfPieces',NULL),(1544,NULL,'',NULL,'type',NULL),(1545,'2008-01-22','ProstatePathologyAnnotation','2008-01-30','ProstatePathologyAnnotation',NULL),(1546,NULL,NULL,NULL,'id',NULL),(1547,NULL,NULL,NULL,'GleasonScore',NULL),(1548,NULL,'',NULL,'periprostaticFatInvasion',NULL),(1549,NULL,'',NULL,'seminalVesicleInvasion',NULL),(1550,NULL,'',NULL,'proportionOrPercentOfProstaticTissueInvolvedByTumor',NULL),(1551,'2008-01-22','GleasonScore','2008-01-30','GleasonScore',NULL),(1552,NULL,NULL,NULL,'id',NULL),(1553,NULL,'',NULL,'tertiaryPatternScore',NULL),(1554,NULL,'',NULL,'secondaryPatternScore',NULL),(1555,NULL,'',NULL,'primaryPatternScore',NULL),(1556,'2008-01-22','UninvolvedMelanomaMargin','2008-01-22','UninvolvedMelanomaMargin',NULL),(1557,NULL,NULL,NULL,'id',NULL),(1558,NULL,NULL,NULL,'closestDistanceToTumor',NULL),(1559,'2008-01-22','LungBiopsyPathologyAnnotation','2008-01-22','LungBiopsyPathologyAnnotation',NULL),(1560,NULL,NULL,NULL,'id',NULL),(1561,NULL,'',NULL,'visceralPleuraInvasion',NULL),(1562,'2008-01-22','PancreasMarginInvolvedByInvasiveCarcinoma','2008-01-22','PancreasMarginInvolvedByInvasiveCarcinoma',NULL),(1563,NULL,NULL,NULL,'id',NULL),(1564,NULL,'',NULL,'otherMarginLocation',NULL),(1565,NULL,'',NULL,'marginLocation',NULL),(1566,'2008-01-22','KidneyNephrectomyMargin','2008-01-22','KidneyNephrectomyMargin',NULL),(1567,NULL,NULL,NULL,'id',NULL),(1568,NULL,NULL,NULL,'KidneyMarginLocation',NULL),(1569,NULL,'',NULL,'marginStatus',NULL),(1570,'2008-01-22','KidneyMarginLocation','2008-01-22','KidneyMarginLocation',NULL),(1571,NULL,NULL,NULL,'id',NULL),(1572,NULL,'',NULL,'otherLocation',NULL),(1573,NULL,'',NULL,'location',NULL),(1574,'2008-01-22','MacroscopicExtentOfTumor','2008-01-22','MacroscopicExtentOfTumor',NULL),(1575,NULL,NULL,NULL,'id',NULL),(1576,NULL,'',NULL,'extentOfTumor',NULL),(1577,'2008-01-22','BaseHaematologyPathologyAnnotation','2008-01-28','BaseHaematologyPathologyAnnotation',NULL),(1578,NULL,NULL,NULL,'id',NULL),(1579,NULL,NULL,NULL,'Cytogenetics',NULL),(1580,NULL,NULL,NULL,'ImmunoPhenotyping',NULL),(1581,NULL,'',NULL,'adequacyOfSpecimen',NULL),(1582,NULL,'',NULL,'otherBiopsyOrAspirateSite',NULL),(1583,NULL,'',NULL,'biopsyOrAspirateSite',NULL),(1584,'2008-01-22','ImmunoPhenotyping','2008-01-28','ImmunoPhenotyping',NULL),(1585,NULL,NULL,NULL,'id',NULL),(1586,NULL,'',NULL,'status',NULL),(1587,NULL,'',NULL,'result',NULL),(1588,NULL,'',NULL,'methodUsed',NULL),(1589,'2008-01-22','Cytogenetics','2008-01-28','Cytogenetics',NULL),(1590,NULL,NULL,NULL,'id',NULL),(1591,NULL,'',NULL,'result',NULL),(1592,NULL,'',NULL,'status',NULL),(1593,'2008-01-22','ColorectalPathologyAnnotation','2008-01-30','ColorectalPathologyAnnotation',NULL),(1594,NULL,NULL,NULL,'id',NULL),(1596,NULL,'',NULL,'intratumoralPeritumoralLymphocyticResponse',NULL),(1597,NULL,'',NULL,'tumorBorderConfiguration',NULL),(1598,NULL,'',NULL,'otherTumorConfiguration',NULL),(1599,NULL,'',NULL,'tumorConfiguration',NULL),(1600,'2008-01-22','DeepMelanomaMargin','2008-01-22','DeepMelanomaMargin',NULL),(1601,NULL,NULL,NULL,'id',NULL),(1602,NULL,NULL,NULL,'UninvolvedMelanomaMargin',NULL),(1603,NULL,'',NULL,'marginLocation',NULL),(1604,NULL,'',NULL,'marginStatus',NULL),(1605,'2008-01-22','SatelliteNodule','2008-01-22','SatelliteNodule',NULL),(1606,NULL,NULL,NULL,'id',NULL),(1607,NULL,'',NULL,'site',NULL),(1608,'2008-01-22','ExcisionalBiopsyColorectalDeepMargin','2008-01-22','ExcisionalBiopsyColorectalDeepMargin',NULL),(1609,NULL,NULL,NULL,'id',NULL),(1610,NULL,NULL,NULL,'ExcionalBiopsyMarginUninvolved',NULL),(1611,NULL,'',NULL,'marginStatus',NULL),(1612,'2008-01-22','ExcionalBiopsyMarginUninvolved','2008-01-22','ExcionalBiopsyMarginUninvolved',NULL),(1613,NULL,NULL,NULL,'id',NULL),(1614,NULL,NULL,NULL,'closestDistanceToTumor',NULL),(1615,'2008-01-22','PancreasMargin','2008-01-22','PancreasMargin',NULL),(1616,NULL,NULL,NULL,'id',NULL),(1617,NULL,NULL,NULL,'PancreasMarginInvolvedByInvasiveCarcinoma',NULL),(1618,NULL,NULL,NULL,'PancreasMarginUninvolvedByInvasiveCarcinoma',NULL),(1619,NULL,'',NULL,'marginStatus',NULL),(1620,'2008-01-22','PancreasMarginUninvolvedByInvasiveCarcinoma','2008-01-22','PancreasMarginUninvolvedByInvasiveCarcinoma',NULL),(1621,NULL,NULL,NULL,'id',NULL),(1622,NULL,NULL,NULL,'CarcinomaInSituStatus',NULL),(1623,NULL,'',NULL,'marginLocation',NULL),(1624,NULL,'',NULL,'closestDistanceToTumor',NULL),(1625,'2008-01-22','TransurethralProstaticResectionPathologyAnnotation','2008-01-22','TransurethralProstaticResectionPathologyAnnotation',NULL),(1626,NULL,NULL,NULL,'id',NULL),(1627,NULL,'',NULL,'totalNumberOfChips',NULL),(1628,NULL,'',NULL,'numberOfPositiveChips',NULL),(1629,NULL,'',NULL,'isTumorIncidentalHistologicFindingAbove5Percent',NULL),(1630,NULL,'',NULL,'specimenWeight',NULL),(1631,'2008-01-22','ExcisionalBiopsyBasedColorectalPathologyAnnotation','2008-01-22','ExcisionalBiopsyBasedColorectalPathologyAnnotation',NULL),(1632,NULL,NULL,NULL,'id',NULL),(1633,NULL,NULL,NULL,'ExcisionalBiopsyColorectalDeepMargin',NULL),(1634,NULL,NULL,NULL,'ExcisionalBiopsyColorectalLateralOrMucosalMargin',NULL),(1636,NULL,NULL,NULL,'PolypConfiguration',NULL),(1638,NULL,'',NULL,'typeOfPolypInWhichInvasiveCarcinomaArose',NULL),(1639,NULL,'',NULL,'extentOfInvasion',NULL),(1640,'2008-01-22','DistanceFromAnalVerge','2008-01-30','DistanceFromAnalVerge',NULL),(1641,NULL,NULL,NULL,'id',NULL),(1642,NULL,'',NULL,'lengthInCentimeters',NULL),(1643,NULL,'',NULL,'distanceKnown',NULL),(1644,'2008-01-22','PolypConfiguration','2008-01-22','PolypConfiguration',NULL),(1645,NULL,NULL,NULL,'id',NULL),(1646,NULL,'',NULL,'stalkLength',NULL),(1647,NULL,'',NULL,'configuration',NULL),(1648,'2008-01-22','ExcisionalBiopsyColorectalLateralOrMucosalMargin','2008-01-22','ExcisionalBiopsyColorectalLateralOrMucosalMargin',NULL),(1649,NULL,NULL,NULL,'id',NULL),(1650,NULL,NULL,NULL,'ExcionalBiopsyMarginUninvolved',NULL),(1651,NULL,'',NULL,'marginStatus',NULL),(1652,'2008-01-22','NeedleBiopsyProstatePathologyAnnotation','2008-01-22','NeedleBiopsyProstatePathologyAnnotation',NULL),(1653,NULL,NULL,NULL,'id',NULL),(1654,NULL,'',NULL,'totalNumberOfCores',NULL),(1655,NULL,'',NULL,'numberOfPositiveCores',NULL),(1656,NULL,'',NULL,'otherQuantitiation',NULL),(1657,NULL,'',NULL,'coreLengthInMillimeter',NULL),(1658,NULL,'',NULL,'totalLinearCarcinomaInMillimeter',NULL),(1659,'2008-01-22','BreastMarginInvolved','2008-01-22','BreastMarginInvolved',NULL),(1660,NULL,NULL,NULL,'id',NULL),(1661,NULL,'',NULL,'otherExtentOfInvolvement',NULL),(1662,NULL,'',NULL,'extentOfInvolvement',NULL),(1663,'2008-01-22','ProstateMarginLocation','2008-01-30','ProstateMarginLocation',NULL),(1664,NULL,NULL,NULL,'id',NULL),(1665,NULL,'',NULL,'involvedMarginLocation',NULL),(1666,NULL,'',NULL,'otherLocation',NULL),(1667,'2008-01-22','BreastMargin','2008-01-22','BreastMargin',NULL),(1668,NULL,NULL,NULL,'id',NULL),(1669,NULL,NULL,NULL,'BreastMarginUninvolved',NULL),(1670,NULL,NULL,NULL,'BreastMarginInvolved',NULL),(1671,NULL,'',NULL,'marginLocation',NULL),(1672,NULL,'',NULL,'marginStatus',NULL),(1673,'2008-01-22','BreastMarginUninvolved','2008-01-22','BreastMarginUninvolved',NULL),(1674,NULL,NULL,NULL,'id',NULL),(1675,NULL,NULL,NULL,'closestDistanceToTumor',NULL),(1676,'2008-01-22','RadicalProstatectomyPathologyAnnotation','2008-01-30','RadicalProstatectomyPathologyAnnotation',NULL),(1677,NULL,NULL,NULL,'id',NULL),(1678,NULL,NULL,NULL,'ExtraprostaticExtension',NULL),(1679,NULL,NULL,NULL,'RadicalProstatectomyMargin',NULL),(1680,'2008-01-22','RadicalProstatectomyMargin','2008-01-30','RadicalProstatectomyMargin',NULL),(1681,NULL,NULL,NULL,'id',NULL),(1682,NULL,NULL,NULL,'ProstateMarginLocation',NULL),(1683,NULL,'',NULL,'focalityOfInvolvedMargin',NULL),(1684,NULL,'',NULL,'marginStatus',NULL),(1685,'2008-01-22','ExtraprostaticExtension','2008-01-30','ExtraprostaticExtension',NULL),(1686,NULL,NULL,NULL,'id',NULL),(1687,NULL,NULL,NULL,'ExtraprostaticExtensionTissueSites',NULL),(1688,NULL,'',NULL,'isFocal',NULL),(1689,NULL,'',NULL,'status',NULL),(1690,'2008-01-22','ExtraprostaticExtensionTissueSites','2008-01-30','ExtraprostaticExtensionTissueSites',NULL),(1691,NULL,NULL,NULL,'id',NULL),(1692,NULL,'',NULL,'tissueSite',NULL),(1693,'2008-01-22','ResectionColorectalMesentricMargin','2008-01-22','ResectionColorectalMesentricMargin',NULL),(1694,NULL,NULL,NULL,'id',NULL),(1695,NULL,NULL,NULL,'ColorectalResectedMarginUninvolved',NULL),(1696,NULL,'',NULL,'marginStatus',NULL),(1697,'2008-01-22','ColorectalResectedMarginUninvolved','2008-01-22','ColorectalResectedMarginUninvolved',NULL),(1698,NULL,NULL,NULL,'id',NULL),(1699,NULL,NULL,NULL,'marginLocation',NULL),(1700,NULL,NULL,NULL,'closestDistanceToTumor',NULL),(1701,'2008-01-22','OtherResectedOrgans','2008-01-22','OtherResectedOrgans',NULL),(1702,NULL,NULL,NULL,'id',NULL),(1703,NULL,'',NULL,'otherOtherOrgansResected',NULL),(1704,NULL,'',NULL,'otherOrgansResected',NULL),(1705,'2008-01-22','PancreasPathologyAnnotation','2008-01-22','PancreasPathologyAnnotation',NULL),(1706,NULL,NULL,NULL,'id',NULL),(1707,NULL,NULL,NULL,'Pancrease Margin',NULL),(1708,NULL,NULL,NULL,'Other Resected Organs',NULL),(1709,'2008-01-22','NottinghamHistologicScore','2008-01-22','NottinghamHistologicScore',NULL),(1710,NULL,NULL,NULL,'id',NULL),(1711,NULL,'',NULL,'totalNottinghamScore',NULL),(1712,NULL,'',NULL,'mitoticCountScore',NULL),(1713,NULL,'',NULL,'nuclearPleomorphismScore',NULL),(1714,NULL,'',NULL,'tubuleFormationScore',NULL),(1715,'2008-01-22','ResectionBasedColorectalPathologyAnnotation','2008-01-22','ResectionBasedColorectalPathologyAnnotation',NULL),(1716,NULL,NULL,NULL,'id',NULL),(1717,NULL,NULL,NULL,'ResectionColorectalRadialMargin',NULL),(1718,NULL,NULL,NULL,'ResectionColorectalMesentricMargin',NULL),(1719,NULL,NULL,NULL,'ResectionColorectalDistalMargin',NULL),(1720,NULL,NULL,NULL,'ResectionColorectalProximalMargin',NULL),(1721,NULL,'',NULL,'intactnessOfMesorectum',NULL),(1722,NULL,NULL,NULL,'specimenLength',NULL),(1723,'2008-01-22','ResectionColorectalProximalMargin','2008-01-22','ResectionColorectalProximalMargin',NULL),(1724,NULL,NULL,NULL,'id',NULL),(1725,NULL,NULL,NULL,'ColorectalResectedMarginUninvolved',NULL),(1726,NULL,'',NULL,'marginStatus',NULL),(1727,'2008-01-22','ResectionColorectalDistalMargin','2008-01-22','ResectionColorectalDistalMargin',NULL),(1728,NULL,NULL,NULL,'id',NULL),(1729,NULL,NULL,NULL,'ColorectalResectedMarginUninvolved',NULL),(1730,NULL,'',NULL,'marginStatus',NULL),(1731,'2008-01-22','ResectionColorectalRadialMargin','2008-01-22','ResectionColorectalRadialMargin',NULL),(1732,NULL,NULL,NULL,'id',NULL),(1733,NULL,NULL,NULL,'ColorectalResectedMarginUninvolved',NULL),(1734,NULL,'',NULL,'marginStatus',NULL),(1735,'2008-01-22','MelanomaPathologyAnnotation','2008-01-22','MelanomaPathologyAnnotation',NULL),(1736,NULL,'',NULL,'macroscopicTumor',NULL),(1737,NULL,'',NULL,'pigmentation',NULL),(1738,NULL,'',NULL,'ulceration',NULL),(1739,NULL,'',NULL,'depthOfInvasion',NULL),(1740,NULL,'',NULL,'depthOfInvasionCannotBeDetermined',NULL),(1741,NULL,'',NULL,'tumorInfiltratingLymphocytes',NULL),(1742,NULL,'',NULL,'tumorRegression',NULL),(1743,NULL,'',NULL,'mitoticIndex',NULL),(1744,NULL,'',NULL,'satelliteNoduleStatus',NULL),(1745,NULL,NULL,NULL,'LateralMelanomaMargin',NULL),(1746,NULL,NULL,NULL,'satelliteNodule',NULL),(1747,NULL,NULL,NULL,'DeepMelanomaMargin',NULL),(1748,NULL,NULL,NULL,'id',NULL),(1749,'2008-01-22','LateralMelanomaMargin','2008-01-22','LateralMelanomaMargin',NULL),(1750,NULL,NULL,NULL,'id',NULL),(1751,NULL,NULL,NULL,'UninvolvedMelanomaMargin',NULL),(1752,NULL,'',NULL,'marginLocation',NULL),(1753,NULL,'',NULL,'marginStatus',NULL),(1754,'2008-01-22','BreastPathologyAnnotation','2008-01-22','BreastPathologyAnnotation',NULL),(1755,NULL,NULL,NULL,'id',NULL),(1756,NULL,NULL,NULL,'Microcalcification',NULL),(1758,NULL,NULL,NULL,'Breast Margin',NULL),(1759,NULL,NULL,NULL,'NottinghamHistologicScore',NULL),(1760,NULL,NULL,NULL,'mitoticCountIfOtherGradingSystemUsed',NULL),(1761,NULL,'',NULL,'lymphNodeSampling',NULL),(1762,'2008-01-22','Microcalcification','2008-01-22','Microcalcification',NULL),(1763,NULL,NULL,NULL,'id',NULL),(1764,NULL,'',NULL,'value',NULL),(1765,'2008-01-22','LocalExcisionColorectalLateralMargin','2008-01-30','LocalExcisionColorectalLateralMargin',NULL),(1766,NULL,NULL,NULL,'id',NULL),(1767,NULL,NULL,NULL,'ColorectalLocalExcisionMarginUninvolved',NULL),(1768,NULL,'',NULL,'marginLocation',NULL),(1769,NULL,'',NULL,'marginStatus',NULL),(1770,'2008-01-22','ColorectalLocalExcisionMarginUninvolved','2008-01-30','ColorectalLocalExcisionMarginUninvolved',NULL),(1771,NULL,NULL,NULL,'id',NULL),(1772,NULL,NULL,NULL,'closestDistanceToTumor',NULL),(1773,'2008-01-22','CNSPathologyAnnotation','2008-01-22','CNSPathologyAnnotation',NULL),(1774,NULL,NULL,NULL,'id',NULL),(1776,NULL,NULL,NULL,'CNS Margin',NULL),(1777,'2008-01-22','CNSMargin','2008-01-22','CNSMargin',NULL),(1778,NULL,NULL,NULL,'id',NULL),(1779,NULL,NULL,NULL,'CNSMarginLocation',NULL),(1780,NULL,'',NULL,'marginStatus',NULL),(1781,'2008-01-22','CNSMarginLocation','2008-01-22','CNSMarginLocation',NULL),(1782,NULL,NULL,NULL,'id',NULL),(1783,NULL,'',NULL,'marginLocation',NULL),(1784,'2008-01-22','LocalExcisionColorectalDeepMargin','2008-01-30','LocalExcisionColorectalDeepMargin',NULL),(1785,NULL,NULL,NULL,'id',NULL),(1786,NULL,NULL,NULL,'ColorectalLocalExcisionMarginUninvolved',NULL),(1787,NULL,'',NULL,'marginStatus',NULL),(1788,'2008-01-22','LocalExcisionBasedColorectalPathologyAnnotation','2008-01-30','LocalExcisionBasedColorectalPathologyAnnotation',NULL),(1789,NULL,NULL,NULL,'id',NULL),(1790,NULL,NULL,NULL,'SpecimenIntegrity',NULL),(1791,NULL,NULL,NULL,'LocalExcisionColorectalDeepMargin',NULL),(1792,NULL,NULL,NULL,'DistanceFromAnalVerge',NULL),(1793,NULL,NULL,NULL,'LocalExcisionColorectalLateralMargin',NULL),(1794,'2008-01-22','RetropubicEnucleationPathologyAnnotation','2008-01-22','RetropubicEnucleationPathologyAnnotation',NULL),(1795,NULL,NULL,NULL,'id',NULL),(1796,NULL,'',NULL,'specimenWeight',NULL),(1797,'2008-01-22','KidneyNephrectomyBasedPathologyAnnotation','2008-01-22','KidneyNephrectomyBasedPathologyAnnotation',NULL),(1798,NULL,NULL,NULL,'id',NULL),(1799,NULL,NULL,NULL,'KidneyNephrectomyMargin',NULL),(1800,NULL,NULL,NULL,'MacroscopicExtentOfTumor',NULL),(1801,NULL,'',NULL,'adrenalGlandStage',NULL),(1802,NULL,'',NULL,'focality',NULL),(1805,NULL,NULL,NULL,'379_42',NULL),(1806,NULL,NULL,NULL,'379_45',NULL),(1807,NULL,NULL,NULL,'379_56',NULL),(1808,NULL,NULL,NULL,'379_58',NULL),(1809,NULL,NULL,NULL,'379_63',NULL),(1810,NULL,NULL,NULL,'379_64',NULL),(1811,NULL,NULL,NULL,'379_65',NULL),(1812,NULL,NULL,NULL,'379_66',NULL),(1813,NULL,NULL,NULL,'379_72',NULL),(1814,NULL,NULL,NULL,'379_73',NULL),(1815,NULL,NULL,NULL,'379_74',NULL),(1816,NULL,NULL,NULL,'379_78',NULL),(1817,NULL,NULL,NULL,'379_79',NULL),(1818,NULL,NULL,NULL,'379_80',NULL),(1819,NULL,NULL,NULL,'379_84',NULL),(1820,NULL,NULL,NULL,'379_89',NULL),(1821,NULL,NULL,NULL,'379_92',NULL),(1822,NULL,NULL,NULL,'379_98',NULL),(1823,NULL,NULL,NULL,'379_99',NULL),(1824,NULL,NULL,NULL,'379_105',NULL),(1825,NULL,NULL,NULL,'379_110',NULL),(1826,NULL,NULL,NULL,'379_116',NULL),(1827,NULL,NULL,NULL,'Size',NULL),(1828,'2008-01-22','','2008-01-22','SpecimenSize',NULL),(1829,NULL,NULL,NULL,'id',NULL),(1830,NULL,'',NULL,'cannotBeDetermined',NULL),(1831,NULL,'',NULL,'additionalDimensionTwo',NULL),(1832,NULL,'',NULL,'additionalDimensionOne',NULL),(1833,NULL,'',NULL,'greatestDimension',NULL),(1834,NULL,NULL,NULL,'Size',NULL),(1835,NULL,NULL,NULL,'Size',NULL),(1836,'2008-01-22','','2008-01-22','SizeOfInvasiveCarcinoma',NULL),(1837,NULL,NULL,NULL,'id',NULL),(1838,'2008-01-22','','2008-01-22','SizeOfSpecimen',NULL),(1839,NULL,NULL,NULL,'id',NULL),(1840,NULL,NULL,NULL,'Size',NULL),(1841,'2008-01-22','','2008-01-30','PolypSize',NULL),(1842,NULL,NULL,NULL,'id',NULL),(1843,NULL,NULL,NULL,'DistanceFromAnalVerge',NULL),(1844,NULL,NULL,NULL,'DistanceFromAnalVerge',NULL),(1845,'2008-01-22','','2008-01-22','DistanceOfAdenoma',NULL),(1846,NULL,NULL,NULL,'id',NULL),(1847,'2008-01-22','','2008-01-22','DistanceOfInvasiveCarcinoma',NULL),(1848,NULL,NULL,NULL,'id',NULL),(1849,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.Race',NULL),(1850,NULL,NULL,NULL,'id',NULL),(1851,NULL,NULL,NULL,'raceName',NULL),(1852,NULL,NULL,NULL,'participant_race',NULL),(1853,NULL,NULL,NULL,'race_participant',NULL),(1854,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.AbstractPosition',NULL),(1855,NULL,NULL,NULL,'id',NULL),(1856,NULL,NULL,NULL,'positionDimensionOne',NULL),(1857,NULL,NULL,NULL,'positionDimensionTwo',NULL),(1858,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.AbstractSpecimen',NULL),(1859,NULL,NULL,NULL,'id',NULL),(1860,NULL,NULL,NULL,'abstractSpecimen_SpecimenEventParameters',NULL),(1861,NULL,NULL,NULL,'SpecimenEventParameters_abstractSpecimen',NULL),(1862,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.SpecimenRequirement',NULL),(1863,NULL,NULL,NULL,'id',NULL),(1864,NULL,NULL,NULL,'storageType',NULL),(1865,NULL,NULL,NULL,'collectionProtocolEvent_specimenRequirement',NULL),(1866,NULL,NULL,NULL,'specimenRequirement_collectionProtocolEvent',NULL),(1867,NULL,NULL,NULL,'specimenRequirement_specimen',NULL),(1868,NULL,NULL,NULL,'specimen_specimenRequirement',NULL),(1869,NULL,NULL,NULL,'specimenClass',NULL),(1870,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment',NULL),(1871,NULL,NULL,NULL,'id',NULL),(1872,NULL,NULL,NULL,'label',NULL),(1873,NULL,NULL,NULL,'createdDate',NULL),(1874,NULL,NULL,NULL,'receiverComments',NULL),(1875,NULL,NULL,NULL,'senderComments',NULL),(1876,NULL,NULL,NULL,'sendDate',NULL),(1877,NULL,NULL,NULL,'activityStatus',NULL),(1878,NULL,NULL,NULL,'CATISSUE_BASE_SHIPMENT',NULL),(1879,NULL,NULL,NULL,'CATISSUE_BASE_SHIPMENT',NULL),(1880,NULL,NULL,NULL,'CATISSUE_BASE_SHIPMENT',NULL),(1881,NULL,NULL,NULL,'CATISSUE_BASE_SHIPMENT',NULL),(1882,NULL,NULL,NULL,'CATISSUE_SHIPMENT_CONTAINR_REL',NULL),(1883,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.shippingtracking.ShipmentRequest',NULL),(1884,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.shippingtracking.Shipment',NULL),(1885,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.ContainerPosition',NULL),(1886,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.SpecimenPosition',NULL),(1887,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.CellSpecimenRequirement',NULL),(1888,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.FluidSpecimenRequirement',NULL),(1889,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.MolecularSpecimenRequirement',NULL),(1890,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.TissueSpecimenRequirement',NULL),(1891,NULL,NULL,NULL,'id',NULL),(1892,NULL,NULL,NULL,'id',NULL),(1893,NULL,NULL,NULL,'id',NULL),(1894,NULL,NULL,NULL,'id',NULL),(1895,NULL,NULL,NULL,'id',NULL),(1896,NULL,NULL,NULL,'id',NULL),(1897,NULL,NULL,NULL,'concentrationInMicrogramPerMicroliter',NULL),(1898,NULL,NULL,NULL,'id',NULL),(1899,NULL,NULL,NULL,'id',NULL),(1900,NULL,NULL,NULL,'barcode',NULL),(1901,NULL,NULL,NULL,'specimen_specimenPosition',NULL),(1902,NULL,NULL,NULL,'specimenPosition_specimen',NULL),(1903,NULL,NULL,NULL,'CATISSUE_USER_CP',NULL),(1904,NULL,NULL,NULL,'CATISSUE_USER_CP',NULL),(1905,NULL,NULL,NULL,'CATISSUE_SITE_CP',NULL),(1906,NULL,NULL,NULL,'CATISSUE_SITE_CP',NULL),(1907,NULL,NULL,NULL,'CATISSUE_SITE_USERS',NULL),(1908,NULL,NULL,NULL,'CATISSUE_SITE_USERS',NULL),(1909,NULL,NULL,NULL,'site_abstractSCG',NULL),(1910,NULL,NULL,NULL,'CATISSUE_ORDER_ITEM',NULL),(1911,NULL,NULL,NULL,'container_containerPosition',NULL),(1912,NULL,NULL,NULL,'containerPosition_container',NULL),(1913,NULL,NULL,NULL,'storageContainer_specimenPosition',NULL),(1914,NULL,NULL,NULL,'specimenPosition_storageContainer',NULL),(1915,NULL,NULL,NULL,'CATISSUE_SHIPMENT',NULL),(1916,NULL,NULL,NULL,'CATISSUE_SPECI_SHIPMNT_REQ_REL',NULL),(1917,NULL,NULL,NULL,'signedConsentDocumentURL',NULL),(1918,NULL,NULL,NULL,'consentSignatureDate',NULL),(1919,NULL,NULL,NULL,'quantity',NULL),(1920,NULL,NULL,NULL,'unsignedConsentDocumentURL',NULL),(1921,NULL,NULL,NULL,'quantity',NULL),(1922,NULL,NULL,NULL,'barcode',NULL),(1923,NULL,NULL,NULL,'barcode',NULL),(1924,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.ClinicalDiagnosis',NULL),(1925,NULL,NULL,NULL,'id',NULL),(1926,NULL,NULL,NULL,'name',NULL),(1927,NULL,NULL,NULL,'specimenArray_specimenArrayContent',NULL),(1928,NULL,NULL,NULL,'collectionProtocol_clinicalDiagnosis',NULL),(1929,NULL,NULL,NULL,'clinicalDiagnosis_collectionProtocol',NULL),(1930,NULL,NULL,NULL,'edu.common.dynamicextensions.domain.integration.AbstractFormContext',NULL),(1931,NULL,NULL,NULL,'id',NULL),(1932,NULL,NULL,NULL,'formLabel',NULL),(1933,NULL,NULL,NULL,'containerId',NULL),(1934,NULL,NULL,NULL,'activityStatus',NULL),(1935,NULL,NULL,NULL,'hideForm',NULL),(1936,NULL,NULL,NULL,'edu.common.dynamicextensions.domain.integration.AbstractRecordEntry',NULL),(1937,NULL,NULL,NULL,'id',NULL),(1938,NULL,NULL,NULL,'activityStatus',NULL),(1939,NULL,NULL,NULL,'modifiedDate',NULL),(1940,NULL,NULL,NULL,'modifiedBy',NULL),(1941,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.deintegration.ParticipantRecordEntry',NULL),(1942,NULL,NULL,NULL,'id',NULL),(1943,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.deintegration.SpecimenRecordEntry',NULL),(1944,NULL,NULL,NULL,'id',NULL),(1945,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.deintegration.SCGRecordEntry',NULL),(1946,NULL,NULL,NULL,'id',NULL),(1947,NULL,NULL,NULL,'edu.wustl.catissuecore.domain.StudyFormContext',NULL),(1948,NULL,NULL,NULL,'id',NULL),(1949,NULL,NULL,NULL,'abstractFormContext_abstractRecordEntry',NULL),(1950,NULL,NULL,NULL,'abstractRecordEntry_abstractFormContext',NULL),(1951,NULL,NULL,NULL,'participant_participantRecordEntry',NULL),(1952,NULL,NULL,NULL,'participantRecordEntry_participant',NULL),(1953,NULL,NULL,NULL,'specimen_specimenRecordEntry',NULL),(1954,NULL,NULL,NULL,'specimenRecordEntry_specimen',NULL),(1955,NULL,NULL,NULL,'scg_scgRecordEntry',NULL),(1956,NULL,NULL,NULL,'scgRecordEntry_scg',NULL),(1957,NULL,NULL,NULL,'CATISSUE_CP_STUDYFORMCONTEXT',NULL),(1958,NULL,NULL,NULL,'CATISSUE_CP_STUDYFORMCONTEXT',NULL);

/*Table structure for table `dyextn_abstract_record_entry` */

DROP TABLE IF EXISTS `dyextn_abstract_record_entry`;

CREATE TABLE `dyextn_abstract_record_entry` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `MODIFIED_DATE` date DEFAULT NULL,
  `MODIFIED_BY` varchar(255) DEFAULT NULL,
  `ACTIVITY_STATUS` varchar(10) DEFAULT NULL,
  `ABSTRACT_FORM_CONTEXT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKA74A5FE4DDFB1974` (`ABSTRACT_FORM_CONTEXT_ID`),
  CONSTRAINT `FKA74A5FE4DDFB1974` FOREIGN KEY (`ABSTRACT_FORM_CONTEXT_ID`) REFERENCES `dyextn_abstract_form_context` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_abstract_record_entry` */

/*Table structure for table `dyextn_base_abstract_attribute` */

DROP TABLE IF EXISTS `dyextn_base_abstract_attribute`;

CREATE TABLE `dyextn_base_abstract_attribute` (
  `IDENTIFIER` bigint(20) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK14BA6610728B19BE` (`IDENTIFIER`),
  CONSTRAINT `FK14BA6610728B19BE` FOREIGN KEY (`IDENTIFIER`) REFERENCES `dyextn_abstract_metadata` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_base_abstract_attribute` */

insert  into `dyextn_base_abstract_attribute`(`IDENTIFIER`) values (3),(6),(7),(8),(13),(14),(15),(17),(18),(19),(21),(22),(23),(24),(25),(26),(27),(41),(45),(46),(47),(50),(51),(52),(54),(56),(57),(58),(59),(60),(63),(64),(65),(66),(71),(72),(73),(74),(76),(77),(78),(81),(82),(83),(84),(85),(86),(90),(91),(92),(93),(94),(95),(96),(98),(99),(100),(101),(102),(103),(104),(105),(106),(107),(108),(109),(110),(111),(113),(114),(115),(117),(118),(119),(120),(121),(122),(123),(124),(126),(127),(129),(130),(132),(133),(135),(136),(137),(138),(139),(140),(141),(143),(144),(145),(147),(148),(149),(150),(151),(152),(153),(154),(155),(156),(158),(159),(160),(161),(162),(163),(164),(165),(167),(168),(169),(170),(171),(172),(173),(174),(175),(176),(178),(179),(180),(181),(182),(183),(184),(185),(186),(187),(188),(189),(190),(191),(193),(194),(195),(196),(197),(198),(199),(200),(201),(202),(204),(205),(221),(222),(223),(226),(227),(228),(235),(236),(238),(240),(242),(243),(245),(246),(248),(249),(263),(264),(265),(272),(274),(276),(278),(279),(281),(282),(284),(296),(299),(300),(301),(308),(310),(312),(314),(315),(317),(318),(320),(332),(335),(336),(337),(344),(346),(348),(350),(351),(353),(354),(356),(368),(370),(371),(372),(374),(375),(376),(377),(378),(380),(381),(382),(383),(384),(385),(386),(387),(388),(389),(390),(392),(393),(394),(395),(396),(397),(398),(399),(400),(401),(402),(403),(404),(405),(406),(407),(408),(409),(410),(412),(413),(414),(421),(422),(423),(424),(431),(432),(433),(434),(435),(436),(443),(444),(445),(446),(447),(454),(455),(456),(457),(464),(465),(466),(467),(468),(469),(473),(474),(475),(476),(477),(478),(479),(480),(481),(482),(492),(493),(494),(495),(496),(503),(504),(505),(506),(507),(514),(515),(516),(517),(522),(523),(524),(525),(526),(527),(528),(529),(530),(531),(532),(537),(538),(539),(540),(541),(542),(543),(544),(545),(556),(557),(558),(559),(560),(561),(568),(569),(570),(571),(572),(579),(580),(581),(582),(583),(585),(586),(587),(588),(589),(590),(591),(592),(593),(594),(601),(602),(603),(604),(605),(606),(613),(614),(615),(616),(617),(619),(620),(621),(622),(623),(624),(625),(626),(627),(634),(635),(636),(637),(638),(639),(641),(642),(643),(644),(645),(646),(647),(648),(649),(651),(652),(654),(655),(656),(658),(659),(660),(661),(662),(664),(665),(667),(668),(669),(670),(672),(673),(675),(676),(677),(678),(679),(680),(681),(682),(683),(684),(686),(687),(688),(689),(690),(691),(692),(693),(694),(695),(696),(697),(699),(700),(701),(702),(703),(704),(705),(707),(708),(710),(711),(712),(713),(715),(716),(718),(719),(720),(721),(735),(737),(738),(739),(741),(742),(748),(753),(755),(756),(757),(758),(759),(760),(761),(763),(764),(765),(766),(767),(768),(769),(776),(778),(779),(780),(787),(789),(790),(791),(792),(793),(799),(800),(801),(802),(803),(804),(805),(807),(808),(809),(817),(818),(819),(820),(821),(823),(824),(825),(826),(827),(828),(831),(832),(833),(834),(835),(836),(837),(838),(839),(841),(842),(843),(845),(846),(847),(848),(849),(850),(851),(852),(853),(854),(855),(856),(863),(865),(866),(867),(873),(874),(875),(876),(878),(879),(880),(881),(882),(883),(884),(889),(890),(891),(892),(893),(894),(895),(896),(898),(903),(904),(905),(906),(907),(908),(909),(910),(912),(913),(914),(916),(917),(918),(919),(920),(922),(923),(924),(925),(927),(928),(929),(930),(931),(933),(939),(940),(941),(942),(943),(945),(946),(947),(948),(950),(952),(953),(954),(955),(961),(966),(967),(968),(969),(970),(971),(972),(973),(974),(976),(977),(978),(979),(980),(987),(988),(990),(991),(992),(993),(994),(996),(999),(1005),(1029),(1030),(1031),(1033),(1034),(1035),(1038),(1041),(1060),(1061),(1065),(1068),(1086),(1087),(1092),(1095),(1112),(1113),(1119),(1122),(1138),(1139),(1140),(1141),(1142),(1143),(1144),(1145),(1146),(1147),(1148),(1149),(1150),(1151),(1152),(1153),(1154),(1155),(1156),(1157),(1158),(1159),(1160),(1161),(1162),(1163),(1164),(1165),(1166),(1167),(1168),(1169),(1170),(1171),(1172),(1173),(1174),(1175),(1176),(1177),(1178),(1179),(1180),(1182),(1188),(1189),(1190),(1191),(1192),(1193),(1194),(1195),(1196),(1197),(1198),(1199),(1200),(1201),(1202),(1203),(1204),(1205),(1206),(1207),(1209),(1210),(1211),(1213),(1215),(1217),(1219),(1220),(1221),(1222),(1223),(1224),(1225),(1228),(1229),(1231),(1232),(1233),(1234),(1235),(1237),(1238),(1239),(1240),(1242),(1243),(1245),(1246),(1247),(1248),(1250),(1251),(1252),(1253),(1255),(1256),(1257),(1259),(1260),(1261),(1262),(1263),(1265),(1266),(1267),(1268),(1269),(1270),(1272),(1275),(1278),(1280),(1281),(1282),(1284),(1285),(1286),(1287),(1288),(1289),(1291),(1293),(1294),(1296),(1298),(1299),(1301),(1302),(1303),(1304),(1305),(1306),(1307),(1308),(1309),(1310),(1311),(1312),(1313),(1314),(1315),(1316),(1319),(1320),(1321),(1323),(1324),(1326),(1328),(1329),(1330),(1331),(1333),(1334),(1335),(1337),(1338),(1340),(1341),(1342),(1343),(1345),(1346),(1347),(1348),(1350),(1351),(1352),(1353),(1354),(1355),(1356),(1358),(1360),(1361),(1362),(1364),(1366),(1368),(1370),(1371),(1372),(1373),(1374),(1376),(1378),(1380),(1382),(1383),(1384),(1385),(1387),(1390),(1391),(1392),(1393),(1394),(1395),(1396),(1397),(1398),(1399),(1401),(1402),(1403),(1405),(1406),(1407),(1409),(1410),(1411),(1412),(1413),(1415),(1416),(1417),(1418),(1419),(1420),(1422),(1423),(1424),(1425),(1426),(1428),(1429),(1430),(1431),(1433),(1435),(1438),(1439),(1441),(1442),(1443),(1444),(1445),(1446),(1448),(1449),(1450),(1452),(1453),(1455),(1456),(1457),(1459),(1460),(1462),(1463),(1464),(1465),(1466),(1467),(1469),(1470),(1471),(1472),(1474),(1475),(1476),(1477),(1478),(1480),(1481),(1482),(1483),(1485),(1486),(1487),(1488),(1490),(1491),(1492),(1493),(1494),(1495),(1496),(1498),(1499),(1500),(1502),(1503),(1504),(1506),(1507),(1509),(1510),(1511),(1512),(1514),(1515),(1517),(1519),(1520),(1521),(1522),(1523),(1525),(1526),(1528),(1529),(1530),(1531),(1532),(1534),(1535),(1537),(1538),(1540),(1542),(1543),(1544),(1546),(1547),(1548),(1549),(1550),(1552),(1553),(1554),(1555),(1557),(1558),(1560),(1561),(1563),(1564),(1565),(1567),(1568),(1569),(1571),(1572),(1573),(1575),(1576),(1578),(1579),(1580),(1581),(1582),(1583),(1585),(1586),(1587),(1588),(1590),(1591),(1592),(1594),(1596),(1597),(1598),(1599),(1601),(1602),(1603),(1604),(1606),(1607),(1609),(1610),(1611),(1613),(1614),(1616),(1617),(1618),(1619),(1621),(1622),(1623),(1624),(1626),(1627),(1628),(1629),(1630),(1632),(1633),(1634),(1636),(1638),(1639),(1641),(1642),(1643),(1645),(1646),(1647),(1649),(1650),(1651),(1653),(1654),(1655),(1656),(1657),(1658),(1660),(1661),(1662),(1664),(1665),(1666),(1668),(1669),(1670),(1671),(1672),(1674),(1675),(1677),(1678),(1679),(1681),(1682),(1683),(1684),(1686),(1687),(1688),(1689),(1691),(1692),(1694),(1695),(1696),(1698),(1699),(1700),(1702),(1703),(1704),(1706),(1707),(1708),(1710),(1711),(1712),(1713),(1714),(1716),(1717),(1718),(1719),(1720),(1721),(1722),(1724),(1725),(1726),(1728),(1729),(1730),(1732),(1733),(1734),(1736),(1737),(1738),(1739),(1740),(1741),(1742),(1743),(1744),(1745),(1746),(1747),(1748),(1750),(1751),(1752),(1753),(1755),(1756),(1758),(1759),(1760),(1761),(1763),(1764),(1766),(1767),(1768),(1769),(1771),(1772),(1774),(1776),(1778),(1779),(1780),(1782),(1783),(1785),(1786),(1787),(1789),(1790),(1791),(1792),(1793),(1795),(1796),(1798),(1799),(1800),(1801),(1802),(1805),(1806),(1807),(1808),(1809),(1810),(1811),(1812),(1813),(1814),(1815),(1816),(1817),(1818),(1819),(1820),(1821),(1822),(1823),(1824),(1825),(1826),(1827),(1829),(1830),(1831),(1832),(1833),(1834),(1835),(1837),(1839),(1840),(1842),(1843),(1844),(1846),(1848),(1850),(1851),(1852),(1853),(1855),(1856),(1857),(1859),(1860),(1861),(1863),(1864),(1865),(1866),(1867),(1868),(1869),(1871),(1872),(1873),(1874),(1875),(1876),(1877),(1878),(1879),(1880),(1881),(1882),(1891),(1892),(1893),(1894),(1895),(1896),(1897),(1898),(1899),(1900),(1901),(1902),(1903),(1904),(1905),(1906),(1907),(1908),(1909),(1910),(1911),(1912),(1913),(1914),(1915),(1916),(1917),(1918),(1919),(1920),(1921),(1922),(1923),(1925),(1926),(1927),(1928),(1929),(1931),(1932),(1933),(1934),(1935),(1937),(1938),(1939),(1940),(1942),(1944),(1946),(1948),(1949),(1950),(1951),(1952),(1953),(1954),(1955),(1956),(1957),(1958);

/*Table structure for table `dyextn_database_properties` */

DROP TABLE IF EXISTS `dyextn_database_properties`;

CREATE TABLE `dyextn_database_properties` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=3056 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_database_properties` */

insert  into `dyextn_database_properties`(`IDENTIFIER`,`NAME`) values (1,'DE_E_2'),(2,'DE_AT_3'),(3,'CATISSUE_SPECIMEN'),(4,'CATISSUE_SPECIMEN_BIOHZ_REL'),(5,'DE_E_902'),(7,'DE_E_618'),(10,'DE_E_584'),(16,'DE_E_4'),(31,'DE_E_4'),(32,'DE_E_4'),(33,'DE_E_369'),(38,'DE_E_4'),(39,'DE_E_4'),(40,'IDENTIFIER'),(42,'COLLECTION_STATUS'),(43,'PATHOLOGICAL_STATUS'),(44,'AVAILABLE'),(46,'BARCODE'),(47,'CREATED_ON_DATE'),(48,'SPECIMEN_TYPE'),(49,'LABEL'),(50,'ACTIVITY_STATUS'),(51,'LINEAGE'),(52,'COMMENTS'),(65,'CATISSUE_CONTAINER'),(69,'DE_E_142'),(73,'COMMENTS'),(74,'CONT_FULL'),(75,'BARCODE'),(78,'ACTIVITY_STATUS'),(79,'NAME'),(80,'IDENTIFIER'),(81,'CATISSUE_SPECIMEN_ARRAY'),(86,'DE_E_142'),(88,'DE_E_53'),(89,'IDENTIFIER'),(90,'NAME'),(91,'ACTIVITY_STATUS'),(92,'AVAILABLE'),(95,'BARCODE'),(96,'CONT_FULL'),(97,'COMMENTS'),(98,'DE_E_157'),(102,'CATISSUE_STORAGE_CONTAINER'),(106,'DE_E_142'),(107,'CATISSUE_CONT_HOLDS_SPARRTYPE'),(108,'CATISSUE_ST_CONT_ST_TYPE_REL'),(109,'CATISSUE_ST_CONT_COLL_PROT_REL'),(111,'IDENTIFIER'),(112,'NAME'),(113,'ACTIVITY_STATUS'),(116,'BARCODE'),(117,'CONT_FULL'),(118,'COMMENTS'),(119,'TEMPERATURE'),(120,'DE_E_146'),(121,'DE_E_70'),(124,'CATISSUE_SITE'),(125,'DE_E_116'),(126,'DE_E_89'),(127,'ACTIVITY_STATUS'),(128,'NAME'),(129,'IDENTIFIER'),(130,'EMAIL_ADDRESS'),(131,'TYPE'),(132,'CATISSUE_USER'),(133,'CATISSUE_COLL_COORDINATORS'),(134,'DE_E_97'),(135,'LAST_NAME'),(136,'CSM_USER_ID'),(137,'IDENTIFIER'),(138,'START_DATE'),(139,'ACTIVITY_STATUS'),(140,'FIRST_NAME'),(141,'STATUS_COMMENT'),(142,'LOGIN_NAME'),(143,'EMAIL_ADDRESS'),(144,'DE_E_97'),(145,'DE_E_97'),(146,'DE_E_116'),(147,'DE_E_112'),(148,'CATISSUE_PASSWORD'),(149,'PASSWORD'),(150,'UPDATE_DATE'),(151,'IDENTIFIER'),(152,'CATISSUE_ADDRESS'),(153,'FAX_NUMBER'),(154,'CITY'),(155,'STATE'),(156,'ZIPCODE'),(157,'PHONE_NUMBER'),(158,'COUNTRY'),(159,'STREET'),(160,'IDENTIFIER'),(161,'CATISSUE_INSTITUTION'),(162,'NAME'),(163,'IDENTIFIER'),(164,'CATISSUE_CANCER_RESEARCH_GROUP'),(165,'NAME'),(166,'IDENTIFIER'),(167,'CATISSUE_DEPARTMENT'),(168,'NAME'),(169,'IDENTIFIER'),(170,'CATISSUE_CONTAINER_TYPE'),(171,'DE_E_142'),(172,'ACTIVITY_STATUS'),(173,'ONE_DIMENSION_LABEL'),(174,'COMMENTS'),(175,'TWO_DIMENSION_LABEL'),(176,'NAME'),(177,'IDENTIFIER'),(178,'CATISSUE_CAPACITY'),(179,'ONE_DIMENSION_CAPACITY'),(180,'TWO_DIMENSION_CAPACITY'),(181,'IDENTIFIER'),(182,'CATISSUE_STORAGE_TYPE'),(183,'CATISSUE_STORTY_HOLDS_SPARRTY'),(184,'DE_E_142'),(185,'CATISSUE_STOR_TYPE_HOLDS_TYPE'),(186,'ACTIVITY_STATUS'),(187,'ONE_DIMENSION_LABEL'),(188,'COMMENTS'),(189,'DEFAULT_TEMPERATURE'),(190,'TWO_DIMENSION_LABEL'),(191,'NAME'),(192,'IDENTIFIER'),(193,'CATISSUE_SPECIMEN_ARRAY_TYPE'),(194,'DE_E_142'),(195,'ACTIVITY_STATUS'),(196,'ONE_DIMENSION_LABEL'),(197,'COMMENTS'),(198,'TWO_DIMENSION_LABEL'),(199,'SPECIMEN_CLASS'),(200,'NAME'),(201,'IDENTIFIER'),(202,'CATISSUE_SPECIMEN_PROTOCOL'),(203,'DE_E_166'),(204,'START_DATE'),(205,'TITLE'),(206,'ACTIVITY_STATUS'),(207,'IRB_IDENTIFIER'),(208,'ENROLLMENT'),(209,'SHORT_TITLE'),(210,'DESCRIPTION_URL'),(211,'END_DATE'),(212,'IDENTIFIER'),(213,'CATISSUE_COLLECTION_PROTOCOL'),(214,'DE_E_830'),(215,'DE_E_717'),(216,'DE_E_203'),(217,'IDENTIFIER'),(218,'END_DATE'),(219,'DESCRIPTION_URL'),(220,'SHORT_TITLE'),(221,'ENROLLMENT'),(222,'IRB_IDENTIFIER'),(223,'ALIQUOT_IN_SAME_CONTAINER'),(224,'ACTIVITY_STATUS'),(225,'TITLE'),(226,'START_DATE'),(227,'DE_E_177'),(228,'CATISSUE_COLL_COORDINATORS'),(229,'CATISSUE_COLL_DISTRIBUTION_REL'),(230,'CATISSUE_DISTRIBUTION_PROTOCOL'),(232,'CATISSUE_COLL_DISTRIBUTION_REL'),(233,'DE_E_192'),(234,'START_DATE'),(235,'TITLE'),(236,'ACTIVITY_STATUS'),(237,'IRB_IDENTIFIER'),(238,'ENROLLMENT'),(239,'SHORT_TITLE'),(240,'IDENTIFIER'),(241,'END_DATE'),(242,'DESCRIPTION_URL'),(243,'CATISSUE_CONSENT_TIER'),(244,'STATEMENT'),(245,'IDENTIFIER'),(260,'CATISSUE_SPECIMEN_CHAR'),(261,'TISSUE_SIDE'),(262,'TISSUE_SITE'),(263,'IDENTIFIER'),(264,'CATISSUE_MOLECULAR_SPECIMEN'),(265,'DE_AS_965_224_969'),(266,'DE_E_902'),(269,'DE_E_618'),(272,'DE_E_584'),(292,'DE_E_224'),(293,'DE_E_224'),(294,'DE_E_369'),(301,'DE_E_224'),(302,'IDENTIFIER'),(304,'COLLECTION_STATUS'),(306,'AVAILABLE'),(308,'BARCODE'),(309,'CREATED_ON_DATE'),(311,'LABEL'),(312,'ACTIVITY_STATUS'),(314,'COMMENTS'),(315,'CONCENTRATION'),(327,'CATISSUE_CELL_SPECIMEN'),(328,'DE_AS_965_261_968'),(329,'DE_E_902'),(333,'DE_E_618'),(336,'DE_E_584'),(355,'DE_E_261'),(356,'DE_E_261'),(357,'DE_E_369'),(364,'IDENTIFIER'),(366,'COLLECTION_STATUS'),(368,'AVAILABLE'),(370,'BARCODE'),(371,'CREATED_ON_DATE'),(373,'LABEL'),(374,'ACTIVITY_STATUS'),(376,'COMMENTS'),(388,'DE_E_261'),(389,'CATISSUE_TISSUE_SPECIMEN'),(390,'DE_AS_965_297_967'),(391,'DE_E_902'),(396,'DE_E_618'),(399,'DE_E_584'),(417,'DE_E_297'),(418,'DE_E_297'),(419,'DE_E_369'),(426,'IDENTIFIER'),(428,'COLLECTION_STATUS'),(430,'AVAILABLE'),(432,'BARCODE'),(433,'CREATED_ON_DATE'),(435,'LABEL'),(436,'ACTIVITY_STATUS'),(438,'COMMENTS'),(450,'DE_E_297'),(451,'CATISSUE_FLUID_SPECIMEN'),(452,'DE_AS_965_333_966'),(453,'DE_E_902'),(459,'DE_E_618'),(462,'DE_E_584'),(479,'DE_E_333'),(480,'DE_E_333'),(481,'DE_E_369'),(488,'IDENTIFIER'),(490,'COLLECTION_STATUS'),(492,'AVAILABLE'),(494,'BARCODE'),(495,'CREATED_ON_DATE'),(497,'LABEL'),(498,'ACTIVITY_STATUS'),(500,'COMMENTS'),(512,'DE_E_333'),(513,'CATISSUE_CONSENT_TIER_STATUS'),(514,'DE_E_369'),(515,'STATUS'),(516,'IDENTIFIER'),(517,'CATISSUE_ABS_SPECI_COLL_GROUP'),(518,'DE_E_4'),(519,'DE_E_224'),(520,'DE_E_261'),(521,'DE_E_297'),(522,'DE_E_333'),(523,'DE_E_373'),(524,'CLINICAL_DIAGNOSIS'),(525,'CLINICAL_STATUS'),(526,'ACTIVITY_STATUS'),(527,'IDENTIFIER'),(528,'CATISSUE_SPECIMEN_COLL_GROUP'),(529,'DE_E_379'),(530,'DE_E_4'),(531,'DE_E_224'),(532,'DE_E_261'),(533,'DE_E_297'),(534,'DE_E_333'),(535,'DE_E_379'),(536,'DE_E_379'),(537,'DE_E_379'),(538,'DE_E_674'),(539,'DE_E_369'),(540,'CATISSUE_SPECIMEN_EVENT_PARAM'),(541,'CATISSUE_SPECIMEN_EVENT_PARAM'),(542,'CATISSUE_SPECIMEN_EVENT_PARAM'),(543,'CATISSUE_SPECIMEN_EVENT_PARAM'),(544,'CATISSUE_SPECIMEN_EVENT_PARAM'),(545,'CATISSUE_SPECIMEN_EVENT_PARAM'),(546,'CATISSUE_SPECIMEN_EVENT_PARAM'),(548,'NAME'),(549,'CLINICAL_STATUS'),(550,'SURGICAL_PATHOLOGY_NUMBER'),(551,'COLLECTION_STATUS'),(552,'COMMENTS'),(553,'ACTIVITY_STATUS'),(554,'IDENTIFIER'),(555,'CATISSUE_SPECIMEN_EVENT_PARAM'),(556,'CATISSUE_SPECIMEN_EVENT_PARAM'),(557,'CATISSUE_SPECIMEN_EVENT_PARAM'),(558,'CATISSUE_SPECIMEN_EVENT_PARAM'),(559,'CATISSUE_SPECIMEN_EVENT_PARAM'),(560,'CATISSUE_SPECIMEN_EVENT_PARAM'),(561,'CATISSUE_SPECIMEN_EVENT_PARAM'),(562,'CATISSUE_SPECIMEN_EVENT_PARAM'),(563,'CATISSUE_SPECIMEN_EVENT_PARAM'),(564,'CATISSUE_SPECIMEN_EVENT_PARAM'),(565,'CATISSUE_SPECIMEN_EVENT_PARAM'),(566,'CATISSUE_SPECIMEN_EVENT_PARAM'),(567,'DE_E_411'),(568,'DE_AT_412'),(569,'DE_AT_413'),(570,'DE_AT_414'),(571,'CATISSUE_SPECIMEN_EVENT_PARAM'),(572,'DE_AS_379_415_390'),(578,'DE_E_415'),(579,'EVENT_TIMESTAMP'),(580,'COMMENTS'),(581,'IDENTIFIER'),(582,'CATISSUE_SPUN_EVENT_PARAMETERS'),(583,'DE_AS_379_425_410'),(589,'DE_E_425'),(590,'EVENT_TIMESTAMP'),(591,'DURATION_IN_MINUTES'),(592,'COMMENTS'),(593,'GFORCE'),(594,'IDENTIFIER'),(595,'CATISSUE_EMBEDDED_EVENT_PARAM'),(596,'DE_AS_379_437_409'),(602,'DE_E_437'),(603,'EVENT_TIMESTAMP'),(604,'EMBEDDING_MEDIUM'),(605,'COMMENTS'),(606,'IDENTIFIER'),(607,'CATISSUE_THAW_EVENT_PARAMETERS'),(608,'DE_AS_379_448_408'),(614,'DE_E_448'),(615,'EVENT_TIMESTAMP'),(616,'COMMENTS'),(617,'IDENTIFIER'),(618,'CATISSUE_FIXED_EVENT_PARAM'),(619,'DE_AS_379_458_407'),(625,'DE_E_458'),(626,'EVENT_TIMESTAMP'),(627,'FIXATION_TYPE'),(628,'DURATION_IN_MINUTES'),(629,'COMMENTS'),(630,'IDENTIFIER'),(631,'CATISSUE_TRANSFER_EVENT_PARAM'),(632,'DE_AS_379_470_406'),(635,'IDENTIFIER'),(636,'TO_POSITION_DIMENSION_ONE'),(637,'FROM_POSITION_DIMENSION_ONE'),(638,'TO_POSITION_DIMENSION_TWO'),(639,'COMMENTS'),(640,'FROM_POSITION_DIMENSION_TWO'),(641,'EVENT_TIMESTAMP'),(642,'DE_E_470'),(643,'DE_E_470'),(644,'DE_E_470'),(648,'CATISSUE_RECEIVED_EVENT_PARAM'),(649,'DE_AS_379_486_405'),(655,'DE_E_486'),(656,'EVENT_TIMESTAMP'),(657,'RECEIVED_QUALITY'),(658,'COMMENTS'),(659,'IDENTIFIER'),(660,'CATISSUE_IN_OUT_EVENT_PARAM'),(661,'DE_AS_379_497_404'),(667,'DE_E_497'),(668,'EVENT_TIMESTAMP'),(669,'COMMENTS'),(670,'STORAGE_STATUS'),(671,'IDENTIFIER'),(672,'CATISSUE_EVENT_PARAM'),(673,'DE_AS_379_508_399'),(679,'DE_E_508'),(680,'EVENT_TIMESTAMP'),(681,'COMMENTS'),(682,'IDENTIFIER'),(683,'CATISSUE_MOL_SPE_REVIEW_PARAM'),(684,'DE_AS_379_518_403'),(688,'IDENTIFIER'),(689,'GEL_IMAGE_URL'),(690,'RATIO_28S_TO_18S'),(691,'COMMENTS'),(692,'LANE_NUMBER'),(693,'GEL_NUMBER'),(694,'QUALITY_INDEX'),(695,'ABSORBANCE_AT_280'),(696,'ABSORBANCE_AT_260'),(697,'EVENT_TIMESTAMP'),(698,'DE_E_518'),(701,'CATISSUE_TIS_SPE_EVENT_PARAM'),(702,'DE_AS_379_535_402'),(704,'HISTOLOGICAL_QUALITY'),(705,'IDENTIFIER'),(706,'TOTAL_CELLULARITY_PERCENTAGE'),(707,'NEOPLASTIC_CELLULARITY_PER'),(708,'COMMENTS'),(709,'NECROSIS_PERCENTAGE'),(710,'LYMPHOCYTIC_PERCENTAGE'),(711,'EVENT_TIMESTAMP'),(712,'DE_E_535'),(717,'CATISSUE_CELL_SPE_REVIEW_PARAM'),(718,'DE_AS_379_550_401'),(724,'DE_E_550'),(725,'EVENT_TIMESTAMP'),(726,'COMMENTS'),(727,'NEOPLASTIC_CELLULARITY_PER'),(728,'VIABLE_CELL_PERCENTAGE'),(729,'IDENTIFIER'),(730,'CATISSUE_FLUID_SPE_EVENT_PARAM'),(731,'DE_AS_379_562_400'),(737,'DE_E_562'),(738,'EVENT_TIMESTAMP'),(739,'COMMENTS'),(740,'CELL_COUNT'),(741,'IDENTIFIER'),(742,'CATISSUE_DISPOSAL_EVENT_PARAM'),(743,'DE_AS_379_573_389'),(749,'DE_E_573'),(750,'EVENT_TIMESTAMP'),(751,'COMMENTS'),(752,'REASON'),(753,'IDENTIFIER'),(754,'DE_E_584'),(755,'DE_AS_379_584_388'),(756,'DE_E_584'),(757,'DE_E_584'),(758,'DE_E_584'),(759,'DE_E_584'),(760,'DE_E_584'),(761,'DE_E_584'),(762,'DE_AT_591'),(763,'DE_AT_592'),(764,'DE_AT_593'),(765,'DE_AT_594'),(766,'CATISSUE_PROCEDURE_EVENT_PARAM'),(767,'DE_AS_379_595_387'),(773,'DE_E_595'),(774,'EVENT_TIMESTAMP'),(775,'URL'),(776,'NAME'),(777,'COMMENTS'),(778,'IDENTIFIER'),(779,'CATISSUE_FROZEN_EVENT_PARAM'),(780,'DE_AS_379_607_386'),(786,'DE_E_607'),(787,'EVENT_TIMESTAMP'),(788,'METHOD'),(789,'COMMENTS'),(790,'IDENTIFIER'),(791,'DE_E_618'),(792,'DE_AS_379_618_385'),(793,'DE_E_618'),(794,'DE_E_618'),(795,'DE_E_618'),(796,'DE_E_618'),(797,'DE_E_618'),(798,'DE_E_618'),(799,'DE_AT_625'),(800,'DE_AT_626'),(801,'DE_AT_627'),(802,'CATISSUE_COLL_EVENT_PARAM'),(803,'DE_AS_379_628_384'),(809,'DE_E_628'),(810,'EVENT_TIMESTAMP'),(811,'COMMENTS'),(812,'CONTAINER'),(813,'COLLECTION_PROCEDURE'),(814,'IDENTIFIER'),(815,'CATISSUE_PATHOLOGY_REPORT'),(816,'DE_E_640'),(817,'DE_E_666'),(818,'DE_E_640'),(819,'DE_E_653'),(820,'DE_E_640'),(821,'COLLECTION_DATE_TIME'),(822,'REVIEW_FLAG'),(823,'ACTIVITY_STATUS'),(824,'IDENTIFIER'),(825,'CATISSUE_REPORT_CONTENT'),(826,'REPORT_DATA'),(827,'IDENTIFIER'),(828,'CATISSUE_REPORT_TEXTCONTENT'),(829,'DE_E_653'),(830,'DE_E_653'),(831,'DE_E_653'),(832,'DE_E_657'),(833,'REPORT_DATA'),(834,'IDENTIFIER'),(835,'CATISSUE_REPORT_SECTION'),(836,'DE_E_657'),(837,'DOCUMENT_FRAGMENT'),(838,'END_OFFSET'),(839,'NAME'),(840,'START_OFFSET'),(841,'IDENTIFIER'),(842,'CATISSUE_REPORT_BICONTENT'),(843,'REPORT_DATA'),(844,'IDENTIFIER'),(845,'CATISSUE_REVIEW_PARAMS'),(846,'DE_E_666'),(847,'DE_E_666'),(848,'DE_E_666'),(849,'EVENT_TIMESTAMP'),(850,'COMMENTS'),(851,'REVIEWER_ROLE'),(852,'IDENTIFIER'),(853,'CATISSUE_REPORT_XMLCONTENT'),(854,'REPORT_DATA'),(855,'IDENTIFIER'),(856,'CATISSUE_IDENTIFIED_REPORT'),(857,'DE_E_674'),(858,'DE_E_674'),(859,'DE_E_666'),(860,'DE_E_674'),(861,'DE_E_653'),(862,'DE_E_685'),(863,'DE_E_674'),(864,'COLLECTION_DATE_TIME'),(865,'REVIEW_FLAG'),(866,'ACTIVITY_STATUS'),(867,'IDENTIFIER'),(868,'CATISSUE_DEIDENTIFIED_REPORT'),(869,'DE_E_926'),(870,'DE_E_698'),(871,'DE_E_685'),(872,'DE_E_666'),(873,'DE_E_685'),(874,'DE_E_379'),(875,'DE_E_653'),(876,'DE_E_685'),(877,'COLLECTION_DATE_TIME'),(878,'REVIEW_FLAG'),(879,'STATUS'),(880,'ACTIVITY_STATUS'),(881,'IDENTIFIER'),(882,'CATISSUE_CONCEPT_REFERENT'),(883,'DE_E_698'),(884,'DE_E_698'),(885,'DE_E_698'),(886,'IS_NEGATED'),(887,'IS_MODIFIER'),(888,'START_OFFSET'),(889,'IDENTIFIER'),(890,'END_OFFSET'),(891,'CATISSUE_CONCEPT_CLASSIFICATN'),(892,'DE_E_698'),(893,'NAME'),(894,'IDENTIFIER'),(895,'CATISSUE_CONCEPT'),(896,'DE_E_698'),(897,'DE_E_709'),(898,'NAME'),(899,'CONCEPT_UNIQUE_ID'),(900,'IDENTIFIER'),(901,'CATISSUE_SEMANTIC_TYPE'),(902,'LABEL'),(903,'IDENTIFIER'),(904,'CATISSUE_COLL_PROT_EVENT'),(906,'DE_E_379'),(907,'DE_E_717'),(908,'COLLECTION_POINT_LABEL'),(909,'STUDY_CALENDAR_EVENT_POINT'),(910,'IDENTIFIER'),(923,'CATISSUE_ORDER_ITEM'),(929,'DE_E_729'),(931,'DESCRIPTION'),(932,'STATUS'),(933,'IDENTIFIER'),(934,'CATISSUE_DISTRIBUTED_ITEM'),(935,'IDENTIFIER'),(936,'DE_E_53'),(942,'DE_E_740'),(947,'DE_E_740'),(948,'CATISSUE_DISTRIBUTION'),(949,'DE_E_740'),(950,'DE_E_754'),(951,'DE_E_754'),(952,'DE_E_754'),(953,'COMMENTS'),(954,'EVENT_TIMESTAMP'),(955,'ACTIVITY_STATUS'),(956,'IDENTIFIER'),(957,'CATISSUE_ORDER'),(958,'DE_E_981'),(959,'DE_E_886'),(960,'DE_E_868'),(961,'DE_E_729'),(962,'DE_E_770'),(963,'DE_E_781'),(964,'DE_E_794'),(965,'DE_E_812'),(966,'DE_E_857'),(967,'CATISSUE_DISTRIBUTION'),(968,'DE_E_762'),(969,'NAME'),(970,'STATUS'),(971,'REQUESTED_DATE'),(972,'COMMENTS'),(973,'IDENTIFIER'),(974,'CATISSUE_SPECIMEN_ORDER_ITEM'),(975,'DE_E_770'),(981,'DE_E_770'),(983,'DESCRIPTION'),(984,'STATUS'),(985,'IDENTIFIER'),(986,'CATISSUE_NEW_SPEC_ORD_ITEM'),(987,'DE_E_781'),(993,'DE_E_781'),(995,'DE_AT_789'),(996,'SPECIMEN_CLASS'),(997,'SPECIMEN_TYPE'),(998,'DE_AT_792'),(999,'IDENTIFIER'),(1000,'CATISSUE_PATH_CASE_ORDER_ITEM'),(1001,'DE_E_794'),(1006,'IDENTIFIER'),(1007,'STATUS'),(1008,'PATHOLOGICAL_STATUS'),(1009,'SPECIMEN_TYPE'),(1010,'SPECIMEN_CLASS'),(1011,'DESCRIPTION'),(1012,'TISSUE_SITE'),(1014,'DE_E_794'),(1015,'DE_E_794'),(1016,'DE_E_794'),(1019,'CATISSUE_DERIEVED_SP_ORD_ITEM'),(1020,'DE_E_812'),(1025,'IDENTIFIER'),(1026,'STATUS'),(1027,'SPECIMEN_TYPE'),(1028,'SPECIMEN_CLASS'),(1029,'DESCRIPTION'),(1031,'DE_E_812'),(1032,'DE_E_812'),(1033,'DE_E_812'),(1034,'DE_E_812'),(1035,'DE_E_812'),(1036,'DE_E_812'),(1038,'CATISSUE_COLL_PROT_REG'),(1039,'DE_E_830'),(1040,'DE_E_830'),(1041,'DE_E_840'),(1042,'DE_E_379'),(1043,'DE_E_830'),(1044,'ACTIVITY_STATUS'),(1045,'PROTOCOL_PARTICIPANT_ID'),(1046,'IDENTIFIER'),(1047,'REGISTRATION_DATE'),(1048,'CATISSUE_CONSENT_TIER_RESPONSE'),(1049,'DE_E_840'),(1050,'RESPONSE'),(1051,'IDENTIFIER'),(1052,'CATISSUE_PARTICIPANT'),(1053,'DE_E_944'),(1054,'DE_E_830'),(1055,'ETHNICITY'),(1056,'LAST_NAME'),(1057,'BIRTH_DATE'),(1058,'IDENTIFIER'),(1059,'VITAL_STATUS'),(1060,'FIRST_NAME'),(1061,'MIDDLE_NAME'),(1062,'GENDER'),(1063,'SOCIAL_SECURITY_NUMBER'),(1064,'ACTIVITY_STATUS'),(1065,'DEATH_DATE'),(1066,'GENOTYPE'),(1067,'CATISSUE_SP_ARRAY_ORDER_ITEM'),(1073,'DE_E_857'),(1075,'DE_AT_865'),(1076,'DE_AT_866'),(1077,'IDENTIFIER'),(1078,'CATISSUE_NEW_SP_AR_ORDER_ITEM'),(1083,'STATUS'),(1084,'IDENTIFIER'),(1085,'DESCRIPTION'),(1086,'NAME'),(1088,'DE_E_770'),(1089,'DE_E_886'),(1090,'DE_E_781'),(1091,'DE_E_812'),(1092,'DE_E_794'),(1093,'DE_E_868'),(1094,'DE_E_868'),(1096,'CATISSUE_EXISTING_SP_ORD_ITEM'),(1097,'DE_E_886'),(1100,'IDENTIFIER'),(1101,'STATUS'),(1102,'DESCRIPTION'),(1103,'DE_E_886'),(1104,'DE_E_886'),(1105,'DE_E_886'),(1106,'DE_E_886'),(1107,'DE_E_886'),(1109,'DE_E_886'),(1113,'CATISSUE_EXTERNAL_IDENTIFIER'),(1114,'DE_E_902'),(1115,'DE_E_902'),(1116,'DE_E_902'),(1117,'DE_E_902'),(1118,'DE_E_902'),(1119,'NAME'),(1120,'VALUE'),(1121,'IDENTIFIER'),(1122,'DE_E_911'),(1123,'DE_E_911'),(1124,'DE_AT_913'),(1125,'DE_AT_914'),(1126,'DE_E_915'),(1127,'DE_E_911'),(1128,'DE_E_921'),(1129,'DE_AT_917'),(1130,'DE_AT_918'),(1131,'DE_AT_919'),(1132,'DE_AT_920'),(1133,'DE_E_921'),(1134,'DE_E_975'),(1135,'DE_E_921'),(1136,'DE_AT_922'),(1137,'DE_AT_923'),(1138,'DE_AT_924'),(1139,'DE_AT_925'),(1140,'CATISSUE_QUARANTINE_PARAMS'),(1141,'DE_E_926'),(1142,'EVENT_TIMESTAMP'),(1143,'COMMENTS'),(1144,'IS_QUARANTINED'),(1145,'IDENTIFIER'),(1146,'CATISSUE_DISTRIBUTION_SPEC_REQ'),(1147,'CATISSUE_DISTRIBUTION_SPE_REQ'),(1153,'TISSUE_SITE'),(1154,'SPECIMEN_TYPE'),(1155,'SPECIMEN_CLASS'),(1156,'IDENTIFIER'),(1157,'PATHOLOGY_STATUS'),(1158,'CATISSUE_PART_MEDICAL_ID'),(1159,'DE_E_944'),(1160,'DE_E_944'),(1161,'MEDICAL_RECORD_NUMBER'),(1162,'IDENTIFIER'),(1163,'CATISSUE_SPECI_ARRAY_CONTENT'),(1164,'DE_E_949'),(1166,'IDENTIFIER'),(1167,'POSITION_DIMENSION_TWO'),(1168,'POSITION_DIMENSION_ONE'),(1169,'CONC_IN_MICROGM_PER_MICROLTR'),(1175,'DE_E_949'),(1179,'CATISSUE_BIOHAZARD'),(1180,'CATISSUE_SPECIMEN_BIOHZ_REL'),(1181,'CATISSUE_SPECIMEN_BIOHZ_REL'),(1182,'CATISSUE_SPECIMEN_BIOHZ_REL'),(1183,'CATISSUE_SPECIMEN_BIOHZ_REL'),(1184,'CATISSUE_SPECIMEN_BIOHZ_REL'),(1185,'COMMENTS'),(1186,'NAME'),(1187,'IDENTIFIER'),(1188,'TYPE'),(1189,'DE_E_975'),(1190,'DE_E_975'),(1191,'DE_AT_977'),(1192,'DE_AT_978'),(1193,'DE_AT_979'),(1194,'DE_AT_980'),(1195,'CATISSUE_SP_ARRAY_ORDER_ITEM'),(1201,'DE_E_981'),(1202,'DE_E_981'),(1204,'DESCRIPTION'),(1205,'STATUS'),(1206,'IDENTIFIER'),(1207,'AVAILABLE_QUANTITY'),(1208,'INITIAL_QUANTITY'),(1209,'AVAILABLE_QUANTITY'),(1211,'AVAILABLE_QUANTITY'),(1213,'AVAILABLE_QUANTITY'),(1215,'AVAILABLE_QUANTITY'),(1217,'DATE_OFFSET'),(1218,'DATE_OFFSET'),(1219,'CP_TYPE'),(1220,'SEQUENCE_NUMBER'),(1221,'STUDY_CALENDAR_EVENT_POINT'),(1222,'collectionProtocolSelfAssociation'),(1223,'collectionProtocolSelfAssociation'),(1224,'IDENTIFIER'),(1225,'IDENTIFIER'),(1226,'IDENTIFIER'),(1227,'IDENTIFIER'),(1228,'IDENTIFIER'),(1229,'IDENTIFIER'),(1230,'IDENTIFIER'),(1231,'IDENTIFIER'),(1232,'IDENTIFIER'),(1233,'IDENTIFIER'),(1234,'IDENTIFIER'),(1235,'IDENTIFIER'),(1236,'IDENTIFIER'),(1237,'IDENTIFIER'),(1238,'IDENTIFIER'),(1239,'IDENTIFIER'),(1240,'IDENTIFIER'),(1241,'IDENTIFIER'),(1242,'DE_E_1227'),(1243,'DE_AT_1229'),(1244,'DE_E_1230'),(1245,'DE_E_1236'),(1246,'DE_AT_1233'),(1247,'DE_AT_1234'),(1248,'DE_AT_1235'),(1249,'DE_E_1236'),(1250,'DE_AT_1238'),(1251,'DE_AT_1239'),(1252,'DE_AT_1240'),(1253,'DE_E_1241'),(1254,'DE_AT_1243'),(1255,'DE_E_1244'),(1256,'DE_AT_1246'),(1257,'DE_AT_1247'),(1258,'DE_AT_1248'),(1259,'DE_E_1249'),(1260,'DE_AT_1251'),(1261,'DE_AT_1252'),(1262,'DE_AT_1253'),(1263,'DE_E_1254'),(1264,'DE_AT_1256'),(1265,'DE_AT_1257'),(1266,'DE_E_1258'),(1267,'DE_E_1258'),(1268,'DE_E_1274'),(1269,'DE_E_1271'),(1270,'DE_AT_1263'),(1271,'DE_E_1264'),(1272,'DE_E_1236'),(1273,'DE_AT_1267'),(1274,'DE_AT_1268'),(1275,'DE_AT_1269'),(1276,'DE_AT_1270'),(1277,'DE_E_1271'),(1279,'DE_E_1274'),(1281,'DE_E_1277'),(1282,'DE_E_1279'),(1283,'DE_AT_1281'),(1284,'DE_AT_1282'),(1285,'DE_E_1283'),(1286,'DE_AT_1285'),(1287,'DE_AT_1286'),(1288,'DE_AT_1287'),(1289,'DE_AT_1288'),(1290,'DE_AT_1289'),(1291,'DE_E_1290'),(1293,'DE_AT_1293'),(1294,'DE_AT_1294'),(1295,'DE_E_1295'),(1296,'DE_E_1297'),(1297,'DE_AT_1299'),(1298,'DE_E_1300'),(1299,'DE_E_1283'),(1300,'DE_E_1290'),(1301,'DE_E_1227'),(1302,'DE_E_1264'),(1303,'DE_E_1271'),(1304,'DE_E_1274'),(1305,'DE_E_1230'),(1306,'DE_E_1297'),(1307,'DE_E_1241'),(1308,'DE_E_1279'),(1309,'DE_E_1254'),(1310,'DE_E_1249'),(1311,'DE_E_1277'),(1312,'DE_E_1295'),(1313,'DE_E_1300'),(1314,'IDENTIFIER'),(1315,'IDENTIFIER'),(1316,'IDENTIFIER'),(1317,'IDENTIFIER'),(1318,'IDENTIFIER'),(1319,'IDENTIFIER'),(1320,'IDENTIFIER'),(1321,'IDENTIFIER'),(1322,'IDENTIFIER'),(1323,'IDENTIFIER'),(1324,'IDENTIFIER'),(1325,'IDENTIFIER'),(1326,'IDENTIFIER'),(1327,'IDENTIFIER'),(1328,'IDENTIFIER'),(1329,'IDENTIFIER'),(1330,'IDENTIFIER'),(1331,'DE_E_1318'),(1332,'DE_E_1322'),(1333,'DE_AT_1321'),(1334,'DE_E_1322'),(1335,'DE_AT_1324'),(1336,'DE_E_1325'),(1338,'DE_E_1344'),(1339,'DE_E_1339'),(1340,'DE_E_1332'),(1341,'DE_AT_1331'),(1342,'DE_E_1332'),(1343,'DE_E_1336'),(1344,'DE_AT_1335'),(1345,'DE_E_1336'),(1346,'DE_AT_1338'),(1347,'DE_E_1339'),(1348,'DE_AT_1341'),(1349,'DE_AT_1342'),(1350,'DE_AT_1343'),(1351,'DE_E_1344'),(1352,'DE_AT_1346'),(1353,'DE_AT_1347'),(1354,'DE_AT_1348'),(1355,'DE_E_1349'),(1356,'DE_AT_1351'),(1357,'DE_AT_1352'),(1358,'DE_AT_1353'),(1359,'DE_AT_1354'),(1360,'DE_AT_1355'),(1361,'DE_AT_1356'),(1362,'DE_E_1357'),(1363,'DE_E_1359'),(1364,'DE_AT_1361'),(1365,'DE_AT_1362'),(1366,'DE_E_1363'),(1367,'DE_E_1365'),(1369,'DE_AT_1368'),(1370,'DE_E_1369'),(1371,'DE_E_1369'),(1372,'DE_AT_1371'),(1373,'DE_AT_1372'),(1374,'DE_AT_1373'),(1375,'DE_AT_1374'),(1376,'DE_E_1375'),(1377,'DE_E_1377'),(1379,'DE_AT_1380'),(1380,'DE_E_1381'),(1381,'DE_E_1381'),(1382,'DE_AT_1383'),(1383,'DE_AT_1384'),(1384,'DE_AT_1385'),(1385,'DE_E_1386'),(1386,'DE_E_1325'),(1387,'DE_E_1359'),(1388,'DE_E_1375'),(1389,'DE_E_1349'),(1390,'DE_E_1363'),(1391,'DE_E_1377'),(1392,'DE_E_1357'),(1393,'DE_E_1386'),(1394,'DE_E_1365'),(1395,'IDENTIFIER'),(1396,'IDENTIFIER'),(1397,'DE_E_1400'),(1398,'DE_E_1400'),(1399,'DE_E_1404'),(1400,'DE_AT_1403'),(1401,'DE_E_1404'),(1402,'DE_AT_1406'),(1403,'IDENTIFIER'),(1404,'DE_E_1408'),(1405,'DE_E_1408'),(1406,'DE_AT_1410'),(1407,'DE_AT_1411'),(1408,'DE_AT_1412'),(1409,'IDENTIFIER'),(1410,'DE_E_1414'),(1411,'DE_E_1414'),(1412,'DE_AT_1416'),(1413,'DE_AT_1417'),(1414,'DE_AT_1418'),(1415,'DE_AT_1419'),(1416,'IDENTIFIER'),(1417,'DE_E_1421'),(1418,'DE_E_1421'),(1419,'DE_AT_1423'),(1420,'DE_AT_1424'),(1421,'DE_AT_1425'),(1422,'IDENTIFIER'),(1423,'IDENTIFIER'),(1424,'IDENTIFIER'),(1425,'DE_E_1427'),(1426,'DE_E_1427'),(1427,'DE_E_1434'),(1428,'DE_E_1432'),(1429,'DE_AT_1431'),(1430,'DE_E_1432'),(1431,'DE_E_1434'),(1432,'IDENTIFIER'),(1433,'IDENTIFIER'),(1434,'IDENTIFIER'),(1435,'IDENTIFIER'),(1436,'IDENTIFIER'),(1437,'IDENTIFIER'),(1438,'IDENTIFIER'),(1439,'IDENTIFIER'),(1440,'IDENTIFIER'),(1441,'IDENTIFIER'),(1442,'IDENTIFIER'),(1443,'IDENTIFIER'),(1444,'IDENTIFIER'),(1445,'IDENTIFIER'),(1446,'IDENTIFIER'),(1447,'IDENTIFIER'),(1448,'IDENTIFIER'),(1449,'IDENTIFIER'),(1450,'IDENTIFIER'),(1451,'IDENTIFIER'),(1452,'IDENTIFIER'),(1453,'IDENTIFIER'),(1454,'IDENTIFIER'),(1455,'IDENTIFIER'),(1456,'IDENTIFIER'),(1457,'IDENTIFIER'),(1458,'IDENTIFIER'),(1459,'IDENTIFIER'),(1460,'IDENTIFIER'),(1461,'IDENTIFIER'),(1462,'IDENTIFIER'),(1463,'IDENTIFIER'),(1464,'IDENTIFIER'),(1465,'IDENTIFIER'),(1466,'IDENTIFIER'),(1467,'IDENTIFIER'),(1468,'IDENTIFIER'),(1469,'IDENTIFIER'),(1470,'IDENTIFIER'),(1471,'IDENTIFIER'),(1472,'IDENTIFIER'),(1473,'IDENTIFIER'),(1474,'IDENTIFIER'),(1475,'IDENTIFIER'),(1476,'IDENTIFIER'),(1477,'IDENTIFIER'),(1478,'IDENTIFIER'),(1479,'IDENTIFIER'),(1480,'IDENTIFIER'),(1481,'IDENTIFIER'),(1482,'IDENTIFIER'),(1483,'IDENTIFIER'),(1484,'IDENTIFIER'),(1485,'IDENTIFIER'),(1486,'IDENTIFIER'),(1487,'IDENTIFIER'),(1488,'IDENTIFIER'),(1489,'IDENTIFIER'),(1490,'IDENTIFIER'),(1491,'IDENTIFIER'),(1492,'IDENTIFIER'),(1493,'IDENTIFIER'),(1494,'IDENTIFIER'),(1495,'IDENTIFIER'),(1496,'IDENTIFIER'),(1497,'IDENTIFIER'),(1498,'IDENTIFIER'),(1499,'IDENTIFIER'),(1500,'IDENTIFIER'),(1501,'IDENTIFIER'),(1502,'IDENTIFIER'),(1503,'IDENTIFIER'),(1504,'IDENTIFIER'),(1505,'IDENTIFIER'),(1506,'IDENTIFIER'),(1507,'IDENTIFIER'),(1508,'IDENTIFIER'),(1509,'IDENTIFIER'),(1510,'IDENTIFIER'),(1511,'DE_E_1437'),(1512,'DE_AT_1439'),(1513,'DE_E_1440'),(1514,'DE_E_1454'),(1515,'DE_E_1447'),(1516,'DE_AT_1444'),(1517,'DE_AT_1445'),(1518,'DE_AT_1446'),(1519,'DE_E_1447'),(1520,'DE_E_1451'),(1521,'DE_AT_1450'),(1522,'DE_E_1451'),(1523,'DE_AT_1453'),(1524,'DE_E_1454'),(1525,'DE_E_1458'),(1526,'DE_AT_1457'),(1527,'DE_E_1458'),(1528,'DE_AT_1460'),(1529,'DE_E_1461'),(1530,'DE_E_1508'),(1531,'DE_E_1484'),(1532,'DE_E_1479'),(1533,'DE_E_1473'),(1534,'DE_E_1468'),(1535,'DE_E_1468'),(1536,'DE_AT_1470'),(1537,'DE_AT_1471'),(1538,'DE_AT_1472'),(1539,'DE_E_1473'),(1540,'DE_AT_1475'),(1541,'DE_AT_1476'),(1542,'DE_AT_1477'),(1543,'DE_AT_1478'),(1544,'DE_E_1479'),(1545,'DE_AT_1481'),(1546,'DE_AT_1482'),(1547,'DE_AT_1483'),(1548,'DE_E_1484'),(1549,'DE_E_1505'),(1550,'DE_E_1497'),(1551,'DE_E_1489'),(1552,'DE_E_1489'),(1553,'DE_AT_1491'),(1554,'DE_AT_1492'),(1555,'DE_AT_1493'),(1556,'DE_AT_1494'),(1557,'DE_AT_1495'),(1558,'DE_AT_1496'),(1559,'DE_E_1497'),(1560,'DE_E_1501'),(1561,'DE_AT_1500'),(1562,'DE_E_1501'),(1563,'DE_AT_1503'),(1564,'DE_AT_1504'),(1565,'DE_E_1505'),(1566,'DE_AT_1507'),(1567,'DE_E_1508'),(1568,'DE_E_1513'),(1569,'DE_AT_1511'),(1570,'DE_AT_1512'),(1571,'DE_E_1513'),(1572,'DE_AT_1515'),(1573,'DE_E_1516'),(1574,'DE_E_1518'),(1575,'DE_E_1527'),(1576,'DE_E_1524'),(1577,'DE_AT_1522'),(1578,'DE_AT_1523'),(1579,'DE_E_1524'),(1580,'DE_AT_1526'),(1581,'DE_E_1527'),(1582,'DE_E_1533'),(1583,'DE_AT_1530'),(1584,'DE_AT_1531'),(1585,'DE_AT_1532'),(1586,'DE_E_1533'),(1587,'DE_AT_1535'),(1588,'DE_E_1536'),(1589,'DE_AT_1538'),(1590,'DE_E_1539'),(1591,'DE_E_1541'),(1592,'DE_AT_1543'),(1593,'DE_AT_1544'),(1594,'DE_E_1545'),(1595,'DE_E_1551'),(1596,'DE_AT_1548'),(1597,'DE_AT_1549'),(1598,'DE_AT_1550'),(1599,'DE_E_1551'),(1600,'DE_AT_1553'),(1601,'DE_AT_1554'),(1602,'DE_AT_1555'),(1603,'DE_E_1556'),(1604,'DE_AT_1558'),(1605,'DE_E_1559'),(1606,'DE_AT_1561'),(1607,'DE_E_1562'),(1608,'DE_AT_1564'),(1609,'DE_AT_1565'),(1610,'DE_E_1566'),(1611,'DE_E_1570'),(1612,'DE_AT_1569'),(1613,'DE_E_1570'),(1614,'DE_AT_1572'),(1615,'DE_AT_1573'),(1616,'DE_E_1574'),(1617,'DE_AT_1576'),(1618,'DE_E_1577'),(1619,'DE_E_1589'),(1620,'DE_E_1584'),(1621,'DE_AT_1581'),(1622,'DE_AT_1582'),(1623,'DE_AT_1583'),(1624,'DE_E_1584'),(1626,'DE_AT_1586'),(1627,'DE_AT_1587'),(1628,'DE_AT_1588'),(1629,'DE_E_1589'),(1630,'DE_AT_1591'),(1631,'DE_AT_1592'),(1632,'DE_E_1593'),(1634,'DE_AT_1596'),(1635,'DE_AT_1597'),(1636,'DE_AT_1598'),(1637,'DE_AT_1599'),(1638,'DE_E_1600'),(1639,'DE_E_1556'),(1640,'DE_AT_1603'),(1641,'DE_AT_1604'),(1642,'DE_E_1605'),(1643,'DE_AT_1607'),(1644,'DE_E_1608'),(1645,'DE_E_1612'),(1646,'DE_AT_1611'),(1647,'DE_E_1612'),(1648,'DE_AT_1614'),(1649,'DE_E_1615'),(1650,'DE_E_1562'),(1651,'DE_E_1620'),(1652,'DE_AT_1619'),(1653,'DE_E_1620'),(1654,'DE_E_1437'),(1655,'DE_AT_1623'),(1656,'DE_AT_1624'),(1657,'DE_E_1625'),(1658,'DE_AT_1627'),(1659,'DE_AT_1628'),(1660,'DE_AT_1629'),(1661,'DE_AT_1630'),(1662,'DE_E_1631'),(1663,'DE_E_1608'),(1664,'DE_E_1648'),(1666,'DE_E_1644'),(1668,'DE_AT_1638'),(1669,'DE_AT_1639'),(1670,'DE_E_1640'),(1671,'DE_AT_1642'),(1672,'DE_AT_1643'),(1673,'DE_E_1644'),(1674,'DE_AT_1646'),(1675,'DE_AT_1647'),(1676,'DE_E_1648'),(1677,'DE_E_1612'),(1678,'DE_AT_1651'),(1679,'DE_E_1652'),(1680,'DE_AT_1654'),(1681,'DE_AT_1655'),(1682,'DE_AT_1656'),(1683,'DE_AT_1657'),(1684,'DE_AT_1658'),(1685,'DE_E_1659'),(1686,'DE_AT_1661'),(1687,'DE_AT_1662'),(1688,'DE_E_1663'),(1689,'DE_AT_1665'),(1690,'DE_AT_1666'),(1691,'DE_E_1667'),(1692,'DE_E_1673'),(1693,'DE_E_1659'),(1694,'DE_AT_1671'),(1695,'DE_AT_1672'),(1696,'DE_E_1673'),(1697,'DE_AT_1675'),(1698,'DE_E_1676'),(1699,'DE_E_1685'),(1700,'DE_E_1680'),(1701,'DE_E_1680'),(1702,'DE_E_1663'),(1703,'DE_AT_1683'),(1704,'DE_AT_1684'),(1705,'DE_E_1685'),(1707,'DE_E_1690'),(1708,'DE_AT_1688'),(1709,'DE_AT_1689'),(1710,'DE_E_1690'),(1711,'DE_AT_1692'),(1712,'DE_E_1693'),(1713,'DE_E_1697'),(1714,'DE_AT_1696'),(1715,'DE_E_1697'),(1716,'DE_AT_1699'),(1717,'DE_AT_1700'),(1718,'DE_E_1701'),(1719,'DE_AT_1703'),(1720,'DE_AT_1704'),(1721,'DE_E_1705'),(1722,'DE_E_1615'),(1723,'DE_E_1701'),(1724,'DE_E_1709'),(1725,'DE_AT_1711'),(1726,'DE_AT_1712'),(1727,'DE_AT_1713'),(1728,'DE_AT_1714'),(1729,'DE_E_1715'),(1730,'DE_E_1731'),(1731,'DE_E_1693'),(1732,'DE_E_1727'),(1733,'DE_E_1723'),(1734,'DE_AT_1721'),(1735,'DE_AT_1722'),(1736,'DE_E_1723'),(1737,'DE_E_1697'),(1738,'DE_AT_1726'),(1739,'DE_E_1727'),(1740,'DE_E_1697'),(1741,'DE_AT_1730'),(1742,'DE_E_1731'),(1743,'DE_E_1697'),(1744,'DE_AT_1734'),(1745,'DE_E_1735'),(1746,'DE_AT_1736'),(1747,'DE_AT_1737'),(1748,'DE_AT_1738'),(1749,'DE_AT_1739'),(1750,'DE_AT_1740'),(1751,'DE_AT_1741'),(1752,'DE_AT_1742'),(1753,'DE_AT_1743'),(1754,'DE_AT_1744'),(1755,'DE_E_1749'),(1756,'DE_E_1605'),(1757,'DE_E_1600'),(1758,'DE_E_1749'),(1759,'DE_E_1556'),(1760,'DE_AT_1752'),(1761,'DE_AT_1753'),(1762,'DE_E_1754'),(1763,'DE_E_1762'),(1765,'DE_E_1667'),(1766,'DE_E_1709'),(1767,'DE_AT_1760'),(1768,'DE_AT_1761'),(1769,'DE_E_1762'),(1770,'DE_AT_1764'),(1771,'DE_E_1765'),(1772,'DE_E_1770'),(1773,'DE_AT_1768'),(1774,'DE_AT_1769'),(1775,'DE_E_1770'),(1776,'DE_AT_1772'),(1777,'DE_E_1773'),(1779,'DE_E_1777'),(1780,'DE_E_1777'),(1781,'DE_E_1781'),(1782,'DE_AT_1780'),(1783,'DE_E_1781'),(1784,'DE_AT_1783'),(1785,'DE_E_1784'),(1786,'DE_E_1770'),(1787,'DE_AT_1787'),(1788,'DE_E_1788'),(1789,'DE_E_1541'),(1790,'DE_E_1784'),(1791,'DE_E_1640'),(1792,'DE_E_1765'),(1793,'DE_E_1794'),(1794,'DE_AT_1796'),(1795,'DE_E_1797'),(1796,'DE_E_1566'),(1797,'DE_E_1574'),(1798,'DE_AT_1801'),(1799,'DE_AT_1802'),(1800,'DE_E_1440'),(1801,'DE_E_1577'),(1802,'DE_E_1461'),(1803,'DE_E_1545'),(1804,'DE_E_1676'),(1805,'DE_E_1652'),(1806,'DE_E_1794'),(1807,'DE_E_1625'),(1808,'DE_E_1705'),(1809,'DE_E_1516'),(1810,'DE_E_1559'),(1811,'DE_E_1518'),(1812,'DE_E_1536'),(1813,'DE_E_1539'),(1814,'DE_E_1797'),(1815,'DE_E_1735'),(1816,'DE_E_1773'),(1817,'DE_E_1754'),(1818,'DE_E_1593'),(1819,'DE_E_1788'),(1820,'DE_E_1631'),(1821,'DE_E_1715'),(1822,'IDENTIFIER'),(1823,'DE_E_1828'),(1824,'DE_E_1828'),(1825,'DE_AT_1830'),(1826,'DE_AT_1831'),(1827,'DE_AT_1832'),(1828,'DE_AT_1833'),(1829,'IDENTIFIER'),(1830,'IDENTIFIER'),(1831,'DE_E_1838'),(1832,'DE_E_1836'),(1833,'DE_E_1836'),(1834,'DE_E_1838'),(1835,'IDENTIFIER'),(1836,'DE_E_1841'),(1837,'DE_E_1841'),(1838,'IDENTIFIER'),(1839,'IDENTIFIER'),(1840,'DE_E_1847'),(1841,'DE_E_1845'),(1842,'DE_E_1845'),(1843,'DE_E_1847'),(1844,'SPECIMEN_ID'),(1845,'BIOHAZARD_ID'),(1846,'SPECIMEN_ID'),(1847,'SPECIMEN_ID'),(1848,'SPECIMEN_ID'),(1849,'SPECIMEN_ID'),(1850,'SPECIMEN_ID'),(1851,'SPECIMEN_ID'),(1852,'SPECIMEN_ID'),(1853,'SPECIMEN_ID'),(1854,'SPECIMEN_ID'),(1855,'SPECIMEN_ID'),(1856,'SPECIMEN_ID'),(1857,'PARENT_SPECIMEN_ID'),(1858,'PARENT_SPECIMEN_ID'),(1859,'PARENT_SPECIMEN_ID'),(1860,'PARENT_SPECIMEN_ID'),(1861,'PARENT_SPECIMEN_ID'),(1862,'SPECIMEN_ID'),(1863,'SPECIMEN_ID'),(1864,'SPECIMEN_ID'),(1865,'SPECIMEN_ID'),(1866,'SPECIMEN_ID'),(1867,'SPECIMEN_ID'),(1868,'SPECIMEN_ID'),(1869,'SPECIMEN_ID'),(1870,'SPECIMEN_ID'),(1871,'SPECIMEN_COLLECTION_GROUP_ID'),(1872,'SPECIMEN_COLLECTION_GROUP_ID'),(1873,'SPECIMEN_COLLECTION_GROUP_ID'),(1874,'SPECIMEN_ID'),(1875,'PARENT_SPECIMEN_ID'),(1876,'PARENT_SPECIMEN_ID'),(1877,'PARENT_SPECIMEN_ID'),(1878,'PARENT_SPECIMEN_ID'),(1879,'PARENT_SPECIMEN_ID'),(1880,'SPECIMEN_CHARACTERISTICS_ID'),(1881,'AVAILABLE_QUANTITY'),(1882,'AVAILABLE_QUANTITY'),(1883,'AVAILABLE_QUANTITY'),(1884,'AVAILABLE_QUANTITY'),(1885,'AVAILABLE_QUANTITY'),(1886,'QUANTITY'),(1887,'QUANTITY'),(1888,'QUANTITY'),(1889,'QUANTITY'),(1890,'QUANTITY'),(1891,'STORAGE_CONTAINER_IDENTIFIER'),(1892,'PARENT_CONTAINER_ID'),(1893,'PARENT_CONTAINER_ID'),(1894,'PARENT_CONTAINER_ID'),(1895,'CAPACITY_ID'),(1896,'PARENT_CONTAINER_ID'),(1897,'PARENT_CONTAINER_ID'),(1898,'PARENT_CONTAINER_ID'),(1899,'SPECIMEN_ARRAY_ID'),(1900,'DE_E_53_43_IDENTIFIER'),(1901,'DE_E_53_68_IDENTIFIER'),(1902,'DE_E_53_88_IDENTIFIER'),(1903,'CAPACITY_ID'),(1904,'STORAGE_CONTAINER_ID'),(1905,'CREATED_BY_ID'),(1906,'SPECIMEN_ARRAY_TYPE_ID'),(1907,'PARENT_CONTAINER_ID'),(1908,'PARENT_CONTAINER_ID'),(1909,'PARENT_CONTAINER_ID'),(1910,'DE_E_70_null_IDENTIFIER'),(1911,'DE_E_70_null_IDENTIFIER'),(1912,'DE_E_70_null_IDENTIFIER'),(1913,'CAPACITY_ID'),(1914,'STORAGE_CONTAINER_ID'),(1915,'SPECIMEN_ARRAY_TYPE_ID'),(1916,'STORAGE_CONTAINER_ID'),(1917,'STORAGE_TYPE_ID'),(1918,'STORAGE_CONTAINER_ID'),(1919,'COLLECTION_PROTOCOL_ID'),(1920,'PARENT_CONTAINER_ID'),(1921,'STORAGE_TYPE_ID'),(1922,'SITE_ID'),(1923,'PARENT_CONTAINER_ID'),(1924,'PARENT_CONTAINER_ID'),(1925,'ADDRESS_ID'),(1926,'USER_ID'),(1927,'USER_ID'),(1928,'COLLECTION_PROTOCOL_ID'),(1929,'DEPARTMENT_ID'),(1930,'CANCER_RESEARCH_GROUP_ID'),(1931,'INSTITUTION_ID'),(1932,'ADDRESS_ID'),(1933,'USER_ID'),(1934,'CAPACITY_ID'),(1935,'STORAGE_TYPE_ID'),(1936,'SPECIMEN_ARRAY_TYPE_ID'),(1937,'CAPACITY_ID'),(1938,'HOLDS_STORAGE_TYPE_ID'),(1939,'STORAGE_TYPE_ID'),(1940,'CAPACITY_ID'),(1941,'PRINCIPAL_INVESTIGATOR_ID'),(1942,'COLLECTION_PROTOCOL_ID'),(1943,'COLLECTION_PROTOCOL_ID'),(1944,'COLL_PROTOCOL_ID'),(1945,'PRINCIPAL_INVESTIGATOR_ID'),(1946,'COLLECTION_PROTOCOL_ID'),(1947,'USER_ID'),(1948,'COLLECTION_PROTOCOL_ID'),(1949,'DISTRIBUTION_PROTOCOL_ID'),(1950,'DISTRIBUTION_PROTOCOL_ID'),(1951,'SPECIMEN_REQUIREMENT_ID'),(1952,'DISTRIBUTION_PROTOCOL_ID'),(1953,'COLLECTION_PROTOCOL_ID'),(1954,'PRINCIPAL_INVESTIGATOR_ID'),(1955,'DE_E_T_224_969_IDENTIFIER'),(1956,'DE_E_S_965_969_IDENTIFIER'),(1957,'DE_E_224_906_IDENTIFIER'),(1958,'PARENT_SPECIMEN_ID'),(1959,'DE_E_224_null_IDENTIFIER'),(1960,'DE_E_224_null_IDENTIFIER'),(1961,'DE_E_224_null_IDENTIFIER'),(1962,'DE_E_224_null_IDENTIFIER'),(1963,'DE_E_224_null_IDENTIFIER'),(1964,'DE_E_224_null_IDENTIFIER'),(1965,'DE_E_224_null_IDENTIFIER'),(1966,'DE_E_224_null_IDENTIFIER'),(1967,'DE_E_224_null_IDENTIFIER'),(1968,'DE_E_224_null_IDENTIFIER'),(1969,'PARENT_SPECIMEN_ID'),(1970,'PARENT_SPECIMEN_ID'),(1971,'PARENT_SPECIMEN_ID'),(1972,'PARENT_SPECIMEN_ID'),(1973,'DE_E_224_null_IDENTIFIER'),(1974,'DE_E_224_null_IDENTIFIER'),(1975,'DE_E_224_null_IDENTIFIER'),(1976,'DE_E_224_null_IDENTIFIER'),(1977,'DE_E_224_null_IDENTIFIER'),(1978,'DE_E_224_null_IDENTIFIER'),(1979,'DE_E_224_null_IDENTIFIER'),(1980,'DE_E_224_null_IDENTIFIER'),(1981,'DE_E_224_null_IDENTIFIER'),(1982,'SPECIMEN_COLLECTION_GROUP_ID'),(1983,'SPECIMEN_COLLECTION_GROUP_ID'),(1984,'SPECIMEN_COLLECTION_GROUP_ID'),(1985,'DE_E_224_228_IDENTIFIER'),(1986,'DE_E_224_229_IDENTIFIER'),(1987,'DE_E_224_230_IDENTIFIER'),(1988,'DE_E_224_231_IDENTIFIER'),(1989,'DE_E_224_232_IDENTIFIER'),(1990,'DE_E_224_233_IDENTIFIER'),(1991,'SPECIMEN_CHARACTERISTICS_ID'),(1992,'STORAGE_CONTAINER_IDENTIFIER'),(1993,'AVAILABLE_QUANTITY'),(1994,'AVAILABLE_QUANTITY'),(1995,'AVAILABLE_QUANTITY'),(1996,'AVAILABLE_QUANTITY'),(1997,'AVAILABLE_QUANTITY'),(1998,'QUANTITY'),(1999,'QUANTITY'),(2000,'QUANTITY'),(2001,'QUANTITY'),(2002,'QUANTITY'),(2003,'DE_E_T_261_968_IDENTIFIER'),(2004,'DE_E_S_965_968_IDENTIFIER'),(2005,'DE_E_261_905_IDENTIFIER'),(2006,'PARENT_SPECIMEN_ID'),(2007,'PARENT_SPECIMEN_ID'),(2008,'DE_E_261_631_IDENTIFIER'),(2009,'DE_E_261_621_IDENTIFIER'),(2010,'DE_E_261_610_IDENTIFIER'),(2011,'DE_E_261_598_IDENTIFIER'),(2012,'DE_E_261_587_IDENTIFIER'),(2013,'DE_E_261_576_IDENTIFIER'),(2014,'DE_E_261_565_IDENTIFIER'),(2015,'DE_E_261_553_IDENTIFIER'),(2016,'PARENT_SPECIMEN_ID'),(2017,'PARENT_SPECIMEN_ID'),(2018,'PARENT_SPECIMEN_ID'),(2019,'DE_E_261_418_IDENTIFIER'),(2020,'DE_E_261_428_IDENTIFIER'),(2021,'DE_E_261_440_IDENTIFIER'),(2022,'DE_E_261_451_IDENTIFIER'),(2023,'DE_E_261_461_IDENTIFIER'),(2024,'DE_E_261_485_IDENTIFIER'),(2025,'DE_E_261_489_IDENTIFIER'),(2026,'DE_E_261_500_IDENTIFIER'),(2027,'DE_E_261_511_IDENTIFIER'),(2028,'DE_E_261_521_IDENTIFIER'),(2029,'DE_E_261_548_IDENTIFIER'),(2030,'SPECIMEN_COLLECTION_GROUP_ID'),(2031,'SPECIMEN_COLLECTION_GROUP_ID'),(2032,'SPECIMEN_COLLECTION_GROUP_ID'),(2033,'DE_E_261_265_IDENTIFIER'),(2034,'DE_E_261_266_IDENTIFIER'),(2035,'DE_E_261_267_IDENTIFIER'),(2036,'DE_E_261_268_IDENTIFIER'),(2037,'DE_E_261_269_IDENTIFIER'),(2038,'DE_E_261_270_IDENTIFIER'),(2039,'SPECIMEN_CHARACTERISTICS_ID'),(2040,'AVAILABLE_QUANTITY'),(2041,'AVAILABLE_QUANTITY'),(2042,'AVAILABLE_QUANTITY'),(2043,'AVAILABLE_QUANTITY'),(2044,'AVAILABLE_QUANTITY'),(2045,'QUANTITY'),(2046,'QUANTITY'),(2047,'QUANTITY'),(2048,'QUANTITY'),(2049,'QUANTITY'),(2050,'STORAGE_CONTAINER_IDENTIFIER'),(2051,'DE_E_T_297_967_IDENTIFIER'),(2052,'DE_E_S_965_967_IDENTIFIER'),(2053,'DE_E_297_904_IDENTIFIER'),(2054,'PARENT_SPECIMEN_ID'),(2055,'PARENT_SPECIMEN_ID'),(2056,'PARENT_SPECIMEN_ID'),(2057,'DE_E_297_630_IDENTIFIER'),(2058,'DE_E_297_620_IDENTIFIER'),(2059,'DE_E_297_609_IDENTIFIER'),(2060,'DE_E_297_597_IDENTIFIER'),(2061,'DE_E_297_586_IDENTIFIER'),(2062,'DE_E_297_575_IDENTIFIER'),(2063,'DE_E_297_564_IDENTIFIER'),(2064,'PARENT_SPECIMEN_ID'),(2065,'PARENT_SPECIMEN_ID'),(2066,'DE_E_297_417_IDENTIFIER'),(2067,'DE_E_297_427_IDENTIFIER'),(2068,'DE_E_297_439_IDENTIFIER'),(2069,'DE_E_297_450_IDENTIFIER'),(2070,'DE_E_297_460_IDENTIFIER'),(2071,'DE_E_297_472_IDENTIFIER'),(2072,'DE_E_297_488_IDENTIFIER'),(2073,'DE_E_297_499_IDENTIFIER'),(2074,'DE_E_297_510_IDENTIFIER'),(2075,'DE_E_297_520_IDENTIFIER'),(2076,'DE_E_297_549_IDENTIFIER'),(2077,'DE_E_297_552_IDENTIFIER'),(2078,'SPECIMEN_COLLECTION_GROUP_ID'),(2079,'SPECIMEN_COLLECTION_GROUP_ID'),(2080,'SPECIMEN_COLLECTION_GROUP_ID'),(2081,'DE_E_297_301_IDENTIFIER'),(2082,'DE_E_297_302_IDENTIFIER'),(2083,'DE_E_297_303_IDENTIFIER'),(2084,'DE_E_297_304_IDENTIFIER'),(2085,'DE_E_297_305_IDENTIFIER'),(2086,'DE_E_297_306_IDENTIFIER'),(2087,'SPECIMEN_CHARACTERISTICS_ID'),(2088,'AVAILABLE_QUANTITY'),(2089,'AVAILABLE_QUANTITY'),(2090,'AVAILABLE_QUANTITY'),(2091,'AVAILABLE_QUANTITY'),(2092,'AVAILABLE_QUANTITY'),(2093,'QUANTITY'),(2094,'QUANTITY'),(2095,'QUANTITY'),(2096,'QUANTITY'),(2097,'QUANTITY'),(2098,'STORAGE_CONTAINER_IDENTIFIER'),(2099,'DE_E_T_333_966_IDENTIFIER'),(2100,'DE_E_S_965_966_IDENTIFIER'),(2101,'DE_E_333_903_IDENTIFIER'),(2102,'PARENT_SPECIMEN_ID'),(2103,'PARENT_SPECIMEN_ID'),(2104,'PARENT_SPECIMEN_ID'),(2105,'PARENT_SPECIMEN_ID'),(2106,'DE_E_333_629_IDENTIFIER'),(2107,'DE_E_333_619_IDENTIFIER'),(2108,'DE_E_333_608_IDENTIFIER'),(2109,'DE_E_333_596_IDENTIFIER'),(2110,'DE_E_333_585_IDENTIFIER'),(2111,'DE_E_333_574_IDENTIFIER'),(2112,'PARENT_SPECIMEN_ID'),(2113,'DE_E_333_416_IDENTIFIER'),(2114,'DE_E_333_426_IDENTIFIER'),(2115,'DE_E_333_438_IDENTIFIER'),(2116,'DE_E_333_449_IDENTIFIER'),(2117,'DE_E_333_459_IDENTIFIER'),(2118,'DE_E_333_471_IDENTIFIER'),(2119,'DE_E_333_487_IDENTIFIER'),(2120,'DE_E_333_498_IDENTIFIER'),(2121,'DE_E_333_509_IDENTIFIER'),(2122,'DE_E_333_519_IDENTIFIER'),(2123,'DE_E_333_536_IDENTIFIER'),(2124,'DE_E_333_551_IDENTIFIER'),(2125,'DE_E_333_563_IDENTIFIER'),(2126,'SPECIMEN_COLLECTION_GROUP_ID'),(2127,'SPECIMEN_COLLECTION_GROUP_ID'),(2128,'SPECIMEN_COLLECTION_GROUP_ID'),(2129,'DE_E_333_337_IDENTIFIER'),(2130,'DE_E_333_338_IDENTIFIER'),(2131,'DE_E_333_339_IDENTIFIER'),(2132,'DE_E_333_340_IDENTIFIER'),(2133,'DE_E_333_341_IDENTIFIER'),(2134,'DE_E_333_342_IDENTIFIER'),(2135,'SPECIMEN_CHARACTERISTICS_ID'),(2136,'AVAILABLE_QUANTITY'),(2137,'AVAILABLE_QUANTITY'),(2138,'AVAILABLE_QUANTITY'),(2139,'AVAILABLE_QUANTITY'),(2140,'AVAILABLE_QUANTITY'),(2141,'QUANTITY'),(2142,'QUANTITY'),(2143,'QUANTITY'),(2144,'QUANTITY'),(2145,'QUANTITY'),(2146,'STORAGE_CONTAINER_IDENTIFIER'),(2147,'CONSENT_TIER_ID'),(2148,'SPECIMEN_COLLECTION_GROUP_ID'),(2149,'SPECIMEN_COLLECTION_GROUP_ID'),(2150,'SPECIMEN_COLLECTION_GROUP_ID'),(2151,'SPECIMEN_COLLECTION_GROUP_ID'),(2152,'SPECIMEN_COLLECTION_GROUP_ID'),(2153,'SITE_ID'),(2154,'COLLECTION_PROTOCOL_REG_ID'),(2155,'DE_E_379_6_IDENTIFIER'),(2156,'DE_E_379_226_IDENTIFIER'),(2157,'DE_E_379_263_IDENTIFIER'),(2158,'DE_E_379_299_IDENTIFIER'),(2159,'DE_E_379_335_IDENTIFIER'),(2160,'SCG_ID'),(2161,'SITE_ID'),(2162,'COLLECTION_PROTOCOL_EVENT_ID'),(2163,'SCG_ID'),(2164,'SPECIMEN_COLL_GROUP_ID'),(2165,'SPECIMEN_COLL_GRP_ID'),(2166,'IDENTIFIER'),(2167,'SPECIMEN_COLL_GRP_ID'),(2168,'IDENTIFIER'),(2169,'SPECIMEN_COLL_GRP_ID'),(2170,'IDENTIFIER'),(2171,'SPECIMEN_COLL_GRP_ID'),(2172,'IDENTIFIER'),(2173,'SPECIMEN_COLL_GRP_ID'),(2174,'IDENTIFIER'),(2175,'SPECIMEN_COLL_GRP_ID'),(2176,'IDENTIFIER'),(2177,'SPECIMEN_COLL_GRP_ID'),(2178,'IDENTIFIER'),(2179,'SPECIMEN_COLL_GRP_ID'),(2180,'IDENTIFIER'),(2181,'SPECIMEN_COLL_GRP_ID'),(2182,'IDENTIFIER'),(2183,'SPECIMEN_COLL_GRP_ID'),(2184,'IDENTIFIER'),(2185,'SPECIMEN_COLL_GRP_ID'),(2186,'IDENTIFIER'),(2187,'SPECIMEN_COLL_GRP_ID'),(2188,'IDENTIFIER'),(2189,'SPECIMEN_COLL_GRP_ID'),(2190,'IDENTIFIER'),(2191,'SPECIMEN_COLL_GRP_ID'),(2192,'IDENTIFIER'),(2193,'SPECIMEN_COLL_GRP_ID'),(2194,'IDENTIFIER'),(2195,'SPECIMEN_COLL_GRP_ID'),(2196,'IDENTIFIER'),(2197,'SPECIMEN_COLL_GRP_ID'),(2198,'IDENTIFIER'),(2199,'SPECIMEN_COLL_GRP_ID'),(2200,'IDENTIFIER'),(2201,'SPECIMEN_COLL_GRP_ID'),(2202,'IDENTIFIER'),(2203,'DE_E_T_415_390_IDENTIFIER'),(2204,'DE_E_S_379_390_IDENTIFIER'),(2205,'SPECIMEN_ID'),(2206,'SPECIMEN_ID'),(2207,'SPECIMEN_ID'),(2208,'SPECIMEN_ID'),(2209,'SPECIMEN_ID'),(2210,'USER_ID'),(2211,'DE_E_T_425_410_IDENTIFIER'),(2212,'DE_E_S_379_410_IDENTIFIER'),(2213,'SPECIMEN_ID'),(2214,'SPECIMEN_ID'),(2215,'SPECIMEN_ID'),(2216,'SPECIMEN_ID'),(2217,'SPECIMEN_ID'),(2218,'USER_ID'),(2219,'DE_E_T_437_409_IDENTIFIER'),(2220,'DE_E_S_379_409_IDENTIFIER'),(2221,'SPECIMEN_ID'),(2222,'SPECIMEN_ID'),(2223,'SPECIMEN_ID'),(2224,'SPECIMEN_ID'),(2225,'SPECIMEN_ID'),(2226,'USER_ID'),(2227,'DE_E_T_448_408_IDENTIFIER'),(2228,'DE_E_S_379_408_IDENTIFIER'),(2229,'SPECIMEN_ID'),(2230,'SPECIMEN_ID'),(2231,'SPECIMEN_ID'),(2232,'SPECIMEN_ID'),(2233,'SPECIMEN_ID'),(2234,'USER_ID'),(2235,'DE_E_T_458_407_IDENTIFIER'),(2236,'DE_E_S_379_407_IDENTIFIER'),(2237,'SPECIMEN_ID'),(2238,'SPECIMEN_ID'),(2239,'SPECIMEN_ID'),(2240,'SPECIMEN_ID'),(2241,'SPECIMEN_ID'),(2242,'USER_ID'),(2243,'DE_E_T_470_406_IDENTIFIER'),(2244,'DE_E_S_379_406_IDENTIFIER'),(2245,'SPECIMEN_ID'),(2246,'SPECIMEN_ID'),(2247,'FROM_STORAGE_CONTAINER_ID'),(2248,'TO_STORAGE_CONTAINER_ID'),(2249,'USER_ID'),(2250,'SPECIMEN_ID'),(2251,'SPECIMEN_ID'),(2252,'SPECIMEN_ID'),(2253,'DE_E_T_486_405_IDENTIFIER'),(2254,'DE_E_S_379_405_IDENTIFIER'),(2255,'SPECIMEN_ID'),(2256,'SPECIMEN_ID'),(2257,'SPECIMEN_ID'),(2258,'SPECIMEN_ID'),(2259,'SPECIMEN_ID'),(2260,'USER_ID'),(2261,'DE_E_T_497_404_IDENTIFIER'),(2262,'DE_E_S_379_404_IDENTIFIER'),(2263,'SPECIMEN_ID'),(2264,'SPECIMEN_ID'),(2265,'SPECIMEN_ID'),(2266,'SPECIMEN_ID'),(2267,'SPECIMEN_ID'),(2268,'USER_ID'),(2269,'DE_E_T_508_399_IDENTIFIER'),(2270,'DE_E_S_379_399_IDENTIFIER'),(2271,'SPECIMEN_ID'),(2272,'SPECIMEN_ID'),(2273,'SPECIMEN_ID'),(2274,'SPECIMEN_ID'),(2275,'SPECIMEN_ID'),(2276,'USER_ID'),(2277,'DE_E_T_518_403_IDENTIFIER'),(2278,'DE_E_S_379_403_IDENTIFIER'),(2279,'SPECIMEN_ID'),(2280,'SPECIMEN_ID'),(2281,'SPECIMEN_ID'),(2282,'USER_ID'),(2283,'SPECIMEN_ID'),(2284,'SPECIMEN_ID'),(2285,'DE_E_T_535_402_IDENTIFIER'),(2286,'DE_E_S_379_402_IDENTIFIER'),(2287,'SPECIMEN_ID'),(2288,'USER_ID'),(2289,'SPECIMEN_ID'),(2290,'SPECIMEN_ID'),(2291,'SPECIMEN_ID'),(2292,'SPECIMEN_ID'),(2293,'DE_E_T_550_401_IDENTIFIER'),(2294,'DE_E_S_379_401_IDENTIFIER'),(2295,'SPECIMEN_ID'),(2296,'SPECIMEN_ID'),(2297,'SPECIMEN_ID'),(2298,'SPECIMEN_ID'),(2299,'SPECIMEN_ID'),(2300,'USER_ID'),(2301,'DE_E_T_562_400_IDENTIFIER'),(2302,'DE_E_S_379_400_IDENTIFIER'),(2303,'SPECIMEN_ID'),(2304,'SPECIMEN_ID'),(2305,'SPECIMEN_ID'),(2306,'SPECIMEN_ID'),(2307,'SPECIMEN_ID'),(2308,'USER_ID'),(2309,'DE_E_T_573_389_IDENTIFIER'),(2310,'DE_E_S_379_389_IDENTIFIER'),(2311,'SPECIMEN_ID'),(2312,'SPECIMEN_ID'),(2313,'SPECIMEN_ID'),(2314,'SPECIMEN_ID'),(2315,'SPECIMEN_ID'),(2316,'USER_ID'),(2317,'DE_E_T_584_388_IDENTIFIER'),(2318,'DE_E_S_379_388_IDENTIFIER'),(2319,'DE_E_333_585_IDENTIFIER'),(2320,'DE_E_297_586_IDENTIFIER'),(2321,'DE_E_261_587_IDENTIFIER'),(2322,'DE_E_224_588_IDENTIFIER'),(2323,'DE_E_4_589_IDENTIFIER'),(2324,'DE_E_97_590_IDENTIFIER'),(2325,'DE_E_T_595_387_IDENTIFIER'),(2326,'DE_E_S_379_387_IDENTIFIER'),(2327,'SPECIMEN_ID'),(2328,'SPECIMEN_ID'),(2329,'SPECIMEN_ID'),(2330,'SPECIMEN_ID'),(2331,'SPECIMEN_ID'),(2332,'USER_ID'),(2333,'DE_E_T_607_386_IDENTIFIER'),(2334,'DE_E_S_379_386_IDENTIFIER'),(2335,'SPECIMEN_ID'),(2336,'SPECIMEN_ID'),(2337,'SPECIMEN_ID'),(2338,'SPECIMEN_ID'),(2339,'SPECIMEN_ID'),(2340,'USER_ID'),(2341,'DE_E_T_618_385_IDENTIFIER'),(2342,'DE_E_S_379_385_IDENTIFIER'),(2343,'DE_E_333_619_IDENTIFIER'),(2344,'DE_E_297_620_IDENTIFIER'),(2345,'DE_E_261_621_IDENTIFIER'),(2346,'DE_E_224_622_IDENTIFIER'),(2347,'DE_E_4_623_IDENTIFIER'),(2348,'DE_E_97_624_IDENTIFIER'),(2349,'DE_E_T_628_384_IDENTIFIER'),(2350,'DE_E_S_379_384_IDENTIFIER'),(2351,'SPECIMEN_ID'),(2352,'SPECIMEN_ID'),(2353,'SPECIMEN_ID'),(2354,'SPECIMEN_ID'),(2355,'SPECIMEN_ID'),(2356,'USER_ID'),(2357,'REPORT_ID'),(2358,'REPORT_ID'),(2359,'REPORT_ID'),(2360,'REPORT_ID'),(2361,'SOURCE_ID'),(2362,'REPORT_ID'),(2363,'REPORT_ID'),(2364,'REPORT_ID'),(2365,'TEXT_CONTENT_ID'),(2366,'TEXT_CONTENT_ID'),(2367,'REPORT_ID'),(2368,'REPORT_ID'),(2369,'REPORT_ID'),(2370,'SCG_ID'),(2371,'REPORT_ID'),(2372,'DE_E_674_676_IDENTIFIER'),(2373,'REPORT_ID'),(2374,'REPORT_ID'),(2375,'DEID_REPORT'),(2376,'SOURCE_ID'),(2377,'DEID_REPORT_ID'),(2378,'DEIDENTIFIED_REPORT_ID'),(2379,'DE_E_671_687_IDENTIFIER'),(2380,'DE_E_685_688_IDENTIFIER'),(2381,'DE_E_663_689_IDENTIFIER'),(2382,'SCG_ID'),(2383,'REPORT_ID'),(2384,'SOURCE_ID'),(2385,'DEIDENTIFIED_REPORT_ID'),(2386,'CONCEPT_ID'),(2387,'CONCEPT_CLASSIFICATION_ID'),(2388,'CONCEPT_CLASSIFICATION_ID'),(2389,'CONCEPT_ID'),(2390,'SEMANTIC_TYPE_ID'),(2391,'SPECIMEN_COLL_REQ_GROUP_ID'),(2392,'COLLECTION_PROTOCOL_EVENT_ID'),(2393,'COLLECTION_PROTOCOL_ID'),(2394,'DE_E_722_5_IDENTIFIER'),(2395,'DE_E_722_225_IDENTIFIER'),(2396,'DE_E_722_262_IDENTIFIER'),(2397,'DE_E_722_298_IDENTIFIER'),(2398,'DE_E_722_334_IDENTIFIER'),(2399,'SITE_ID'),(2400,'SPECIMEN_COLL_REQ_GROUP_ID'),(2401,'REQUESTED_QUANTITY'),(2402,'REQUESTED_QUANTITY'),(2403,'REQUESTED_QUANTITY'),(2404,'REQUESTED_QUANTITY'),(2405,'REQUESTED_QUANTITY'),(2406,'ORDER_ID'),(2407,'DISTRIBUTED_ITEM_ID'),(2408,'SPECIMEN_ARRAY_ID'),(2409,'QUANTITY'),(2410,'QUANTITY'),(2411,'QUANTITY'),(2412,'QUANTITY'),(2413,'QUANTITY'),(2414,'SPECIMEN_ID'),(2415,'SPECIMEN_ID'),(2416,'SPECIMEN_ID'),(2417,'SPECIMEN_ID'),(2418,'SPECIMEN_ID'),(2419,'DISTRIBUTION_ID'),(2420,'DISTRIBUTION_ID'),(2421,'DISTRIBUTION_PROTOCOL_ID'),(2422,'USER_ID'),(2423,'TO_SITE_ID'),(2424,'ORDER_ID'),(2425,'ORDER_ID'),(2426,'ORDER_ID'),(2427,'ORDER_ID'),(2428,'ORDER_ID'),(2429,'ORDER_ID'),(2430,'ORDER_ID'),(2431,'ORDER_ID'),(2432,'ORDER_ID'),(2433,'ORDER_ID'),(2434,'IDENTIFIER'),(2435,'DISTRIBUTION_PROTOCOL_ID'),(2436,'ARRAY_ORDER_ITEM_ID'),(2437,'REQUESTED_QUANTITY'),(2438,'REQUESTED_QUANTITY'),(2439,'REQUESTED_QUANTITY'),(2440,'REQUESTED_QUANTITY'),(2441,'REQUESTED_QUANTITY'),(2442,'ORDER_ID'),(2443,'DISTRIBUTED_ITEM_ID'),(2444,'DE_E_868_880_IDENTIFIER'),(2445,'DE_E_781_782_IDENTIFIER'),(2446,'DE_E_781_783_IDENTIFIER'),(2447,'DE_E_781_784_IDENTIFIER'),(2448,'DE_E_781_785_IDENTIFIER'),(2449,'DE_E_781_786_IDENTIFIER'),(2450,'DE_E_762_787_IDENTIFIER'),(2451,'DE_E_740_788_IDENTIFIER'),(2452,'ARRAY_ORDER_ITEM_ID'),(2453,'REQUESTED_QUANTITY'),(2454,'REQUESTED_QUANTITY'),(2455,'REQUESTED_QUANTITY'),(2456,'REQUESTED_QUANTITY'),(2457,'DISTRIBUTED_ITEM_ID'),(2458,'ORDER_ID'),(2459,'SPECIMEN_COLL_GROUP_ID'),(2460,'SPECIMEN_COLL_GROUP_ID'),(2461,'SPECIMEN_COLL_GROUP_ID'),(2462,'REQUESTED_QUANTITY'),(2463,'ARRAY_ORDER_ITEM_ID'),(2464,'REQUESTED_QUANTITY'),(2465,'REQUESTED_QUANTITY'),(2466,'REQUESTED_QUANTITY'),(2467,'REQUESTED_QUANTITY'),(2468,'DISTRIBUTED_ITEM_ID'),(2469,'ORDER_ID'),(2470,'SPECIMEN_ID'),(2471,'SPECIMEN_ID'),(2472,'SPECIMEN_ID'),(2473,'SPECIMEN_ID'),(2474,'SPECIMEN_ID'),(2475,'REQUESTED_QUANTITY'),(2476,'PARTICIPANT_ID'),(2477,'COLLECTION_PROTOCOL_ID'),(2478,'COLL_PROT_REG_ID'),(2479,'COLLECTION_PROTOCOL_REG_ID'),(2480,'CONSENT_WITNESS'),(2481,'CONSENT_TIER_ID'),(2482,'PARTICIPANT_ID'),(2483,'PARTICIPANT_ID'),(2484,'DE_E_857_858_IDENTIFIER'),(2485,'DE_E_857_859_IDENTIFIER'),(2486,'DE_E_857_860_IDENTIFIER'),(2487,'DE_E_857_861_IDENTIFIER'),(2488,'DE_E_857_862_IDENTIFIER'),(2489,'DE_E_762_863_IDENTIFIER'),(2490,'DE_E_740_864_IDENTIFIER'),(2491,'REQUESTED_QUANTITY'),(2492,'REQUESTED_QUANTITY'),(2493,'REQUESTED_QUANTITY'),(2494,'REQUESTED_QUANTITY'),(2495,'DISTRIBUTED_ITEM_ID'),(2496,'ARRAY_ORDER_ITEM_ID'),(2497,'ARRAY_ORDER_ITEM_ID'),(2498,'ARRAY_ORDER_ITEM_ID'),(2499,'ARRAY_ORDER_ITEM_ID'),(2500,'ARRAY_ORDER_ITEM_ID'),(2501,'ORDER_ID'),(2502,'ARRAY_TYPE_ID'),(2503,'REQUESTED_QUANTITY'),(2504,'ARRAY_ORDER_ITEM_ID'),(2505,'REQUESTED_QUANTITY'),(2506,'REQUESTED_QUANTITY'),(2507,'SPECIMEN_ID'),(2508,'SPECIMEN_ID'),(2509,'SPECIMEN_ID'),(2510,'SPECIMEN_ID'),(2511,'SPECIMEN_ID'),(2512,'DISTRIBUTED_ITEM_ID'),(2513,'ORDER_ID'),(2514,'REQUESTED_QUANTITY'),(2515,'REQUESTED_QUANTITY'),(2516,'REQUESTED_QUANTITY'),(2517,'SPECIMEN_ID'),(2518,'SPECIMEN_ID'),(2519,'SPECIMEN_ID'),(2520,'SPECIMEN_ID'),(2521,'SPECIMEN_ID'),(2522,'DE_E_915_912_IDENTIFIER'),(2523,'DE_E_915_912_IDENTIFIER'),(2524,'DE_E_915_916_IDENTIFIER'),(2525,'DE_E_921_976_IDENTIFIER'),(2526,'DE_E_915_916_IDENTIFIER'),(2527,'DEID_REPORT_ID'),(2528,'SPECIMEN_REQUIREMENT_ID'),(2529,'DISTRIBUTION_PROTOCOL_ID'),(2530,'QUANTITY_ID'),(2531,'QUANTITY_ID'),(2532,'QUANTITY_ID'),(2533,'QUANTITY_ID'),(2534,'QUANTITY_ID'),(2535,'SITE_ID'),(2536,'PARTICIPANT_ID'),(2537,'SPECIMEN_ARRAY_ID'),(2538,'SPECIMEN_ID'),(2539,'INITIAL_QUANTITY_ID'),(2540,'INITIAL_QUANTITY_ID'),(2541,'INITIAL_QUANTITY_ID'),(2542,'INITIAL_QUANTITY_ID'),(2543,'INITIAL_QUANTITY_ID'),(2544,'SPECIMEN_ID'),(2545,'SPECIMEN_ID'),(2546,'SPECIMEN_ID'),(2547,'SPECIMEN_ID'),(2548,'BIOHAZARD_ID'),(2549,'SPECIMEN_ID'),(2550,'BIOHAZARD_ID'),(2551,'SPECIMEN_ID'),(2552,'BIOHAZARD_ID'),(2553,'SPECIMEN_ID'),(2554,'BIOHAZARD_ID'),(2555,'SPECIMEN_ID'),(2556,'BIOHAZARD_ID'),(2557,'SPECIMEN_ID'),(2558,'DE_E_921_976_IDENTIFIER'),(2559,'REQUESTED_QUANTITY'),(2560,'REQUESTED_QUANTITY'),(2561,'REQUESTED_QUANTITY'),(2562,'REQUESTED_QUANTITY'),(2563,'REQUESTED_QUANTITY'),(2564,'SPECIMEN_ARRAY_ID'),(2565,'ORDER_ID'),(2566,'DISTRIBUTED_ITEM_ID'),(2567,'PARENT_CP_ID'),(2568,'PARENT_CP_ID'),(2569,'DE_E_1230_1232_IDENTIFIER'),(2570,'DE_E_1227_1260_IDENTIFIER'),(2571,'DE_E_1258_1261_IDENTIFIER'),(2572,'DE_E_1258_1262_IDENTIFIER'),(2573,'DE_E_1264_1266_IDENTIFIER'),(2574,'DYEXTN_AS_844_1283'),(2575,'DYEXTN_AS_844_1290'),(2576,'DYEXTN_AS_844_1227'),(2577,'DYEXTN_AS_844_1264'),(2578,'DYEXTN_AS_844_1271'),(2579,'DYEXTN_AS_844_1274'),(2580,'DYEXTN_AS_844_1230'),(2581,'DYEXTN_AS_844_1297'),(2582,'DYEXTN_AS_844_1241'),(2583,'DYEXTN_AS_844_1279'),(2584,'DYEXTN_AS_844_1254'),(2585,'DYEXTN_AS_844_1249'),(2586,'DYEXTN_AS_844_1277'),(2587,'DYEXTN_AS_844_1295'),(2588,'DYEXTN_AS_844_1300'),(2589,'DE_E_1318_1320_IDENTIFIER'),(2590,'DE_E_1325_1328_IDENTIFIER'),(2591,'DE_E_1325_1329_IDENTIFIER'),(2592,'DE_E_1325_1330_IDENTIFIER'),(2593,'DE_E_1332_1334_IDENTIFIER'),(2594,'DE_E_1365_1367_IDENTIFIER'),(2595,'DE_E_1377_1379_IDENTIFIER'),(2596,'DYEXTN_AS_4_1325'),(2597,'DYEXTN_AS_4_1359'),(2598,'DYEXTN_AS_4_1375'),(2599,'DYEXTN_AS_4_1349'),(2600,'DYEXTN_AS_4_1363'),(2601,'DYEXTN_AS_4_1377'),(2602,'DYEXTN_AS_4_1357'),(2603,'DYEXTN_AS_4_1386'),(2604,'DYEXTN_AS_4_1365'),(2605,'DE_E_1325_1399_IDENTIFIER'),(2606,'DE_E_1400_1402_IDENTIFIER'),(2607,'DE_E_1377_1407_IDENTIFIER'),(2608,'DE_E_1365_1413_IDENTIFIER'),(2609,'DE_E_1290_1420_IDENTIFIER'),(2610,'DE_E_1227_1426_IDENTIFIER'),(2611,'DE_E_1427_1429_IDENTIFIER'),(2612,'DE_E_1427_1430_IDENTIFIER'),(2613,'DE_E_1440_1442_IDENTIFIER'),(2614,'DE_E_1440_1443_IDENTIFIER'),(2615,'DE_E_1447_1449_IDENTIFIER'),(2616,'DE_E_1454_1456_IDENTIFIER'),(2617,'DE_E_1461_1463_IDENTIFIER'),(2618,'DE_E_1461_1464_IDENTIFIER'),(2619,'DE_E_1461_1465_IDENTIFIER'),(2620,'DE_E_1461_1466_IDENTIFIER'),(2621,'DE_E_1461_1467_IDENTIFIER'),(2622,'DE_E_1484_1486_IDENTIFIER'),(2623,'DE_E_1484_1487_IDENTIFIER'),(2624,'DE_E_1484_1488_IDENTIFIER'),(2625,'DE_E_1497_1499_IDENTIFIER'),(2626,'DE_E_1508_1510_IDENTIFIER'),(2627,'DE_E_1518_1520_IDENTIFIER'),(2628,'DE_E_1518_1521_IDENTIFIER'),(2629,'DE_E_1527_1529_IDENTIFIER'),(2630,'DE_E_1545_1547_IDENTIFIER'),(2631,'DE_E_1566_1568_IDENTIFIER'),(2632,'DE_E_1577_1579_IDENTIFIER'),(2633,'DE_E_1577_1580_IDENTIFIER'),(2634,'DE_E_1600_1602_IDENTIFIER'),(2635,'DE_E_1608_1610_IDENTIFIER'),(2636,'DE_E_1615_1617_IDENTIFIER'),(2637,'DE_E_1615_1618_IDENTIFIER'),(2638,'DE_E_1620_1622_IDENTIFIER'),(2639,'DE_E_1631_1633_IDENTIFIER'),(2640,'DE_E_1631_1634_IDENTIFIER'),(2641,'DE_E_1631_1636_IDENTIFIER'),(2642,'DE_E_1648_1650_IDENTIFIER'),(2643,'DE_E_1667_1669_IDENTIFIER'),(2644,'DE_E_1667_1670_IDENTIFIER'),(2645,'DE_E_1676_1678_IDENTIFIER'),(2646,'DE_E_1676_1679_IDENTIFIER'),(2647,'DE_E_1680_1682_IDENTIFIER'),(2648,'DE_E_1685_1687_IDENTIFIER'),(2649,'DE_E_1693_1695_IDENTIFIER'),(2650,'DE_E_1705_1707_IDENTIFIER'),(2651,'DE_E_1705_1708_IDENTIFIER'),(2652,'DE_E_1715_1717_IDENTIFIER'),(2653,'DE_E_1715_1718_IDENTIFIER'),(2654,'DE_E_1715_1719_IDENTIFIER'),(2655,'DE_E_1715_1720_IDENTIFIER'),(2656,'DE_E_1723_1725_IDENTIFIER'),(2657,'DE_E_1727_1729_IDENTIFIER'),(2658,'DE_E_1731_1733_IDENTIFIER'),(2659,'DE_E_1735_1745_IDENTIFIER'),(2660,'DE_E_1735_1746_IDENTIFIER'),(2661,'DE_E_1735_1747_IDENTIFIER'),(2662,'DE_E_1749_1751_IDENTIFIER'),(2663,'DE_E_1754_1756_IDENTIFIER'),(2664,'DE_E_1754_1758_IDENTIFIER'),(2665,'DE_E_1754_1759_IDENTIFIER'),(2666,'DE_E_1765_1767_IDENTIFIER'),(2667,'DE_E_1773_1776_IDENTIFIER'),(2668,'DE_E_1777_1779_IDENTIFIER'),(2669,'DE_E_1784_1786_IDENTIFIER'),(2670,'DE_E_1788_1790_IDENTIFIER'),(2671,'DE_E_1788_1791_IDENTIFIER'),(2672,'DE_E_1788_1792_IDENTIFIER'),(2673,'DE_E_1788_1793_IDENTIFIER'),(2674,'DE_E_1797_1799_IDENTIFIER'),(2675,'DE_E_1797_1800_IDENTIFIER'),(2676,'DYEXTN_AS_379_1440'),(2677,'DYEXTN_AS_379_1577'),(2678,'DYEXTN_AS_379_1461'),(2679,'DYEXTN_AS_379_1545'),(2680,'DYEXTN_AS_379_1676'),(2681,'DYEXTN_AS_379_1652'),(2682,'DYEXTN_AS_379_1794'),(2683,'DYEXTN_AS_379_1625'),(2684,'DYEXTN_AS_379_1705'),(2685,'DYEXTN_AS_379_1516'),(2686,'DYEXTN_AS_379_1559'),(2687,'DYEXTN_AS_379_1518'),(2688,'DYEXTN_AS_379_1536'),(2689,'DYEXTN_AS_379_1539'),(2690,'DYEXTN_AS_379_1797'),(2691,'DYEXTN_AS_379_1735'),(2692,'DYEXTN_AS_379_1773'),(2693,'DYEXTN_AS_379_1754'),(2694,'DYEXTN_AS_379_1593'),(2695,'DYEXTN_AS_379_1788'),(2696,'DYEXTN_AS_379_1631'),(2697,'DYEXTN_AS_379_1715'),(2698,'DE_E_1773_1827_IDENTIFIER'),(2699,'DE_E_1754_1834_IDENTIFIER'),(2700,'DE_E_1754_1835_IDENTIFIER'),(2701,'DE_E_1593_1840_IDENTIFIER'),(2702,'DE_E_1631_1843_IDENTIFIER'),(2703,'DE_E_1631_1844_IDENTIFIER'),(2704,NULL),(2705,'IDENTIFIER'),(2706,NULL),(2707,'IDENTIFIER'),(2708,NULL),(2709,'IDENTIFIER'),(2710,NULL),(2711,'IDENTIFIER'),(2712,NULL),(2713,'IDENTIFIER'),(2714,NULL),(2715,'IDENTIFIER'),(2716,NULL),(2717,'IDENTIFIER'),(2718,NULL),(2719,'IDENTIFIER'),(2720,NULL),(2721,'IDENTIFIER'),(2722,NULL),(2723,'IDENTIFIER'),(2724,NULL),(2725,'IDENTIFIER'),(2726,NULL),(2727,'IDENTIFIER'),(2728,NULL),(2729,'IDENTIFIER'),(2730,NULL),(2731,'IDENTIFIER'),(2732,NULL),(2733,'IDENTIFIER'),(2734,NULL),(2735,'IDENTIFIER'),(2736,NULL),(2737,'IDENTIFIER'),(2738,NULL),(2739,'IDENTIFIER'),(2740,NULL),(2741,'IDENTIFIER'),(2742,NULL),(2743,'IDENTIFIER'),(2744,NULL),(2745,'IDENTIFIER'),(2746,NULL),(2747,'IDENTIFIER'),(2748,NULL),(2749,'IDENTIFIER'),(2750,NULL),(2751,'IDENTIFIER'),(2752,NULL),(2753,'IDENTIFIER'),(2754,NULL),(2755,'IDENTIFIER'),(2756,NULL),(2757,'IDENTIFIER'),(2758,NULL),(2759,'IDENTIFIER'),(2760,NULL),(2761,'IDENTIFIER'),(2762,NULL),(2763,'IDENTIFIER'),(2764,NULL),(2765,'IDENTIFIER'),(2766,NULL),(2767,'IDENTIFIER'),(2768,NULL),(2769,'IDENTIFIER'),(2770,NULL),(2771,'IDENTIFIER'),(2772,NULL),(2773,'IDENTIFIER'),(2774,NULL),(2775,'IDENTIFIER'),(2776,NULL),(2777,'IDENTIFIER'),(2778,NULL),(2779,'IDENTIFIER'),(2780,NULL),(2781,'IDENTIFIER'),(2782,NULL),(2783,'IDENTIFIER'),(2784,NULL),(2785,'IDENTIFIER'),(2786,NULL),(2787,'IDENTIFIER'),(2788,NULL),(2789,'IDENTIFIER'),(2790,NULL),(2791,'IDENTIFIER'),(2792,NULL),(2793,'IDENTIFIER'),(2794,NULL),(2795,'IDENTIFIER'),(2796,NULL),(2797,'IDENTIFIER'),(2798,NULL),(2799,'IDENTIFIER'),(2800,NULL),(2801,'IDENTIFIER'),(2802,NULL),(2803,'IDENTIFIER'),(2804,NULL),(2805,'IDENTIFIER'),(2806,NULL),(2807,'IDENTIFIER'),(2808,NULL),(2809,'IDENTIFIER'),(2810,NULL),(2811,'IDENTIFIER'),(2812,NULL),(2813,'IDENTIFIER'),(2814,NULL),(2815,'IDENTIFIER'),(2816,NULL),(2817,'IDENTIFIER'),(2818,NULL),(2819,'IDENTIFIER'),(2820,NULL),(2821,'IDENTIFIER'),(2822,NULL),(2823,'IDENTIFIER'),(2824,NULL),(2825,'IDENTIFIER'),(2826,NULL),(2827,'IDENTIFIER'),(2828,NULL),(2829,'IDENTIFIER'),(2830,NULL),(2831,'IDENTIFIER'),(2832,NULL),(2833,'IDENTIFIER'),(2834,NULL),(2835,'IDENTIFIER'),(2836,NULL),(2837,'IDENTIFIER'),(2838,NULL),(2839,'IDENTIFIER'),(2840,NULL),(2841,'IDENTIFIER'),(2842,NULL),(2843,'IDENTIFIER'),(2844,NULL),(2845,'IDENTIFIER'),(2846,NULL),(2847,'IDENTIFIER'),(2848,NULL),(2849,'IDENTIFIER'),(2850,NULL),(2851,'IDENTIFIER'),(2852,NULL),(2853,'IDENTIFIER'),(2854,NULL),(2855,'IDENTIFIER'),(2856,NULL),(2857,'IDENTIFIER'),(2858,NULL),(2859,'IDENTIFIER'),(2860,NULL),(2861,'IDENTIFIER'),(2862,NULL),(2863,'IDENTIFIER'),(2864,NULL),(2865,'IDENTIFIER'),(2866,NULL),(2867,'IDENTIFIER'),(2868,NULL),(2869,'IDENTIFIER'),(2870,NULL),(2871,'IDENTIFIER'),(2872,NULL),(2873,'IDENTIFIER'),(2874,NULL),(2875,'IDENTIFIER'),(2876,NULL),(2877,'IDENTIFIER'),(2878,NULL),(2879,'IDENTIFIER'),(2880,NULL),(2881,'IDENTIFIER'),(2882,NULL),(2883,'IDENTIFIER'),(2884,NULL),(2885,'IDENTIFIER'),(2886,NULL),(2887,'IDENTIFIER'),(2888,NULL),(2889,'IDENTIFIER'),(2890,NULL),(2891,'IDENTIFIER'),(2892,NULL),(2893,'IDENTIFIER'),(2894,NULL),(2895,'IDENTIFIER'),(2896,'CATISSUE_RACE'),(2897,'IDENTIFIER'),(2898,'RACE_NAME'),(2899,'participant_race'),(2900,'PARTICIPANT_ID'),(2901,'race_participant'),(2902,'PARTICIPANT_ID'),(2903,'CATISSUE_ABSTRACT_POSITION'),(2904,'IDENTIFIER'),(2905,'POSITION_DIMENSION_ONE'),(2906,'POSITION_DIMENSION_TWO'),(2907,'CATISSUE_ABSTRACT_SPECIMEN'),(2908,'IDENTIFIER'),(2909,'abstractSpecimen_SpecimenEventParameters'),(2910,'SPECIMEN_ID'),(2911,'SpecimenEventParameters_abstractSpecimen'),(2912,'SPECIMEN_ID'),(2913,'CATISSUE_CP_REQ_SPECIMEN'),(2914,'IDENTIFIER'),(2915,'STORAGE_TYPE'),(2916,'collectionProtocolEvent_specimenRequirement'),(2917,'COLLECTION_PROTOCOL_EVENT_ID'),(2918,'specimenRequirement_collectionProtocolEvent'),(2919,'COLLECTION_PROTOCOL_EVENT_ID'),(2920,'specimenRequirement_specimen'),(2921,'REQ_SPECIMEN_ID'),(2922,'specimen_specimenRequirement'),(2923,'REQ_SPECIMEN_ID'),(2924,'SPECIMEN_CLASS'),(2925,'CATISSUE_BASE_SHIPMENT'),(2926,'IDENTIFIER'),(2927,'LABEL'),(2928,'CREATED_DATE'),(2929,'RECEIVER_COMMENTS'),(2930,'SENDER_COMMENTS'),(2931,'SEND_DATE'),(2932,'ACTIVITY_STATUS'),(2933,'CATISSUE_BASE_SHIPMENT'),(2934,'null'),(2935,'CATISSUE_BASE_SHIPMENT'),(2936,'null'),(2937,'CATISSUE_BASE_SHIPMENT'),(2938,'null'),(2939,'CATISSUE_BASE_SHIPMENT'),(2940,'null'),(2941,'CATISSUE_SHIPMENT_CONTAINR_REL'),(2942,'CONTAINER_ID'),(2943,'CATISSUE_SHIPMENT_REQUEST'),(2944,'CATISSUE_SHIPMENT'),(2945,'CATISSUE_CONTAINER_POSITION'),(2946,'CATISSUE_SPECIMEN_POSITION'),(2947,'CATISSUE_CELL_REQ_SPECIMEN'),(2948,'CATISSUE_FLUID_REQ_SPECIMEN'),(2949,'CATISSUE_MOL_REQ_SPECIMEN'),(2950,'CATISSUE_TISSUE_REQ_SPECIMEN'),(2951,'IDENTIFIER'),(2952,'IDENTIFIER'),(2953,'IDENTIFIER'),(2954,'IDENTIFIER'),(2955,'IDENTIFIER'),(2956,'IDENTIFIER'),(2957,'CONCENTRATION'),(2958,'IDENTIFIER'),(2959,'IDENTIFIER'),(2960,'BARCODE'),(2961,'specimen_specimenPosition'),(2962,'SPECIMEN_ID'),(2963,'specimenPosition_specimen'),(2964,'SPECIMEN_ID'),(2965,'CATISSUE_USER_CP'),(2966,'USER_ID'),(2967,'COLLECTION_PROTOCOL_ID'),(2968,'CATISSUE_USER_CP'),(2969,'COLLECTION_PROTOCOL_ID'),(2970,'USER_ID'),(2971,'CATISSUE_SITE_CP'),(2972,'COLLECTION_PROTOCOL_ID'),(2973,'SITE_ID'),(2974,'CATISSUE_SITE_CP'),(2975,'SITE_ID'),(2976,'COLLECTION_PROTOCOL_ID'),(2977,'CATISSUE_SITE_USERS'),(2978,'SITE_ID'),(2979,'USER_ID'),(2980,'CATISSUE_SITE_USERS'),(2981,'USER_ID'),(2982,'SITE_ID'),(2983,'site_abstractSCG'),(2984,'SITE_ID'),(2985,'CATISSUE_ORDER_ITEM'),(2986,'null'),(2987,'container_containerPosition'),(2988,'PARENT_CONTAINER_ID'),(2989,'containerPosition_container'),(2990,'PARENT_CONTAINER_ID'),(2991,'storageContainer_specimenPosition'),(2992,'CONTAINER_ID'),(2993,'specimenPosition_storageContainer'),(2994,'CONTAINER_ID'),(2995,'CATISSUE_SHIPMENT'),(2996,'null'),(2997,'CATISSUE_SPECI_SHIPMNT_REQ_REL'),(2998,'SPECIMEN_ID'),(2999,'CONSENT_DOC_URL'),(3000,'CONSENT_SIGN_DATE'),(3001,'QUANTITY'),(3002,'UNSIGNED_CONSENT_DOC_URL'),(3003,'QUANTITY'),(3004,'BARCODE'),(3005,'BARCODE'),(3006,'CATISSUE_CLINICAL_DIAGNOSIS'),(3007,'IDENTIFIER'),(3008,'CLINICAL_DIAGNOSIS'),(3009,'specimenArray_specimenArrayContent'),(3010,'SPECIMEN_ARRAY_ID'),(3011,'collectionProtocol_clinicalDiagnosis'),(3012,'COLLECTION_PROTOCOL_ID'),(3013,'clinicalDiagnosis_collectionProtocol'),(3014,'COLLECTION_PROTOCOL_ID'),(3015,'DYEXTN_ABSTRACT_FORM_CONTEXT'),(3016,'IDENTIFIER'),(3017,'FORM_LABEL'),(3018,'CONTAINER_ID'),(3019,'ACTIVITY_STATUS'),(3020,'HIDE_FORM'),(3021,'DYEXTN_ABSTRACT_RECORD_ENTRY'),(3022,'IDENTIFIER'),(3023,'ACTIVITY_STATUS'),(3024,'MODIFIED_DATE'),(3025,'MODIFIED_BY'),(3026,'CATISSUE_PARTICIPANT_REC_NTRY'),(3027,'IDENTIFIER'),(3028,'CATISSUE_SPECIMEN_REC_NTRY'),(3029,'IDENTIFIER'),(3030,'CATISSUE_SCG_REC_NTRY'),(3031,'IDENTIFIER'),(3032,'CATISSUE_STUDY_FORM_CONTEXT'),(3033,'IDENTIFIER'),(3034,'abstractFormContext_abstractRecordEntry'),(3035,'ABSTRACT_FORM_CONTEXT_ID'),(3036,'abstractRecordEntry_abstractFormContext'),(3037,'ABSTRACT_FORM_CONTEXT_ID'),(3038,'participant_participantRecordEntry'),(3039,'PARTICIPANT_ID'),(3040,'participantRecordEntry_participant'),(3041,'PARTICIPANT_ID'),(3042,'specimen_specimenRecordEntry'),(3043,'SPECIMEN_ID'),(3044,'specimenRecordEntry_specimen'),(3045,'SPECIMEN_ID'),(3046,'scg_scgRecordEntry'),(3047,'SPECIMEN_COLLECTION_GROUP_ID'),(3048,'scgRecordEntry_scg'),(3049,'SPECIMEN_COLLECTION_GROUP_ID'),(3050,'CATISSUE_CP_STUDYFORMCONTEXT'),(3051,'COLLECTION_PROTOCOL_ID'),(3052,'STUDY_FORM_CONTEXT_ID'),(3053,'CATISSUE_CP_STUDYFORMCONTEXT'),(3054,'STUDY_FORM_CONTEXT_ID'),(3055,'COLLECTION_PROTOCOL_ID');

/*Table structure for table `dyextn_entity_group` */

DROP TABLE IF EXISTS `dyextn_entity_group`;

CREATE TABLE `dyextn_entity_group` (
  `IDENTIFIER` bigint(20) NOT NULL,
  `LONG_NAME` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IS_SYSTEM_GENERATED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK105DE7A0728B19BE` (`IDENTIFIER`),
  CONSTRAINT `FK105DE7A0728B19BE` FOREIGN KEY (`IDENTIFIER`) REFERENCES `dyextn_abstract_metadata` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_entity_group` */

insert  into `dyextn_entity_group`(`IDENTIFIER`,`LONG_NAME`,`SHORT_NAME`,`VERSION`,`IS_SYSTEM_GENERATED`) values (1,'Catissue Suite','caTissueCore',NULL,1),(1208,'DataListEntityGroup','DataListEntityGroup',NULL,1),(1226,'clinical_annotation','clinical_annotation',NULL,0),(1317,'pathology_specimen','pathology_specimen',NULL,0),(1436,'pathology_scg','pathology_scg',NULL,0);

/*Table structure for table `dyextn_entity_map` */

DROP TABLE IF EXISTS `dyextn_entity_map`;

CREATE TABLE `dyextn_entity_map` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `CONTAINER_ID` bigint(20) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `STATIC_ENTITY_ID` bigint(20) DEFAULT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_entity_map` */

insert  into `dyextn_entity_map`(`IDENTIFIER`,`CONTAINER_ID`,`STATUS`,`STATIC_ENTITY_ID`,`CREATED_DATE`,`CREATED_BY`) values (1,1,'Attached',844,'2008-01-21',''),(2,2,'Attached',844,'2008-01-21',''),(3,3,'Attached',844,'2008-01-21',''),(4,5,'Attached',844,'2008-01-21',''),(5,6,'Attached',844,'2008-01-21',''),(6,7,'Attached',844,'2008-01-21',''),(7,8,'Attached',844,'2008-01-21',''),(8,9,'Attached',844,'2008-01-21',''),(9,10,'Attached',844,'2008-01-21',''),(10,13,'Attached',844,'2008-01-21',''),(11,12,'Attached',844,'2008-01-21',''),(12,11,'Attached',844,'2008-01-21',''),(13,14,'Attached',844,'2008-01-21',''),(14,15,'Attached',844,'2008-01-21',''),(15,16,'Attached',844,'2008-01-21',''),(16,21,'Attached',4,'2008-01-21',''),(17,22,'Attached',4,'2008-01-21',''),(18,23,'Attached',4,'2008-01-21',''),(19,24,'Attached',4,'2008-01-21',''),(20,25,'Attached',4,'2008-01-21',''),(21,26,'Attached',4,'2008-01-21',''),(22,27,'Attached',4,'2008-01-21',''),(23,28,'Attached',4,'2008-01-21',''),(24,29,'Attached',4,'2008-01-21',''),(25,42,'Attached',379,'2008-01-22',''),(26,45,'Attached',379,'2008-01-22',''),(27,56,'Attached',379,'2008-01-22',''),(28,58,'Attached',379,'2008-01-22',''),(29,63,'Attached',379,'2008-01-22',''),(30,64,'Attached',379,'2008-01-22',''),(31,65,'Attached',379,'2008-01-22',''),(32,66,'Attached',379,'2008-01-22',''),(33,72,'Attached',379,'2008-01-22',''),(34,73,'Attached',379,'2008-01-22',''),(35,74,'Attached',379,'2008-01-22',''),(36,78,'Attached',379,'2008-01-22',''),(37,79,'Attached',379,'2008-01-22',''),(38,80,'Attached',379,'2008-01-22',''),(39,84,'Attached',379,'2008-01-22',''),(40,89,'Attached',379,'2008-01-22',''),(41,92,'Attached',379,'2008-01-22',''),(42,98,'Attached',379,'2008-01-22',''),(43,99,'Attached',379,'2008-01-22',''),(44,105,'Attached',379,'2008-01-22',''),(45,110,'Attached',379,'2008-01-22',''),(46,116,'Attached',379,'2008-01-22','');

/*Table structure for table `dyextn_file` */

DROP TABLE IF EXISTS `dyextn_file`;

CREATE TABLE `dyextn_file` (
  `IDENTIFIER` bigint(20) NOT NULL DEFAULT '0',
  `FILE_RECORD` blob,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_file` */

/*Table structure for table `dyextn_form_context` */

DROP TABLE IF EXISTS `dyextn_form_context`;

CREATE TABLE `dyextn_form_context` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `IS_INFINITE_ENTRY` tinyint(1) DEFAULT NULL,
  `ENTITY_MAP_ID` bigint(20) DEFAULT NULL,
  `STUDY_FORM_LABEL` varchar(255) DEFAULT NULL,
  `NO_OF_ENTRIES` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKE56CCDB12B784475` (`ENTITY_MAP_ID`),
  CONSTRAINT `FKE56CCDB12B784475` FOREIGN KEY (`ENTITY_MAP_ID`) REFERENCES `dyextn_entity_map` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_form_context` */

insert  into `dyextn_form_context`(`IDENTIFIER`,`IS_INFINITE_ENTRY`,`ENTITY_MAP_ID`,`STUDY_FORM_LABEL`,`NO_OF_ENTRIES`) values (1,NULL,1,NULL,NULL),(2,NULL,2,NULL,NULL),(3,NULL,3,NULL,NULL),(4,NULL,4,NULL,NULL),(5,NULL,5,NULL,NULL),(6,NULL,6,NULL,NULL),(7,NULL,7,NULL,NULL),(8,NULL,8,NULL,NULL),(9,NULL,9,NULL,NULL),(10,NULL,10,NULL,NULL),(11,NULL,11,NULL,NULL),(12,NULL,12,NULL,NULL),(13,NULL,13,NULL,NULL),(14,NULL,14,NULL,NULL),(15,NULL,15,NULL,NULL),(16,NULL,16,NULL,NULL),(17,NULL,17,NULL,NULL),(18,NULL,18,NULL,NULL),(19,NULL,19,NULL,NULL),(20,NULL,20,NULL,NULL),(21,NULL,21,NULL,NULL),(22,NULL,22,NULL,NULL),(23,NULL,23,NULL,NULL),(24,NULL,24,NULL,NULL),(25,NULL,25,NULL,NULL),(26,NULL,26,NULL,NULL),(27,NULL,27,NULL,NULL),(28,NULL,28,NULL,NULL),(29,NULL,29,NULL,NULL),(30,NULL,30,NULL,NULL),(31,NULL,31,NULL,NULL),(32,NULL,32,NULL,NULL),(33,NULL,33,NULL,NULL),(34,NULL,34,NULL,NULL),(35,NULL,35,NULL,NULL),(36,NULL,36,NULL,NULL),(37,NULL,37,NULL,NULL),(38,NULL,38,NULL,NULL),(39,NULL,39,NULL,NULL),(40,NULL,40,NULL,NULL),(41,NULL,41,NULL,NULL),(42,NULL,42,NULL,NULL),(43,NULL,43,NULL,NULL),(44,NULL,44,NULL,NULL),(45,NULL,45,NULL,NULL),(46,NULL,46,NULL,NULL);

/*Table structure for table `dyextn_id_generator` */

DROP TABLE IF EXISTS `dyextn_id_generator`;

CREATE TABLE `dyextn_id_generator` (
  `ID` bigint(20) NOT NULL,
  `NEXT_AVAILABLE_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_id_generator` */

insert  into `dyextn_id_generator`(`ID`,`NEXT_AVAILABLE_ID`) values (1,1900);

/*Table structure for table `dyextn_label` */

DROP TABLE IF EXISTS `dyextn_label`;

CREATE TABLE `dyextn_label` (
  `IDENTIFIER` bigint(19) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dyextn_label` */

/*Table structure for table `dyextn_role` */

DROP TABLE IF EXISTS `dyextn_role`;

CREATE TABLE `dyextn_role` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `ASSOCIATION_TYPE` varchar(255) DEFAULT NULL,
  `MAX_CARDINALITY` int(11) DEFAULT NULL,
  `MIN_CARDINALITY` int(11) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=1389 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_role` */

insert  into `dyextn_role`(`IDENTIFIER`,`ASSOCIATION_TYPE`,`MAX_CARDINALITY`,`MIN_CARDINALITY`,`NAME`) values (3,'ASSOCIATION',2,0,'specimenCollection'),(4,'ASSOCIATION',1,0,'specimenCollectionGroup'),(5,'ASSOCIATION',2,0,'specimenCollection'),(6,'ASSOCIATION',1,0,'specimenCollectionGroup'),(7,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(8,'CONTAINTMENT',2,0,'consentTierStatusCollection'),(17,'ASSOCIATION',1,0,'parentSpecimen'),(18,'ASSOCIATION',2,0,'childrenSpecimen'),(19,'ASSOCIATION',2,1,'edu.wustl.catissuecore.domain.Specimen'),(20,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.AbstractSpecimen'),(21,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(22,'ASSOCIATION',1,0,'availableQuantity'),(23,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(24,'ASSOCIATION',1,0,'availableQuantity'),(25,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(26,'ASSOCIATION',1,0,'availableQuantity'),(27,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(28,'ASSOCIATION',1,0,'availableQuantity'),(29,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(30,'ASSOCIATION',1,0,'availableQuantity'),(31,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(32,'ASSOCIATION',1,0,'initialQuantity'),(33,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(34,'ASSOCIATION',1,0,'initialQuantity'),(35,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(36,'ASSOCIATION',1,0,'initialQuantity'),(37,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(38,'ASSOCIATION',1,0,'initialQuantity'),(39,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Specimen'),(40,'ASSOCIATION',1,0,'initialQuantity'),(41,'ASSOCIATION',2,0,'specimenCollection'),(42,'ASSOCIATION',1,0,'storageContainer'),(43,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Container'),(44,'CONTAINTMENT',1,0,'capacity'),(51,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArray'),(52,'CONTAINTMENT',1,0,'capacity'),(53,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArray'),(54,'ASSOCIATION',1,0,'storageContainer'),(55,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArray'),(56,'ASSOCIATION',1,0,'createdBy'),(57,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArray'),(58,'ASSOCIATION',1,0,'specimenArrayType'),(65,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.StorageContainer'),(66,'CONTAINTMENT',1,0,'capacity'),(67,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageContainer'),(68,'ASSOCIATION',2,0,'holdsSpecimenArrayTypeCollection'),(69,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageContainer'),(70,'ASSOCIATION',2,0,'holdsStorageTypeCollection'),(71,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageContainer'),(72,'ASSOCIATION',2,0,'collectionProtocolCollection'),(75,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.StorageContainer'),(76,'ASSOCIATION',1,0,'storageType'),(77,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageContainer'),(78,'ASSOCIATION',1,0,'site'),(83,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.Site'),(84,'CONTAINTMENT',1,0,'address'),(85,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.Site'),(86,'ASSOCIATION',1,0,'coordinator'),(87,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.User'),(88,'ASSOCIATION',1,0,'department'),(89,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.User'),(90,'ASSOCIATION',1,0,'cancerResearchGroup'),(91,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.User'),(92,'ASSOCIATION',1,0,'institution'),(93,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.User'),(94,'CONTAINTMENT',1,0,'address'),(95,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.User'),(96,'ASSOCIATION',2,1,'passwordCollection'),(97,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ContainerType'),(98,'CONTAINTMENT',1,0,'capacity'),(99,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageType'),(100,'ASSOCIATION',2,0,'holdsSpecimenArrayTypeCollection'),(101,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.StorageType'),(102,'CONTAINTMENT',1,0,'capacity'),(103,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.StorageType'),(104,'ASSOCIATION',2,0,'holdsStorageTypeCollection'),(105,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayType'),(106,'CONTAINTMENT',1,0,'capacity'),(107,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenProtocol'),(108,'ASSOCIATION',1,0,'principalInvestigator'),(109,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CollectionProtocol'),(110,'CONTAINTMENT',2,0,'consentTierCollection'),(111,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.CollectionProtocol'),(112,'ASSOCIATION',1,0,'principalInvestigator'),(113,'ASSOCIATION',2,0,'collectionProtocolCollection'),(114,'ASSOCIATION',2,0,'coordinatorCollection'),(115,'ASSOCIATION',2,0,'collectionProtocolCollection'),(116,'ASSOCIATION',2,0,'distributionProtocolCollection'),(117,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributionProtocol'),(118,'ASSOCIATION',1,0,'principalInvestigator'),(121,'ASSOCIATION',2,0,'specimenCollection'),(122,'ASSOCIATION',1,0,'specimenCollectionGroup'),(123,'ASSOCIATION',2,0,'specimenCollection'),(124,'ASSOCIATION',1,0,'specimenCollectionGroup'),(125,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(126,'ASSOCIATION',2,0,'consentTierStatusCollection'),(137,'ASSOCIATION',2,1,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(138,'CONTAINTMENT',1,0,'specimenCharacteristics'),(139,'ASSOCIATION',2,0,'specimenCollection'),(140,'ASSOCIATION',1,0,'storageContainer'),(141,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(142,'ASSOCIATION',1,0,'availableQuantity'),(143,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(144,'ASSOCIATION',1,0,'availableQuantity'),(145,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(146,'ASSOCIATION',1,0,'availableQuantity'),(147,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(148,'ASSOCIATION',1,0,'availableQuantity'),(149,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(150,'ASSOCIATION',1,0,'availableQuantity'),(151,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(152,'ASSOCIATION',1,0,'initialQuantity'),(153,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(154,'ASSOCIATION',1,0,'initialQuantity'),(155,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(156,'ASSOCIATION',1,0,'initialQuantity'),(157,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(158,'ASSOCIATION',1,0,'initialQuantity'),(159,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.MolecularSpecimen'),(160,'ASSOCIATION',1,0,'initialQuantity'),(163,'ASSOCIATION',2,0,'specimenCollection'),(164,'ASSOCIATION',1,0,'specimenCollectionGroup'),(165,'ASSOCIATION',2,0,'specimenCollection'),(166,'ASSOCIATION',1,0,'specimenCollectionGroup'),(167,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(168,'ASSOCIATION',2,0,'consentTierStatusCollection'),(179,'ASSOCIATION',2,1,'edu.wustl.catissuecore.domain.CellSpecimen'),(180,'CONTAINTMENT',1,0,'specimenCharacteristics'),(181,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(182,'ASSOCIATION',1,0,'availableQuantity'),(183,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(184,'ASSOCIATION',1,0,'availableQuantity'),(185,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(186,'ASSOCIATION',1,0,'availableQuantity'),(187,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(188,'ASSOCIATION',1,0,'availableQuantity'),(189,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(190,'ASSOCIATION',1,0,'availableQuantity'),(191,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(192,'ASSOCIATION',1,0,'initialQuantity'),(193,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(194,'ASSOCIATION',1,0,'initialQuantity'),(195,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(196,'ASSOCIATION',1,0,'initialQuantity'),(197,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(198,'ASSOCIATION',1,0,'initialQuantity'),(199,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CellSpecimen'),(200,'ASSOCIATION',1,0,'initialQuantity'),(201,'ASSOCIATION',2,0,'specimenCollection'),(202,'ASSOCIATION',1,0,'storageContainer'),(205,'ASSOCIATION',2,0,'specimenCollection'),(206,'ASSOCIATION',1,0,'specimenCollectionGroup'),(207,'ASSOCIATION',2,0,'specimenCollection'),(208,'ASSOCIATION',1,0,'specimenCollectionGroup'),(209,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(210,'ASSOCIATION',2,0,'consentTierStatusCollection'),(221,'ASSOCIATION',2,1,'edu.wustl.catissuecore.domain.TissueSpecimen'),(222,'CONTAINTMENT',1,0,'specimenCharacteristics'),(223,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(224,'ASSOCIATION',1,0,'availableQuantity'),(225,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(226,'ASSOCIATION',1,0,'availableQuantity'),(227,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(228,'ASSOCIATION',1,0,'availableQuantity'),(229,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(230,'ASSOCIATION',1,0,'availableQuantity'),(231,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(232,'ASSOCIATION',1,0,'availableQuantity'),(233,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(234,'ASSOCIATION',1,0,'initialQuantity'),(235,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(236,'ASSOCIATION',1,0,'initialQuantity'),(237,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(238,'ASSOCIATION',1,0,'initialQuantity'),(239,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(240,'ASSOCIATION',1,0,'initialQuantity'),(241,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.TissueSpecimen'),(242,'ASSOCIATION',1,0,'initialQuantity'),(243,'ASSOCIATION',2,0,'specimenCollection'),(244,'ASSOCIATION',1,0,'storageContainer'),(247,'ASSOCIATION',2,0,'specimenCollection'),(248,'ASSOCIATION',1,0,'specimenCollectionGroup'),(249,'ASSOCIATION',2,0,'specimenCollection'),(250,'ASSOCIATION',1,0,'specimenCollectionGroup'),(251,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(252,'ASSOCIATION',2,0,'consentTierStatusCollection'),(263,'ASSOCIATION',2,1,'edu.wustl.catissuecore.domain.FluidSpecimen'),(264,'CONTAINTMENT',1,0,'specimenCharacteristics'),(265,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(266,'ASSOCIATION',1,0,'availableQuantity'),(267,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(268,'ASSOCIATION',1,0,'availableQuantity'),(269,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(270,'ASSOCIATION',1,0,'availableQuantity'),(271,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(272,'ASSOCIATION',1,0,'availableQuantity'),(273,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(274,'ASSOCIATION',1,0,'availableQuantity'),(275,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(276,'ASSOCIATION',1,0,'initialQuantity'),(277,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(278,'ASSOCIATION',1,0,'initialQuantity'),(279,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(280,'ASSOCIATION',1,0,'initialQuantity'),(281,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(282,'ASSOCIATION',1,0,'initialQuantity'),(283,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.FluidSpecimen'),(284,'ASSOCIATION',1,0,'initialQuantity'),(285,'ASSOCIATION',2,0,'specimenCollection'),(286,'ASSOCIATION',1,0,'storageContainer'),(287,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ConsentTierStatus'),(288,'ASSOCIATION',1,0,'consentTier'),(289,'ASSOCIATION',2,0,'abstractSpecimenCollectionGroupCollection'),(290,'ASSOCIATION',1,0,'specimenCollectionSite'),(291,'ASSOCIATION',2,0,'abstractSpecimenCollectionGroupCollection'),(292,'ASSOCIATION',1,0,'specimenCollectionSite'),(293,'ASSOCIATION',2,0,'specimenCollectionGroupCollection'),(294,'ASSOCIATION',1,0,'collectionProtocolEvent'),(295,'ASSOCIATION',1,0,'specimenCollectionGroup'),(296,'ASSOCIATION',1,0,'identifiedSurgicalPathologyReport'),(297,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenCollectionGroup'),(298,'CONTAINTMENT',2,0,'consentTierStatusCollection'),(299,'ASSOCIATION',2,0,'specimenCollectionGroup'),(300,'CONTAINTMENT',2,0,'specimenEventParametersCollection'),(301,'ASSOCIATION',2,0,'specimenCollectionGroup'),(302,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(303,'ASSOCIATION',2,0,'specimenCollectionGroup'),(304,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(305,'ASSOCIATION',2,0,'specimenCollectionGroup'),(306,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(307,'ASSOCIATION',2,0,'specimenCollectionGroup'),(308,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(309,'ASSOCIATION',2,0,'specimenCollectionGroup'),(310,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(311,'ASSOCIATION',2,0,'specimenCollectionGroup'),(312,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(313,'ASSOCIATION',2,0,'specimenCollectionGroup'),(314,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(315,'ASSOCIATION',2,0,'specimenCollectionGroup'),(316,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(317,'ASSOCIATION',2,0,'specimenCollectionGroup'),(318,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(319,'ASSOCIATION',2,0,'specimenCollectionGroup'),(320,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(321,'ASSOCIATION',2,0,'specimenCollectionGroup'),(322,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(323,'ASSOCIATION',2,0,'specimenCollectionGroup'),(324,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(325,'ASSOCIATION',2,0,'specimenCollectionGroup'),(326,'CONTAINTMENT',2,0,'specimenEventParametersCollection'),(327,'ASSOCIATION',2,0,'specimenCollectionGroup'),(328,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(329,'ASSOCIATION',2,0,'specimenCollectionGroup'),(330,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(331,'ASSOCIATION',2,0,'specimenCollectionGroup'),(332,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(333,'ASSOCIATION',2,0,'specimenCollectionGroup'),(334,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(335,'ASSOCIATION',2,0,'specimenCollectionGroup'),(336,'ASSOCIATION',2,0,'specimenEventParametersCollection'),(347,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenEventParameters'),(348,'ASSOCIATION',1,0,'user'),(359,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpunEventParameters'),(360,'ASSOCIATION',1,0,'user'),(371,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.EmbeddedEventParameters'),(372,'ASSOCIATION',1,0,'user'),(383,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ThawEventParameters'),(384,'ASSOCIATION',1,0,'user'),(395,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.FixedEventParameters'),(396,'ASSOCIATION',1,0,'user'),(401,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.TransferEventParameters'),(402,'ASSOCIATION',1,0,'fromStorageContainer'),(403,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.TransferEventParameters'),(404,'ASSOCIATION',1,0,'toStorageContainer'),(405,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.TransferEventParameters'),(406,'ASSOCIATION',1,0,'user'),(423,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ReceivedEventParameters'),(424,'ASSOCIATION',1,0,'user'),(435,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.CheckInCheckOutEventParameter'),(436,'ASSOCIATION',1,0,'user'),(447,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ReviewEventParameters'),(448,'ASSOCIATION',1,0,'user'),(455,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.MolecularSpecimenReviewParameters'),(456,'ASSOCIATION',1,0,'user'),(463,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.TissueSpecimenReviewEventParameters'),(464,'ASSOCIATION',1,0,'user'),(483,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.CellSpecimenReviewParameters'),(484,'ASSOCIATION',1,0,'user'),(495,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.FluidSpecimenReviewEventParameters'),(496,'ASSOCIATION',1,0,'user'),(507,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DisposalEventParameters'),(508,'ASSOCIATION',1,0,'user'),(509,'CONTAINTMENT',2,0,'specimenEventCollection'),(510,'ASSOCIATION',1,0,'specimen'),(511,'CONTAINTMENT',2,0,'specimenEventCollection'),(512,'ASSOCIATION',1,0,'specimen'),(513,'CONTAINTMENT',2,0,'specimenEventCollection'),(514,'ASSOCIATION',1,0,'specimen'),(515,'CONTAINTMENT',2,0,'specimenEventCollection'),(516,'ASSOCIATION',1,0,'specimen'),(517,'CONTAINTMENT',2,0,'specimenEventCollection'),(518,'ASSOCIATION',1,0,'specimen'),(519,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.ClinicalProcedureEventParameterSet'),(520,'ASSOCIATION',1,0,'user'),(531,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ProcedureEventParameters'),(532,'ASSOCIATION',1,0,'user'),(543,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.FrozenEventParameters'),(544,'ASSOCIATION',1,0,'user'),(545,'CONTAINTMENT',2,0,'specimenEventCollection'),(546,'ASSOCIATION',1,0,'specimen'),(547,'CONTAINTMENT',2,0,'specimenEventCollection'),(548,'ASSOCIATION',1,0,'specimen'),(549,'CONTAINTMENT',2,0,'specimenEventCollection'),(550,'ASSOCIATION',1,0,'specimen'),(551,'CONTAINTMENT',2,0,'specimenEventCollection'),(552,'ASSOCIATION',1,0,'specimen'),(553,'CONTAINTMENT',2,0,'specimenEventCollection'),(554,'ASSOCIATION',1,0,'specimen'),(555,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ReturnEventParameters'),(556,'ASSOCIATION',1,0,'user'),(567,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.CollectionEventParameters'),(568,'ASSOCIATION',1,0,'user'),(569,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport'),(570,'CONTAINTMENT',1,0,'xmlContent'),(571,'ASSOCIATION',1,0,'surgicalPathologyReport'),(572,'ASSOCIATION',2,0,'pathologyReportReviewParameterCollection'),(573,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport'),(574,'ASSOCIATION',1,0,'binaryContent'),(575,'ASSOCIATION',1,0,'surgicalPathologyReport'),(576,'CONTAINTMENT',1,0,'textContent'),(577,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport'),(578,'ASSOCIATION',1,0,'reportSource'),(579,'ASSOCIATION',1,0,'textContent'),(580,'CONTAINTMENT',2,0,'reportSectionCollection'),(581,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport'),(582,'CONTAINTMENT',1,0,'xmlContent'),(583,'ASSOCIATION',1,0,'surgicalPathologyReport'),(584,'ASSOCIATION',2,0,'pathologyReportReviewParameterCollection'),(585,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport'),(586,'ASSOCIATION',1,0,'binaryContent'),(587,'ASSOCIATION',1,0,'surgicalPathologyReport'),(588,'CONTAINTMENT',1,0,'textContent'),(589,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport'),(590,'ASSOCIATION',1,0,'deIdentifiedSurgicalPathologyReport'),(591,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.IdentifiedSurgicalPathologyReport'),(592,'ASSOCIATION',1,0,'reportSource'),(593,'ASSOCIATION',1,0,'deIdentifiedSurgicalPathologyReport'),(594,'CONTAINTMENT',2,0,'conceptReferentCollection'),(595,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.DeidentifiedSurgicalPathologyReport'),(596,'CONTAINTMENT',1,0,'xmlContent'),(597,'ASSOCIATION',1,0,'surgicalPathologyReport'),(598,'ASSOCIATION',2,0,'pathologyReportReviewParameterCollection'),(599,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.DeidentifiedSurgicalPathologyReport'),(600,'ASSOCIATION',1,0,'binaryContent'),(601,'ASSOCIATION',1,0,'deIdentifiedSurgicalPathologyReport'),(602,'ASSOCIATION',1,0,'specimenCollectionGroup'),(603,'ASSOCIATION',1,0,'surgicalPathologyReport'),(604,'CONTAINTMENT',1,0,'textContent'),(605,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.DeidentifiedSurgicalPathologyReport'),(606,'ASSOCIATION',1,0,'reportSource'),(607,'ASSOCIATION',2,0,'conceptReferentCollection'),(608,'ASSOCIATION',1,0,'concept'),(609,'ASSOCIATION',2,0,'conceptReferentCollection'),(610,'ASSOCIATION',1,0,'conceptReferentClassification'),(611,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.pathology.Concept'),(612,'ASSOCIATION',1,0,'semanticType'),(613,'CONTAINTMENT',2,1,'collectionProtocolEventCollection'),(614,'ASSOCIATION',1,0,'collectionProtocol'),(615,'ASSOCIATION',2,0,'abstractSpecimenCollectionGroupCollection'),(616,'ASSOCIATION',1,0,'specimenCollectionSite'),(619,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(620,'ASSOCIATION',1,0,'requestedQuantity'),(621,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(622,'ASSOCIATION',1,0,'requestedQuantity'),(623,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(624,'ASSOCIATION',1,0,'requestedQuantity'),(625,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(626,'ASSOCIATION',1,0,'requestedQuantity'),(627,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(628,'CONTAINTMENT',1,0,'requestedQuantity'),(629,'CONTAINTMENT',2,0,'orderItemCollection'),(630,'ASSOCIATION',1,0,'orderDetails'),(631,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.OrderItem'),(632,'ASSOCIATION',1,0,'distributedItem'),(633,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(634,'ASSOCIATION',1,0,'specimenArray'),(635,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(636,'ASSOCIATION',1,0,'quantity'),(637,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(638,'ASSOCIATION',1,0,'quantity'),(639,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(640,'ASSOCIATION',1,0,'quantity'),(641,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(642,'ASSOCIATION',1,0,'quantity'),(643,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DistributedItem'),(644,'ASSOCIATION',1,0,'quantity'),(645,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributedItem'),(646,'ASSOCIATION',1,0,'specimen'),(647,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributedItem'),(648,'ASSOCIATION',1,0,'specimen'),(649,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributedItem'),(650,'ASSOCIATION',1,0,'specimen'),(651,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributedItem'),(652,'ASSOCIATION',1,0,'specimen'),(653,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DistributedItem'),(654,'ASSOCIATION',1,0,'specimen'),(655,'ASSOCIATION',2,1,'distributedItemCollection'),(656,'ASSOCIATION',1,0,'distribution'),(657,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.Distribution'),(658,'ASSOCIATION',1,0,'distributionProtocol'),(659,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.Distribution'),(660,'ASSOCIATION',1,0,'distributedBy'),(661,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.Distribution'),(662,'ASSOCIATION',1,0,'toSite'),(663,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.OrderDetails'),(664,'ASSOCIATION',2,0,'distributionCollection'),(665,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.OrderDetails'),(666,'ASSOCIATION',1,0,'distributionProtocol'),(667,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(668,'ASSOCIATION',1,0,'requestedQuantity'),(669,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(670,'ASSOCIATION',1,0,'requestedQuantity'),(671,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(672,'ASSOCIATION',1,0,'requestedQuantity'),(673,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(674,'ASSOCIATION',1,0,'requestedQuantity'),(675,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(676,'ASSOCIATION',1,0,'requestedQuantity'),(677,'ASSOCIATION',2,0,'orderItemCollection'),(678,'ASSOCIATION',1,0,'orderDetails'),(679,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenOrderItem'),(680,'ASSOCIATION',1,0,'distributedItem'),(681,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(682,'ASSOCIATION',1,0,'requestedQuantity'),(683,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(684,'ASSOCIATION',1,0,'requestedQuantity'),(685,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(686,'ASSOCIATION',1,0,'requestedQuantity'),(687,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(688,'ASSOCIATION',1,0,'requestedQuantity'),(689,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(690,'ASSOCIATION',1,0,'requestedQuantity'),(691,'ASSOCIATION',2,0,'orderItemCollection'),(692,'ASSOCIATION',1,0,'orderDetails'),(693,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.NewSpecimenOrderItem'),(694,'ASSOCIATION',1,0,'distributedItem'),(695,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(696,'ASSOCIATION',1,0,'requestedQuantity'),(697,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(698,'ASSOCIATION',1,0,'requestedQuantity'),(699,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(700,'ASSOCIATION',1,0,'requestedQuantity'),(701,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(702,'ASSOCIATION',1,0,'requestedQuantity'),(703,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(704,'ASSOCIATION',1,0,'distributedItem'),(705,'ASSOCIATION',2,0,'orderItemCollection'),(706,'ASSOCIATION',1,0,'orderDetails'),(707,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(708,'ASSOCIATION',1,0,'specimenCollectionGroup'),(709,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(710,'ASSOCIATION',1,0,'specimenCollectionGroup'),(711,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(712,'ASSOCIATION',1,0,'specimenCollectionGroup'),(713,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.PathologicalCaseOrderItem'),(714,'ASSOCIATION',1,0,'requestedQuantity'),(715,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(716,'ASSOCIATION',1,0,'requestedQuantity'),(717,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(718,'ASSOCIATION',1,0,'requestedQuantity'),(719,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(720,'ASSOCIATION',1,0,'requestedQuantity'),(721,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(722,'ASSOCIATION',1,0,'requestedQuantity'),(723,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(724,'ASSOCIATION',1,0,'distributedItem'),(725,'ASSOCIATION',2,0,'orderItemCollection'),(726,'ASSOCIATION',1,0,'orderDetails'),(727,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(728,'ASSOCIATION',1,0,'parentSpecimen'),(729,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(730,'ASSOCIATION',1,0,'parentSpecimen'),(731,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(732,'ASSOCIATION',1,0,'parentSpecimen'),(733,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(734,'ASSOCIATION',1,0,'parentSpecimen'),(735,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(736,'ASSOCIATION',1,0,'parentSpecimen'),(737,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem'),(738,'ASSOCIATION',1,0,'requestedQuantity'),(739,'ASSOCIATION',2,0,'collectionProtocolRegistrationCollection'),(740,'ASSOCIATION',1,0,'participant'),(741,'ASSOCIATION',2,0,'collectionProtocolRegistrationCollection'),(742,'ASSOCIATION',1,0,'collectionProtocol'),(743,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.CollectionProtocolRegistration'),(744,'CONTAINTMENT',2,0,'consentTierResponseCollection'),(745,'ASSOCIATION',1,0,'collectionProtocolRegistration'),(746,'ASSOCIATION',2,1,'specimenCollectionGroupCollection'),(747,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.CollectionProtocolRegistration'),(748,'ASSOCIATION',1,0,'consentWitness'),(749,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ConsentTierResponse'),(750,'ASSOCIATION',1,0,'consentTier'),(751,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(752,'ASSOCIATION',1,0,'requestedQuantity'),(753,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(754,'ASSOCIATION',1,0,'requestedQuantity'),(755,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(756,'ASSOCIATION',1,0,'requestedQuantity'),(757,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(758,'ASSOCIATION',1,0,'requestedQuantity'),(759,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(760,'ASSOCIATION',1,0,'requestedQuantity'),(761,'ASSOCIATION',2,0,'orderItemCollection'),(762,'ASSOCIATION',1,0,'orderDetails'),(763,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayOrderItem'),(764,'ASSOCIATION',1,0,'distributedItem'),(765,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(766,'ASSOCIATION',1,0,'requestedQuantity'),(767,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(768,'ASSOCIATION',1,0,'requestedQuantity'),(769,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(770,'ASSOCIATION',1,0,'requestedQuantity'),(771,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(772,'ASSOCIATION',1,0,'requestedQuantity'),(773,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(774,'ASSOCIATION',1,0,'distributedItem'),(775,'ASSOCIATION',1,0,'newSpecimenArrayOrderItem'),(776,'ASSOCIATION',2,0,'specimenOrderItemCollection'),(777,'ASSOCIATION',1,0,'newSpecimenArrayOrderItem'),(778,'ASSOCIATION',2,0,'specimenOrderItemCollection'),(779,'ASSOCIATION',1,0,'newSpecimenArrayOrderItem'),(780,'ASSOCIATION',2,0,'specimenOrderItemCollection'),(781,'ASSOCIATION',1,0,'newSpecimenArrayOrderItem'),(782,'ASSOCIATION',2,0,'specimenOrderItemCollection'),(783,'ASSOCIATION',1,0,'newSpecimenArrayOrderItem'),(784,'ASSOCIATION',2,0,'specimenOrderItemCollection'),(785,'ASSOCIATION',2,0,'orderItemCollection'),(786,'ASSOCIATION',1,0,'orderDetails'),(787,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(788,'ASSOCIATION',1,0,'specimenArrayType'),(789,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem'),(790,'ASSOCIATION',1,0,'requestedQuantity'),(791,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(792,'ASSOCIATION',1,0,'requestedQuantity'),(793,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(794,'ASSOCIATION',1,0,'requestedQuantity'),(795,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(796,'ASSOCIATION',1,0,'specimen'),(797,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(798,'ASSOCIATION',1,0,'specimen'),(799,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(800,'ASSOCIATION',1,0,'specimen'),(801,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(802,'ASSOCIATION',1,0,'specimen'),(803,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(804,'ASSOCIATION',1,0,'specimen'),(805,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(806,'ASSOCIATION',1,0,'distributedItem'),(807,'ASSOCIATION',2,0,'orderItemCollection'),(808,'ASSOCIATION',1,0,'orderDetails'),(809,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(810,'ASSOCIATION',1,0,'requestedQuantity'),(811,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(812,'ASSOCIATION',1,0,'requestedQuantity'),(813,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem'),(814,'ASSOCIATION',1,0,'requestedQuantity'),(815,'CONTAINTMENT',2,0,'externalIdentifierCollection'),(816,'ASSOCIATION',1,0,'specimen'),(817,'CONTAINTMENT',2,0,'externalIdentifierCollection'),(818,'ASSOCIATION',1,0,'specimen'),(819,'CONTAINTMENT',2,0,'externalIdentifierCollection'),(820,'ASSOCIATION',1,0,'specimen'),(821,'CONTAINTMENT',2,0,'externalIdentifierCollection'),(822,'ASSOCIATION',1,0,'specimen'),(823,'CONTAINTMENT',2,0,'externalIdentifierCollection'),(824,'ASSOCIATION',1,0,'specimen'),(825,'ASSOCIATION',2,0,'auditEventQueryLogCollection'),(826,'ASSOCIATION',1,0,'auditEvent'),(827,'ASSOCIATION',1,0,'auditEvent'),(828,'ASSOCIATION',2,1,'auditEventLogCollection'),(829,'ASSOCIATION',2,0,'quarantineEventParameterCollection'),(830,'ASSOCIATION',1,0,'deIdentifiedSurgicalPathologyReport'),(831,'CONTAINTMENT',2,1,'specimenRequirementCollection'),(832,'ASSOCIATION',2,1,'distributionProtocolCollection'),(833,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenRequirement'),(834,'ASSOCIATION',1,0,'quantity'),(835,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenRequirement'),(836,'ASSOCIATION',1,0,'quantity'),(837,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenRequirement'),(838,'ASSOCIATION',1,0,'quantity'),(839,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenRequirement'),(840,'ASSOCIATION',1,0,'quantity'),(841,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenRequirement'),(842,'CONTAINTMENT',1,0,'quantity'),(843,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ParticipantMedicalIdentifier'),(844,'ASSOCIATION',1,0,'site'),(845,'CONTAINTMENT',2,0,'participantMedicalIdentifierCollection'),(846,'ASSOCIATION',1,0,'participant'),(847,'CONTAINTMENT',2,0,'specimenArrayContentCollection'),(848,'ASSOCIATION',1,0,'specimenArray'),(849,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(850,'ASSOCIATION',1,0,'specimen'),(851,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(852,'ASSOCIATION',1,0,'initialQuantity'),(853,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(854,'ASSOCIATION',1,0,'initialQuantity'),(855,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(856,'ASSOCIATION',1,0,'initialQuantity'),(857,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(858,'ASSOCIATION',1,0,'initialQuantity'),(859,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(860,'ASSOCIATION',1,0,'initialQuantity'),(861,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(862,'ASSOCIATION',1,0,'specimen'),(863,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(864,'ASSOCIATION',1,0,'specimen'),(865,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(866,'ASSOCIATION',1,0,'specimen'),(867,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.SpecimenArrayContent'),(868,'ASSOCIATION',1,0,'specimen'),(869,'ASSOCIATION',2,0,'biohazardCollection'),(870,'ASSOCIATION',2,0,'specimenCollection'),(871,'ASSOCIATION',2,0,'biohazardCollection'),(872,'ASSOCIATION',2,0,'specimenCollection'),(873,'ASSOCIATION',2,0,'biohazardCollection'),(874,'ASSOCIATION',2,0,'specimenCollection'),(875,'ASSOCIATION',2,0,'biohazardCollection'),(876,'ASSOCIATION',2,0,'specimenCollection'),(877,'ASSOCIATION',2,0,'biohazardCollection'),(878,'ASSOCIATION',2,0,'specimenCollection'),(879,'ASSOCIATION',2,1,'auditEventDetailsCollcetion'),(880,'ASSOCIATION',1,0,'auditEventLog'),(881,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(882,'ASSOCIATION',1,0,'requestedQuantity'),(883,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(884,'ASSOCIATION',1,0,'requestedQuantity'),(885,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(886,'ASSOCIATION',1,0,'requestedQuantity'),(887,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(888,'ASSOCIATION',1,0,'requestedQuantity'),(889,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(890,'ASSOCIATION',1,0,'requestedQuantity'),(891,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(892,'ASSOCIATION',1,0,'specimenArray'),(893,'ASSOCIATION',2,0,'orderItemCollection'),(894,'ASSOCIATION',1,0,'orderDetails'),(895,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.ExistingSpecimenArrayOrderItem'),(896,'ASSOCIATION',1,0,'distributedItem'),(897,'ASSOCIATION',2,0,'childCollectionProtocolCollection'),(898,'ASSOCIATION',1,0,'parentCollectionProtocol'),(899,'ASSOCIATION',2,0,'childCollectionProtocolCollection'),(900,'ASSOCIATION',1,0,'parentCollectionProtocol'),(901,'CONTAINTMENT',1,1,'environmentalExposureHealthAnnotation'),(902,'CONTAINTMENT',100,1,'durationCollection'),(903,'ASSOCIATION',100,1,'treatmentOrderCollection'),(904,'ASSOCIATION',1,1,'treatmentRegimen'),(905,'CONTAINTMENT',1,1,'deprecatedAnnotation2'),(906,'CONTAINTMENT',100,0,'chemoRXAnnotationCollection'),(907,'CONTAINTMENT',1,1,'deprecatedAnnotation2'),(908,'CONTAINTMENT',100,0,'radRXAnnotationCollection'),(909,'CONTAINTMENT',1,1,'treatmentAnnotation'),(910,'CONTAINTMENT',100,0,'durationCollection'),(911,'CONTAINTMENT',1,1,'radRXAnnotation'),(912,'CONTAINTMENT',100,1,'durationCollection'),(913,'CONTAINTMENT',1,1,'chemoRXAnnotation'),(914,'CONTAINTMENT',100,1,'durationCollection'),(915,'ASSOCIATION',1,1,'familyHistoryAnnotation'),(916,'ASSOCIATION',100,1,'generalHealthDiagnosisCollection'),(917,'CONTAINTMENT',1,0,'844_1'),(918,'CONTAINTMENT',100,0,'844_1'),(919,'CONTAINTMENT',1,0,'844_2'),(920,'CONTAINTMENT',100,0,'844_2'),(921,'CONTAINTMENT',1,0,'844_3'),(922,'CONTAINTMENT',100,0,'844_3'),(923,'CONTAINTMENT',1,0,'844_5'),(924,'CONTAINTMENT',100,0,'844_5'),(925,'CONTAINTMENT',1,0,'844_6'),(926,'CONTAINTMENT',100,0,'844_6'),(927,'CONTAINTMENT',1,0,'844_7'),(928,'CONTAINTMENT',100,0,'844_7'),(929,'CONTAINTMENT',1,0,'844_8'),(930,'CONTAINTMENT',100,0,'844_8'),(931,'CONTAINTMENT',1,0,'844_9'),(932,'CONTAINTMENT',100,0,'844_9'),(933,'CONTAINTMENT',1,0,'844_10'),(934,'CONTAINTMENT',100,0,'844_10'),(935,'CONTAINTMENT',1,0,'844_13'),(936,'CONTAINTMENT',100,0,'844_13'),(937,'CONTAINTMENT',1,0,'844_12'),(938,'CONTAINTMENT',100,0,'844_12'),(939,'CONTAINTMENT',1,0,'844_11'),(940,'CONTAINTMENT',100,0,'844_11'),(941,'CONTAINTMENT',1,0,'844_14'),(942,'CONTAINTMENT',100,0,'844_14'),(943,'CONTAINTMENT',1,0,'844_15'),(944,'CONTAINTMENT',100,0,'844_15'),(945,'CONTAINTMENT',1,0,'844_16'),(946,'CONTAINTMENT',100,0,'844_16'),(947,'CONTAINTMENT',1,1,'additionalPathologicFinding'),(948,'CONTAINTMENT',100,0,'detailsCollection'),(949,'ASSOCIATION',1,1,'specimenBaseSolidTissuePathologyAnnotation'),(950,'ASSOCIATION',100,0,'additionalPathologicFindingCollection'),(951,'CONTAINTMENT',1,1,'specimenBaseSolidTissuePathologyAnnotation'),(952,'CONTAINTMENT',100,0,'histologicGrade'),(953,'CONTAINTMENT',1,1,'specimenBaseSolidTissuePathologyAnnotation'),(954,'CONTAINTMENT',1,0,'invasion'),(955,'CONTAINTMENT',1,1,'specimenBaseSolidTissuePathologyAnnotation'),(956,'CONTAINTMENT',100,0,'histologicTypeCollection'),(957,'CONTAINTMENT',1,1,'histologicType'),(958,'CONTAINTMENT',100,0,'histologicVariantTypeCollection'),(963,'CONTAINTMENT',1,0,'4_21'),(964,'CONTAINTMENT',100,0,'4_21'),(965,'CONTAINTMENT',1,0,'4_22'),(966,'CONTAINTMENT',100,0,'4_22'),(967,'CONTAINTMENT',1,0,'4_23'),(968,'CONTAINTMENT',100,0,'4_23'),(969,'CONTAINTMENT',1,0,'4_24'),(970,'CONTAINTMENT',100,0,'4_24'),(971,'CONTAINTMENT',1,0,'4_25'),(972,'CONTAINTMENT',100,0,'4_25'),(973,'CONTAINTMENT',1,0,'4_26'),(974,'CONTAINTMENT',100,0,'4_26'),(975,'CONTAINTMENT',1,0,'4_27'),(976,'CONTAINTMENT',100,0,'4_27'),(977,'CONTAINTMENT',1,0,'4_28'),(978,'CONTAINTMENT',100,0,'4_28'),(979,'CONTAINTMENT',1,0,'4_29'),(980,'CONTAINTMENT',100,0,'4_29'),(981,'ASSOCIATION',100,1,NULL),(982,'ASSOCIATION',1,1,'AlcoholHealthAnnotation'),(983,'CONTAINTMENT',1,1,'SpecimenBaseSolidTissuePathologyAnnotation'),(984,'CONTAINTMENT',100,1,'additionalFinding'),(985,'CONTAINTMENT',1,1,NULL),(986,'CONTAINTMENT',100,1,'HistologicVariantType'),(987,'CONTAINTMENT',1,1,NULL),(988,'CONTAINTMENT',100,1,'Details'),(989,'CONTAINTMENT',1,1,NULL),(990,'CONTAINTMENT',1,1,'Gleason Score'),(991,'CONTAINTMENT',1,1,NULL),(992,'CONTAINTMENT',1,1,'Nottingham Histologic Score'),(993,'CONTAINTMENT',1,1,NULL),(994,'CONTAINTMENT',100,1,'General Health Diagnosis'),(995,'CONTAINTMENT',1,1,NULL),(996,'CONTAINTMENT',100,1,'Treatment Order'),(997,'CONTAINTMENT',1,1,'TreatmentOrder'),(998,'CONTAINTMENT',100,1,'radiationTherapy'),(999,'CONTAINTMENT',1,1,NULL),(1000,'CONTAINTMENT',100,1,'Chemotherapy'),(1001,'CONTAINTMENT',1,1,NULL),(1002,'CONTAINTMENT',100,1,'Duration'),(1003,'CONTAINTMENT',1,1,'basePathologyAnnotation'),(1004,'CONTAINTMENT',100,0,'additionalFinding'),(1005,'CONTAINTMENT',1,1,'basePathologyAnnotation'),(1006,'CONTAINTMENT',1,1,'histologicTypeCollection'),(1007,'CONTAINTMENT',1,1,'histologicType'),(1008,'CONTAINTMENT',100,0,'histologicVariantTypeCollection'),(1009,'CONTAINTMENT',1,1,'additionalFinding'),(1010,'CONTAINTMENT',100,0,'detailsCollection'),(1011,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1012,'CONTAINTMENT',100,0,'tumorTissueSite'),(1013,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1014,'CONTAINTMENT',1,0,'pathologicStaging'),(1015,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1016,'CONTAINTMENT',100,0,'histologicGradeCollection'),(1017,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1018,'CONTAINTMENT',1,0,'tumorSize'),(1019,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1020,'CONTAINTMENT',1,0,'invasion'),(1021,'CONTAINTMENT',1,1,'pathologicStaging'),(1022,'CONTAINTMENT',1,0,'primaryTumorStage'),(1023,'CONTAINTMENT',1,1,'pathologicStaging'),(1024,'CONTAINTMENT',1,0,'distantMetastasis'),(1025,'CONTAINTMENT',1,1,'pathologicStaging'),(1026,'CONTAINTMENT',1,0,'regionalLymphNode'),(1027,'CONTAINTMENT',1,1,'distantMetastasis'),(1028,'CONTAINTMENT',100,0,'metastasisTissueSite'),(1029,'CONTAINTMENT',1,1,'tumorTissueSite'),(1030,'CONTAINTMENT',100,0,'tissueSide'),(1031,'CONTAINTMENT',1,1,'lungResectionBasedPathologyAnnotation'),(1032,'CONTAINTMENT',100,0,'lungResectionMargin'),(1033,'CONTAINTMENT',1,1,'lungResectionBasedPathologyAnnotation'),(1034,'CONTAINTMENT',100,0,'directExtensionOfTumorCollection'),(1035,'CONTAINTMENT',1,1,'lungResectionMargin'),(1036,'CONTAINTMENT',1,0,'uninvolvedMarginCollection'),(1037,'CONTAINTMENT',1,1,'prostatePathologyAnnotation'),(1038,'CONTAINTMENT',1,0,'gleasonScore'),(1039,'CONTAINTMENT',1,1,'kidneyNephrectomyMargin'),(1040,'CONTAINTMENT',100,0,'marginLocationCollection'),(1041,'CONTAINTMENT',1,1,'baseHaematologyPathologyAnnotation'),(1042,'CONTAINTMENT',1,0,'cytogenetics'),(1043,'CONTAINTMENT',1,1,'baseHaematologyPathologyAnnotation'),(1044,'CONTAINTMENT',1,0,'immunoPhenotyping'),(1045,'CONTAINTMENT',1,1,'colorectalPathologyAnnotation'),(1046,'CONTAINTMENT',1,0,'size'),(1047,'CONTAINTMENT',1,1,'deepMelanomaMargin'),(1048,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1049,'CONTAINTMENT',1,1,'excisionalBiopsyColorectalDeepMargin'),(1050,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1051,'CONTAINTMENT',1,1,'pancreasMargin'),(1052,'CONTAINTMENT',100,0,'involved MarginCollection'),(1053,'CONTAINTMENT',1,1,'pancreasMargin'),(1054,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1055,'CONTAINTMENT',1,1,'uninvolvedMargin'),(1056,'CONTAINTMENT',100,0,'carcinomaInSituStatus'),(1057,'CONTAINTMENT',1,1,'excisionalBiopsyBasedColorectalPathologyAnnotation'),(1058,'CONTAINTMENT',100,0,'deepMarginCollection'),(1059,'CONTAINTMENT',1,1,'excisionalBiopsyBasedColorectalPathologyAnnotation'),(1060,'CONTAINTMENT',100,0,'lateralOrMucosalMarginCollection'),(1061,'CONTAINTMENT',1,1,'excisionalBiopsyBasedColorectalPathologyAnnotation'),(1062,'CONTAINTMENT',1,0,'distanceOfInvasiveCarcinoma'),(1063,'CONTAINTMENT',1,1,'excisionalBiopsyBasedColorectalPathologyAnnotation'),(1064,'CONTAINTMENT',1,0,'polypConfiguration'),(1065,'CONTAINTMENT',1,1,'excisionalBiopsyBasedColorectalPathologyAnnotation'),(1066,'CONTAINTMENT',1,0,'distanceOfAdenoma'),(1067,'CONTAINTMENT',1,1,'excisionalBiopsyColorectalLateralOrMucosalMargin'),(1068,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1069,'CONTAINTMENT',1,1,'breastMargin'),(1070,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1071,'CONTAINTMENT',1,1,'breastMargin'),(1072,'CONTAINTMENT',100,0,'involvedMarginCollection'),(1073,'CONTAINTMENT',1,1,'radicalProstatectomyPathologyAnnotation'),(1074,'CONTAINTMENT',1,0,'extraprostaticExtension'),(1075,'CONTAINTMENT',1,1,'radicalProstatectomyPathologyAnnotation'),(1076,'CONTAINTMENT',1,0,'radicalProstatectomyMargin'),(1077,'CONTAINTMENT',1,1,'radicalProstatectomyMargin'),(1078,'CONTAINTMENT',100,0,'marginLocationCollection'),(1079,'CONTAINTMENT',1,1,'extraprostaticExtension'),(1080,'CONTAINTMENT',100,0,'tissueSiteCollection'),(1081,'CONTAINTMENT',1,1,'resectionColorectalMesentricMargin'),(1082,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1083,'CONTAINTMENT',1,1,'pancreasePathologyAnnotation'),(1084,'CONTAINTMENT',1,0,'pancreaseMargin'),(1085,'CONTAINTMENT',1,1,'pancreasePathologyAnnotation'),(1086,'CONTAINTMENT',100,0,'otherResectedOrgans'),(1087,'CONTAINTMENT',1,1,'resectionBasedColorectalPathologyAnnotation'),(1088,'CONTAINTMENT',1,0,'radialMargin'),(1089,'CONTAINTMENT',1,1,'resectionBasedColorectalPathologyAnnotation'),(1090,'CONTAINTMENT',1,0,'mesentricMargin'),(1091,'CONTAINTMENT',1,1,'resectionBasedColorectalPathologyAnnotation'),(1092,'CONTAINTMENT',100,0,'distalMarginCollection'),(1093,'CONTAINTMENT',1,1,'resectionBasedColorectalPathologyAnnotation'),(1094,'CONTAINTMENT',100,0,'proximalMarginCollection'),(1095,'CONTAINTMENT',1,1,'resectionColorectalProximalMargin'),(1096,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1097,'CONTAINTMENT',1,1,'resectionColorectalDistalMargin'),(1098,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1099,'CONTAINTMENT',1,1,'resectionColorectalRadialMargin'),(1100,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1101,'CONTAINTMENT',1,1,'melanomaPathologyAnnotation'),(1102,'CONTAINTMENT',100,0,'lateralMarginCollection'),(1103,'CONTAINTMENT',1,1,'melanomaPathologyAnnotation'),(1104,'CONTAINTMENT',100,0,'satelliteNoduleCollection'),(1105,'CONTAINTMENT',1,1,'melanomaPathologyAnnotation'),(1106,'CONTAINTMENT',100,0,'deepMarginCollection'),(1107,'CONTAINTMENT',1,1,'lateralMelanomaMargin'),(1108,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1109,'CONTAINTMENT',1,1,'breastPathologyAnnotation'),(1110,'CONTAINTMENT',100,0,'microcalcificationCollection'),(1111,'CONTAINTMENT',1,1,'breastPathologyAnnotation'),(1112,'CONTAINTMENT',1,0,'size'),(1113,'CONTAINTMENT',1,1,'breastPathologyAnnotation'),(1114,'CONTAINTMENT',100,0,'breastMarginCollection'),(1115,'CONTAINTMENT',1,1,'breast Pathology Annotation'),(1116,'CONTAINTMENT',1,0,'nottinghamHistologicScore'),(1117,'CONTAINTMENT',1,1,'LocalExcisionColorectalLateralMargin'),(1118,'CONTAINTMENT',100,0,'uninvolvedMarginCollection'),(1119,'CONTAINTMENT',1,1,'cnsPathologyAnnotation'),(1120,'CONTAINTMENT',1,0,'specimenSize'),(1121,'CONTAINTMENT',1,1,'cnsPathologyAnnotation'),(1122,'CONTAINTMENT',1,0,'cnsMargin'),(1123,'CONTAINTMENT',1,1,'cnsMargin'),(1124,'CONTAINTMENT',100,0,'marginLocationCollection'),(1125,'CONTAINTMENT',1,1,'localExcisionColorectalDeepMargin'),(1126,'CONTAINTMENT',1,0,'uninvolvedMargin'),(1127,'CONTAINTMENT',1,1,'localExcisionBasedColorectalPathologyAnnotation'),(1128,'CONTAINTMENT',1,0,'specimenIntegrity'),(1129,'CONTAINTMENT',1,1,'localExcisionBasedColorectalPathologyAnnotation'),(1130,'CONTAINTMENT',100,0,'localExcisionColorectalDeepMargin'),(1131,'CONTAINTMENT',1,1,'localExcisionBasedColorectalPathologyAnnotation'),(1132,'CONTAINTMENT',1,0,'distanceOfTumor'),(1133,'CONTAINTMENT',1,1,'localExcisionBasedColorectalPathologyAnnotation'),(1134,'CONTAINTMENT',100,0,'localExcisionColorectalLateralMargin'),(1135,'CONTAINTMENT',1,1,'kidneyNephrectomyBasedPathologyAnnotation'),(1136,'CONTAINTMENT',1,0,'kidneyNephrectomyMargin'),(1137,'CONTAINTMENT',1,1,'kidneyNephrectomyBasedPathologyAnnotation'),(1138,'CONTAINTMENT',100,0,'macroscopicExtentOfTumor'),(1139,'CONTAINTMENT',1,0,'379_42'),(1140,'CONTAINTMENT',100,0,'379_42'),(1141,'CONTAINTMENT',1,0,'379_45'),(1142,'CONTAINTMENT',100,0,'379_45'),(1143,'CONTAINTMENT',1,0,'379_56'),(1144,'CONTAINTMENT',100,0,'379_56'),(1145,'CONTAINTMENT',1,0,'379_58'),(1146,'CONTAINTMENT',100,0,'379_58'),(1147,'CONTAINTMENT',1,0,'379_63'),(1148,'CONTAINTMENT',100,0,'379_63'),(1149,'CONTAINTMENT',1,0,'379_64'),(1150,'CONTAINTMENT',100,0,'379_64'),(1151,'CONTAINTMENT',1,0,'379_65'),(1152,'CONTAINTMENT',100,0,'379_65'),(1153,'CONTAINTMENT',1,0,'379_66'),(1154,'CONTAINTMENT',100,0,'379_66'),(1155,'CONTAINTMENT',1,0,'379_72'),(1156,'CONTAINTMENT',100,0,'379_72'),(1157,'CONTAINTMENT',1,0,'379_73'),(1158,'CONTAINTMENT',100,0,'379_73'),(1159,'CONTAINTMENT',1,0,'379_74'),(1160,'CONTAINTMENT',100,0,'379_74'),(1161,'CONTAINTMENT',1,0,'379_78'),(1162,'CONTAINTMENT',100,0,'379_78'),(1163,'CONTAINTMENT',1,0,'379_79'),(1164,'CONTAINTMENT',100,0,'379_79'),(1165,'CONTAINTMENT',1,0,'379_80'),(1166,'CONTAINTMENT',100,0,'379_80'),(1167,'CONTAINTMENT',1,0,'379_84'),(1168,'CONTAINTMENT',100,0,'379_84'),(1169,'CONTAINTMENT',1,0,'379_89'),(1170,'CONTAINTMENT',100,0,'379_89'),(1171,'CONTAINTMENT',1,0,'379_92'),(1172,'CONTAINTMENT',100,0,'379_92'),(1173,'CONTAINTMENT',1,0,'379_98'),(1174,'CONTAINTMENT',100,0,'379_98'),(1175,'CONTAINTMENT',1,0,'379_99'),(1176,'CONTAINTMENT',100,0,'379_99'),(1177,'CONTAINTMENT',1,0,'379_105'),(1178,'CONTAINTMENT',100,0,'379_105'),(1179,'CONTAINTMENT',1,0,'379_110'),(1180,'CONTAINTMENT',100,0,'379_110'),(1181,'CONTAINTMENT',1,0,'379_116'),(1182,'CONTAINTMENT',100,0,'379_116'),(1183,'CONTAINTMENT',1,1,'BasePathologyAnnotation'),(1184,'CONTAINTMENT',100,1,'additionalFinding'),(1185,'CONTAINTMENT',1,1,NULL),(1186,'CONTAINTMENT',100,1,'Histologic Type'),(1187,'CONTAINTMENT',1,1,NULL),(1188,'CONTAINTMENT',100,1,'Histologic Variant Type'),(1189,'CONTAINTMENT',1,1,NULL),(1190,'CONTAINTMENT',100,1,'Details'),(1191,'CONTAINTMENT',1,1,NULL),(1192,'CONTAINTMENT',1,1,'Primary Tumor Stage'),(1193,'CONTAINTMENT',1,1,NULL),(1194,'CONTAINTMENT',100,1,'Metastasis Tissue Site'),(1195,'CONTAINTMENT',1,1,NULL),(1196,'CONTAINTMENT',100,1,'Tissue Side'),(1205,'CONTAINTMENT',1,1,NULL),(1206,'CONTAINTMENT',100,1,'GeneralHealthDiagnosis'),(1207,'CONTAINTMENT',1,1,NULL),(1208,'CONTAINTMENT',100,1,'TreatmentOrder'),(1209,'CONTAINTMENT',1,1,'TreatmentAnnotation'),(1210,'CONTAINTMENT',100,1,'Duration'),(1211,'CONTAINTMENT',1,1,'EnvironmentalExposuresHealthAnnotation'),(1212,'CONTAINTMENT',100,1,'Duration'),(1213,'CONTAINTMENT',1,1,'SpecimenBaseSolidTissuePathologyAnnotation'),(1214,'CONTAINTMENT',100,1,'HistologicType'),(1215,'CONTAINTMENT',1,1,'AdditionalFinding'),(1216,'CONTAINTMENT',100,1,'Details'),(1217,'CONTAINTMENT',1,1,'HistologicType'),(1218,'CONTAINTMENT',100,1,'HistologicVariantType'),(1219,'CONTAINTMENT',1,1,'prostateSpecimenPathologyAnnotation'),(1220,'CONTAINTMENT',1,1,'prostateSpecimenGleasonScore'),(1221,'CONTAINTMENT',1,1,'breastSpecimenPathologyAnnotation'),(1222,'CONTAINTMENT',1,1,'breastSpecimenNottinghamHistologicScore'),(1223,'CONTAINTMENT',1,1,NULL),(1224,'CONTAINTMENT',100,1,'HistologicType'),(1225,'CONTAINTMENT',1,1,NULL),(1226,'CONTAINTMENT',1,1,'HistologicVariantType'),(1227,'CONTAINTMENT',1,1,'AdditionalFinding'),(1228,'CONTAINTMENT',100,1,'Details'),(1229,'CONTAINTMENT',1,1,'BaseSolidTissuePathologyAnnotation'),(1230,'CONTAINTMENT',100,1,'HistologicGrade'),(1231,'CONTAINTMENT',1,1,'PathologicalStaging'),(1232,'CONTAINTMENT',1,1,'PrimaryTumorStage'),(1233,'CONTAINTMENT',1,1,'DistantMetastasis'),(1234,'CONTAINTMENT',100,1,'MetastasisTissueSite'),(1235,'CONTAINTMENT',1,1,'TumorTissueSite'),(1236,'CONTAINTMENT',100,1,'TissueSide'),(1237,'CONTAINTMENT',1,1,'ProstatePathologyAnnotation'),(1238,'CONTAINTMENT',1,1,'GleasonScore'),(1247,'CONTAINTMENT',1,1,'PancreasMargin'),(1248,'CONTAINTMENT',1,1,'PancreasMarginUninvolvedByInvasiveCarcinoma'),(1249,'CONTAINTMENT',1,1,'PancreasMargin'),(1250,'CONTAINTMENT',100,1,'PancreasMarginInvolvedByInvasiveCarcinoma'),(1251,'CONTAINTMENT',1,1,'PancreasMarginUninvolvedByInvasiveCarcinoma'),(1252,'CONTAINTMENT',100,1,'CarcinomaInSituStatus'),(1253,'CONTAINTMENT',1,1,'LungResectionBasedPathologyAnnotation'),(1254,'CONTAINTMENT',100,1,'LungResectionMargin'),(1255,'CONTAINTMENT',1,1,NULL),(1256,'CONTAINTMENT',100,1,'DirectExtensionOfTumor'),(1257,'CONTAINTMENT',1,1,'LungResectionMargin'),(1258,'CONTAINTMENT',1,1,'LungResectionMarginsUninvolved'),(1259,'CONTAINTMENT',1,1,'KidneyNephrectomyBasedPathologyAnnotation'),(1260,'CONTAINTMENT',1,1,'KidneyNephrectomyMargin'),(1261,'CONTAINTMENT',1,1,'KidneyNephrectomyBasedPathologyAnnotation'),(1262,'CONTAINTMENT',100,1,'MacroscopicExtentOfTumor'),(1263,'CONTAINTMENT',1,1,'KidneyNephrectomyMargin'),(1264,'CONTAINTMENT',100,1,'KidneyMarginLocation'),(1265,'CONTAINTMENT',1,1,'CNSPathologyAnnotation'),(1266,'CONTAINTMENT',1,1,'SpecimenSize'),(1267,'CONTAINTMENT',1,1,'CNSMargin'),(1268,'CONTAINTMENT',100,1,'CNSMarginLocation'),(1269,'CONTAINTMENT',1,1,'MelanomaPathologyAnnotation'),(1270,'CONTAINTMENT',100,1,'SatelliteNodule'),(1271,'CONTAINTMENT',1,1,'DeepMelanomaMargin'),(1272,'CONTAINTMENT',1,1,'UninvolvedMelanomaMargin'),(1273,'CONTAINTMENT',1,1,'LateralMelanomaMargin'),(1274,'CONTAINTMENT',1,1,'UninvolvedMelanomaMargin'),(1275,'CONTAINTMENT',1,1,'BreastPathologyAnnotation'),(1276,'CONTAINTMENT',1,1,'NottinghamHistologicScore'),(1277,'CONTAINTMENT',1,1,'BreastPathologyAnnotation'),(1278,'CONTAINTMENT',1,1,'SizeOfSpecimen'),(1279,'CONTAINTMENT',1,1,'BreastPathologyAnnotation'),(1280,'CONTAINTMENT',1,1,'SizeOfInvasiveCarcinoma'),(1281,'CONTAINTMENT',1,1,'BreastPathologyAnnotation'),(1282,'CONTAINTMENT',100,1,'Microcalcification'),(1283,'CONTAINTMENT',1,1,'BreastMargin'),(1284,'CONTAINTMENT',1,1,'BreastMarginUninvolved'),(1285,'CONTAINTMENT',1,1,'ColorectalPathologyAnnotation'),(1286,'CONTAINTMENT',1,1,'PolypSize'),(1287,'CONTAINTMENT',1,1,'LocalExcisionBasedColorectalPathologyAnnotation'),(1288,'CONTAINTMENT',1,1,'SpecimenIntegrity'),(1289,'CONTAINTMENT',1,1,'LocalExcisionColorectalDeepMargin'),(1290,'CONTAINTMENT',1,1,'ColorectalLocalExcisionMarginUninvolved'),(1291,'CONTAINTMENT',1,1,'ExcisionalBiopsyBasedColorectalPathologyAnnotation'),(1292,'CONTAINTMENT',1,1,'DistanceOfInvasiveCarcinoma'),(1293,'CONTAINTMENT',1,1,'ExcisionalBiopsyBasedColorectalPathologyAnnotation'),(1294,'CONTAINTMENT',1,1,'DistanceOfAdenoma'),(1295,'CONTAINTMENT',1,1,'ExcisionalBiopsyBasedColorectalPathologyAnnotation'),(1296,'CONTAINTMENT',1,1,'PolypConfiguration'),(1297,'CONTAINTMENT',1,1,'ExcisionalBiopsyColorectalDeepMargin'),(1298,'CONTAINTMENT',1,1,'ExcionalBiopsyMarginUninvolved'),(1299,'CONTAINTMENT',1,1,'ExcisionalBiopsyColorectalLateralOrMucosalMargin'),(1300,'CONTAINTMENT',1,1,'ExcionalBiopsyMarginUninvolved'),(1301,'CONTAINTMENT',1,1,'ResectionBasedColorectalPathologyAnnotation'),(1302,'CONTAINTMENT',100,1,'ResectionColorectalMesentricMargin'),(1303,'CONTAINTMENT',1,1,'ResectionBasedColorectalPathologyAnnotation'),(1304,'CONTAINTMENT',100,1,'ResectionColorectalRadialMargin'),(1305,'CONTAINTMENT',1,1,'TreatmentRegimen'),(1306,'CONTAINTMENT',100,1,'TreatmentOrder'),(1307,'CONTAINTMENT',1,1,'TreatmentOrder'),(1308,'CONTAINTMENT',100,1,'Chemotherapy'),(1309,'CONTAINTMENT',1,1,'BasePathologyAnnotation'),(1310,'CONTAINTMENT',100,1,'HistologicType'),(1311,'CONTAINTMENT',1,1,'HistologicType'),(1312,'CONTAINTMENT',100,1,'HistologicVariantType'),(1313,'CONTAINTMENT',1,1,'FamilyHistoryAnnotation'),(1314,'CONTAINTMENT',100,1,'GeneralHealthDiagnosis'),(1315,'CONTAINTMENT',1,1,'LungResectionBasedPathologyAnnotation'),(1316,'CONTAINTMENT',100,1,'DirectExtensionOfTumor'),(1317,'CONTAINTMENT',1,1,'BaseHaematologyPathologyAnnotation'),(1318,'CONTAINTMENT',1,1,'Cytogenetics'),(1319,'CONTAINTMENT',1,1,'BaseHaematologyPathologyAnnotation'),(1320,'CONTAINTMENT',1,1,'Cytogenetics'),(1321,'CONTAINTMENT',1,1,'RadicalProstatectomyPathologyAnnotation'),(1322,'CONTAINTMENT',1,1,'ExtraprostaticExtension'),(1323,'CONTAINTMENT',1,1,'RadicalProstatectomyMargin'),(1324,'CONTAINTMENT',100,1,'ProstateMarginLocation'),(1325,'CONTAINTMENT',1,1,'ExtraprostaticExtension'),(1326,'CONTAINTMENT',100,1,'ExtraprostaticExtensionTissueSites'),(1327,'CONTAINTMENT',1,1,'baseSolidTissuePathologyAnnotation'),(1328,'CONTAINTMENT',1,1,'PathologicalStaging'),(1329,'CONTAINTMENT',1,1,'pathologicalStaging'),(1330,'CONTAINTMENT',1,1,'DistantMetastasis'),(1331,'CONTAINTMENT',1,1,'distantMetastasis'),(1332,'CONTAINTMENT',100,1,'MetastasisTissueSite'),(1333,'CONTAINTMENT',1,1,'radicalProstatectomyPathologyAnnotation'),(1334,'CONTAINTMENT',1,1,'RadicalProstatectomyMargin'),(1335,'CONTAINTMENT',1,1,'radicalProstatectomyMargin'),(1336,'CONTAINTMENT',100,1,'ProstateMarginLocation'),(1337,'CONTAINTMENT',1,1,'localExcisionBasedColorectalPathologyAnnotation'),(1338,'CONTAINTMENT',100,1,'LocalExcisionColorectalLateralMargin'),(1339,'CONTAINTMENT',1,1,'localExcisionColorectalLateralMargin'),(1340,'CONTAINTMENT',1,1,'ColorectalLocalExcisionMarginUninvolved'),(1341,'CONTAINTMENT',2,0,'raceCollection'),(1342,'ASSOCIATION',1,0,'participant'),(1343,'CONTAINTMENT',2,0,'specimenEventCollection'),(1344,'ASSOCIATION',1,0,'abstractSpecimen'),(1345,'CONTAINTMENT',2,0,'specimenRequirementCollection'),(1346,'ASSOCIATION',1,0,'CollectionProtocolEvent'),(1347,'ASSOCIATION',2,0,'specimenCollection'),(1348,'ASSOCIATION',1,0,'specimenRequirement'),(1349,'ASSOCIATION',1,0,'senderContactPerson'),(1350,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment'),(1351,'ASSOCIATION',1,0,'receiverContactPerson'),(1352,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment'),(1353,'ASSOCIATION',1,0,'senderSite'),(1354,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment'),(1355,'ASSOCIATION',1,0,'receiverSite'),(1356,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment'),(1357,'ASSOCIATION',2,0,'containerCollection'),(1358,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.shippingtracking.BaseShipment'),(1359,'ASSOCIATION',1,0,'specimen'),(1360,'ASSOCIATION',1,0,'specimenPosition'),(1361,'ASSOCIATION',2,0,'assignedProtocolCollection'),(1362,'ASSOCIATION',1,0,'assignedProtocolUserCollection'),(1363,'ASSOCIATION',2,0,'siteCollection'),(1364,'ASSOCIATION',1,0,'collectionProtocolCollection'),(1365,'ASSOCIATION',2,0,'siteCollection'),(1366,'ASSOCIATION',1,0,'assignedSiteUserCollection'),(1367,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.OrderItem'),(1368,'ASSOCIATION',1,0,'distributedItem'),(1369,'CONTAINTMENT',2,0,'occupiedPositions'),(1370,'ASSOCIATION',1,0,'occupiedContainer'),(1371,'CONTAINTMENT',2,0,'specimenPositionCollection'),(1372,'ASSOCIATION',1,0,'storageContainer'),(1373,'ASSOCIATION',1,0,'edu.wustl.catissuecore.domain.shippingtracking.Shipment'),(1374,'ASSOCIATION',1,0,'shipmentRequest'),(1375,'ASSOCIATION',2,0,'edu.wustl.catissuecore.domain.shippingtracking.ShipmentRequest'),(1376,'ASSOCIATION',2,0,'specimenCollection'),(1377,'ASSOCIATION',100,0,'clinicalDiagnosisCollection'),(1378,'ASSOCIATION',1,0,'collectionProtocol'),(1379,'ASSOCIATION',100,0,'recordEntryCollection'),(1380,'ASSOCIATION',1,0,''),(1381,'CONTAINTMENT',100,0,'recordEntryCollection'),(1382,'ASSOCIATION',1,0,'participant'),(1383,'CONTAINTMENT',100,0,'recordEntryCollection'),(1384,'ASSOCIATION',1,0,'specimen'),(1385,'CONTAINTMENT',100,0,'recordEntryCollection'),(1386,'ASSOCIATION',1,0,'specimenCollectionGroup'),(1387,'ASSOCIATION',2,0,'studyFormContextCollection'),(1388,'ASSOCIATION',2,0,'collectionProtocolCollection');

/*Table structure for table `dyextn_sql_audit` */

DROP TABLE IF EXISTS `dyextn_sql_audit`;

CREATE TABLE `dyextn_sql_audit` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `AUDIT_DATE` date DEFAULT NULL,
  `QUERY_EXECUTED` varchar(4000) DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_sql_audit` */

/*Table structure for table `dyextn_tagged_value` */

DROP TABLE IF EXISTS `dyextn_tagged_value`;

CREATE TABLE `dyextn_tagged_value` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `T_KEY` varchar(255) DEFAULT NULL,
  `T_VALUE` varchar(255) DEFAULT NULL,
  `ABSTRACT_METADATA_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FKF79D055B9AEB0CA3` (`ABSTRACT_METADATA_ID`),
  CONSTRAINT `FKF79D055B9AEB0CA3` FOREIGN KEY (`ABSTRACT_METADATA_ID`) REFERENCES `dyextn_abstract_metadata` (`IDENTIFIER`)
) ENGINE=InnoDB AUTO_INCREMENT=1446 DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_tagged_value` */

insert  into `dyextn_tagged_value`(`IDENTIFIER`,`T_KEY`,`T_VALUE`,`ABSTRACT_METADATA_ID`) values (1,'ProjectVersion','1.1',1),(2,'caB2BEntityGroup','caB2BEntityGroup',1),(5,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',6),(6,'derived','derived',6),(37,'actualAssociationPointer','edu.wustl.catissuecore.domain.Container_edu.wustl.catissuecore.domain.Container_capacity_edu.wustl.catissuecore.domain.Capacity',54),(38,'derived','derived',54),(39,'derived','derived',57),(40,'derived','derived',58),(41,'derived','derived',59),(44,'derived','derived',63),(45,'derived','derived',64),(46,'derived','derived',65),(53,'actualAssociationPointer','edu.wustl.catissuecore.domain.Container_edu.wustl.catissuecore.domain.Container_capacity_edu.wustl.catissuecore.domain.Capacity',71),(54,'derived','derived',71),(57,'derived','derived',76),(58,'derived','derived',77),(59,'derived','derived',78),(62,'derived','derived',81),(63,'derived','derived',82),(64,'derived','derived',83),(78,'actualAssociationPointer','edu.wustl.catissuecore.domain.ContainerType_edu.wustl.catissuecore.domain.ContainerType_capacity_edu.wustl.catissuecore.domain.Capacity',148),(79,'derived','derived',148),(80,'derived','derived',150),(81,'derived','derived',151),(82,'derived','derived',152),(83,'derived','derived',154),(84,'derived','derived',155),(85,'derived','derived',156),(86,'actualAssociationPointer','edu.wustl.catissuecore.domain.ContainerType_edu.wustl.catissuecore.domain.ContainerType_capacity_edu.wustl.catissuecore.domain.Capacity',158),(87,'derived','derived',158),(88,'derived','derived',159),(89,'derived','derived',160),(90,'derived','derived',161),(91,'derived','derived',162),(92,'derived','derived',164),(93,'derived','derived',165),(95,'derived','derived',179),(96,'derived','derived',180),(97,'derived','derived',181),(98,'derived','derived',182),(99,'derived','derived',183),(100,'derived','derived',184),(101,'derived','derived',186),(102,'derived','derived',187),(103,'derived','derived',188),(104,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenProtocol_edu.wustl.catissuecore.domain.SpecimenProtocol_principalInvestigator_edu.wustl.catissuecore.domain.User',189),(105,'derived','derived',189),(106,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenProtocol_edu.wustl.catissuecore.domain.SpecimenProtocol_principalInvestigator_edu.wustl.catissuecore.domain.User',193),(107,'derived','derived',193),(108,'derived','derived',194),(109,'derived','derived',195),(110,'derived','derived',196),(111,'derived','derived',197),(112,'derived','derived',198),(113,'derived','derived',199),(114,'derived','derived',200),(115,'derived','derived',201),(116,'derived','derived',202),(126,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',226),(127,'derived','derived',226),(128,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',227),(129,'derived','derived',227),(130,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_null_consentTierStatusCollection_edu.wustl.catissuecore.domain.ConsentTierStatus',228),(131,'derived','derived',228),(144,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_storageContainer_edu.wustl.catissuecore.domain.StorageContainer',235),(145,'derived','derived',235),(146,'derived','derived',236),(148,'derived','derived',238),(150,'derived','derived',240),(152,'derived','derived',242),(153,'derived','derived',243),(155,'derived','derived',245),(156,'derived','derived',246),(158,'derived','derived',248),(182,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',263),(183,'derived','derived',263),(184,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',264),(185,'derived','derived',264),(186,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_null_consentTierStatusCollection_edu.wustl.catissuecore.domain.ConsentTierStatus',265),(187,'derived','derived',265),(200,'derived','derived',272),(202,'derived','derived',274),(204,'derived','derived',276),(206,'derived','derived',278),(207,'derived','derived',279),(209,'derived','derived',281),(210,'derived','derived',282),(212,'derived','derived',284),(234,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_storageContainer_edu.wustl.catissuecore.domain.StorageContainer',296),(235,'derived','derived',296),(238,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',299),(239,'derived','derived',299),(240,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',300),(241,'derived','derived',300),(242,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_null_consentTierStatusCollection_edu.wustl.catissuecore.domain.ConsentTierStatus',301),(243,'derived','derived',301),(256,'derived','derived',308),(258,'derived','derived',310),(260,'derived','derived',312),(262,'derived','derived',314),(263,'derived','derived',315),(265,'derived','derived',317),(266,'derived','derived',318),(268,'derived','derived',320),(290,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_storageContainer_edu.wustl.catissuecore.domain.StorageContainer',332),(291,'derived','derived',332),(294,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',335),(295,'derived','derived',335),(296,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',336),(297,'derived','derived',336),(298,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_null_consentTierStatusCollection_edu.wustl.catissuecore.domain.ConsentTierStatus',337),(299,'derived','derived',337),(312,'derived','derived',344),(314,'derived','derived',346),(316,'derived','derived',348),(318,'derived','derived',350),(319,'derived','derived',351),(321,'derived','derived',353),(322,'derived','derived',354),(324,'derived','derived',356),(346,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_storageContainer_edu.wustl.catissuecore.domain.StorageContainer',368),(347,'derived','derived',368),(350,'actualAssociationPointer','edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup_abstractSpecimenCollectionGroupCollection_specimenCollectionSite_edu.wustl.catissuecore.domain.Site',380),(351,'derived','derived',380),(352,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',384),(353,'derived','derived',384),(354,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',385),(355,'derived','derived',385),(356,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',386),(357,'derived','derived',386),(358,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',387),(359,'derived','derived',387),(360,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',388),(361,'derived','derived',388),(362,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',389),(363,'derived','derived',389),(365,'derived','derived',393),(366,'derived','derived',397),(367,'derived','derived',398),(368,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',399),(369,'derived','derived',399),(370,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',400),(371,'derived','derived',400),(372,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',401),(373,'derived','derived',401),(374,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',402),(375,'derived','derived',402),(376,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',403),(377,'derived','derived',403),(378,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',404),(379,'derived','derived',404),(380,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',405),(381,'derived','derived',405),(382,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',406),(383,'derived','derived',406),(384,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',407),(385,'derived','derived',407),(386,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',408),(387,'derived','derived',408),(388,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',409),(389,'derived','derived',409),(390,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',410),(391,'derived','derived',410),(392,'derived','derived',414),(414,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',431),(415,'derived','derived',431),(416,'derived','derived',432),(417,'derived','derived',434),(418,'derived','derived',436),(429,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',443),(430,'derived','derived',443),(431,'derived','derived',444),(432,'derived','derived',446),(433,'derived','derived',447),(444,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',454),(445,'derived','derived',454),(446,'derived','derived',455),(447,'derived','derived',456),(448,'derived','derived',457),(459,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',464),(460,'derived','derived',464),(461,'derived','derived',465),(462,'derived','derived',468),(463,'derived','derived',469),(468,'derived','derived',473),(469,'derived','derived',477),(470,'derived','derived',479),(471,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',482),(472,'derived','derived',482),(489,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',492),(490,'derived','derived',492),(491,'derived','derived',493),(492,'derived','derived',495),(493,'derived','derived',496),(504,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',503),(505,'derived','derived',503),(506,'derived','derived',504),(507,'derived','derived',505),(508,'derived','derived',507),(519,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',514),(520,'derived','derived',514),(521,'derived','derived',515),(522,'derived','derived',516),(523,'derived','derived',517),(530,'derived','derived',522),(531,'derived','derived',525),(532,'derived','derived',531),(533,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',532),(534,'derived','derived',532),(541,'derived','derived',538),(542,'derived','derived',541),(543,'derived','derived',544),(544,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',545),(545,'derived','derived',545),(564,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',556),(565,'derived','derived',556),(566,'derived','derived',557),(567,'derived','derived',558),(568,'derived','derived',561),(579,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',568),(580,'derived','derived',568),(581,'derived','derived',569),(582,'derived','derived',570),(583,'derived','derived',572),(594,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',579),(595,'derived','derived',579),(596,'derived','derived',580),(597,'derived','derived',581),(598,'derived','derived',583),(599,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',585),(600,'derived','derived',585),(601,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',586),(602,'derived','derived',586),(603,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',587),(604,'derived','derived',587),(605,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',588),(606,'derived','derived',588),(607,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',589),(608,'derived','derived',589),(609,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',590),(610,'derived','derived',590),(611,'derived','derived',591),(612,'derived','derived',592),(613,'derived','derived',594),(624,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',601),(625,'derived','derived',601),(626,'derived','derived',602),(627,'derived','derived',605),(628,'derived','derived',606),(639,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',613),(640,'derived','derived',613),(641,'derived','derived',614),(642,'derived','derived',616),(643,'derived','derived',617),(644,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',619),(645,'derived','derived',619),(646,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',620),(647,'derived','derived',620),(648,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',621),(649,'derived','derived',621),(650,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',622),(651,'derived','derived',622),(652,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',623),(653,'derived','derived',623),(654,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',624),(655,'derived','derived',624),(656,'derived','derived',625),(657,'derived','derived',626),(658,'derived','derived',627),(669,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_null_user_edu.wustl.catissuecore.domain.User',634),(670,'derived','derived',634),(671,'derived','derived',635),(672,'derived','derived',636),(673,'derived','derived',639),(676,'derived','derived',655),(677,'derived','derived',656),(679,'derived','derived',664),(680,'derived','derived',665),(684,'derived','derived',672),(685,'derived','derived',673),(686,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_xmlContent_edu.wustl.catissuecore.domain.pathology.XMLContent',675),(687,'derived','derived',675),(688,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_pathologyReportReviewParameterCollection_edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',676),(689,'derived','derived',676),(690,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_binaryContent_edu.wustl.catissuecore.domain.pathology.BinaryContent',677),(691,'derived','derived',677),(692,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_textContent_edu.wustl.catissuecore.domain.pathology.TextContent',678),(693,'derived','derived',678),(694,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_reportSource_edu.wustl.catissuecore.domain.Site',680),(695,'derived','derived',680),(696,'derived','derived',681),(697,'derived','derived',682),(698,'derived','derived',683),(699,'derived','derived',684),(700,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_xmlContent_edu.wustl.catissuecore.domain.pathology.XMLContent',687),(701,'derived','derived',687),(702,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_pathologyReportReviewParameterCollection_edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',688),(703,'derived','derived',688),(704,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_binaryContent_edu.wustl.catissuecore.domain.pathology.BinaryContent',689),(705,'derived','derived',689),(706,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_textContent_edu.wustl.catissuecore.domain.pathology.TextContent',691),(707,'derived','derived',691),(708,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_reportSource_edu.wustl.catissuecore.domain.Site',692),(709,'derived','derived',692),(710,'derived','derived',693),(711,'derived','derived',694),(712,'derived','derived',696),(713,'derived','derived',697),(763,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',776),(764,'derived','derived',776),(767,'derived','derived',778),(768,'derived','derived',779),(769,'derived','derived',780),(780,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',787),(781,'derived','derived',787),(784,'derived','derived',789),(785,'derived','derived',792),(786,'derived','derived',793),(795,'derived','derived',799),(796,'derived','derived',800),(797,'derived','derived',802),(798,'derived','derived',803),(799,'derived','derived',804),(802,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',807),(803,'derived','derived',807),(804,'actualAssociationPointer','edu.wustl.catissuecore.domain.PathologicalCaseOrderItem_null_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',809),(805,'derived','derived',809),(818,'derived','derived',817),(819,'derived','derived',818),(820,'derived','derived',819),(821,'derived','derived',820),(822,'derived','derived',821),(825,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',823),(826,'derived','derived',823),(827,'actualAssociationPointer','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem_null_parentSpecimen_edu.wustl.catissuecore.domain.Specimen',825),(828,'derived','derived',825),(829,'actualAssociationPointer','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem_null_parentSpecimen_edu.wustl.catissuecore.domain.Specimen',826),(830,'derived','derived',826),(831,'actualAssociationPointer','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem_null_parentSpecimen_edu.wustl.catissuecore.domain.Specimen',827),(832,'derived','derived',827),(833,'actualAssociationPointer','edu.wustl.catissuecore.domain.DerivedSpecimenOrderItem_null_parentSpecimen_edu.wustl.catissuecore.domain.Specimen',828),(834,'derived','derived',828),(850,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',863),(851,'derived','derived',863),(854,'derived','derived',865),(855,'derived','derived',866),(856,'derived','derived',867),(865,'derived','derived',873),(866,'derived','derived',874),(867,'derived','derived',875),(870,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',879),(871,'derived','derived',879),(872,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',880),(873,'derived','derived',880),(874,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',881),(875,'derived','derived',881),(876,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',882),(877,'derived','derived',882),(878,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',883),(879,'derived','derived',883),(886,'derived','derived',889),(887,'derived','derived',890),(888,'derived','derived',891),(889,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem_null_specimen_edu.wustl.catissuecore.domain.Specimen',893),(890,'derived','derived',893),(891,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem_null_specimen_edu.wustl.catissuecore.domain.Specimen',894),(892,'derived','derived',894),(893,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem_null_specimen_edu.wustl.catissuecore.domain.Specimen',895),(894,'derived','derived',895),(895,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExistingSpecimenOrderItem_null_specimen_edu.wustl.catissuecore.domain.Specimen',896),(896,'derived','derived',896),(899,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',898),(900,'derived','derived',898),(907,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',903),(908,'derived','derived',903),(909,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',904),(910,'derived','derived',904),(911,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',905),(912,'derived','derived',905),(913,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',906),(914,'derived','derived',906),(916,'derived','derived',920),(917,'derived','derived',924),(948,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',966),(949,'derived','derived',966),(950,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',967),(951,'derived','derived',967),(952,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',968),(953,'derived','derived',968),(954,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',969),(955,'derived','derived',969),(957,'derived','derived',979),(968,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',988),(969,'derived','derived',988),(972,'derived','derived',990),(973,'derived','derived',991),(974,'derived','derived',992),(977,'derived','derived',996),(978,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',996),(983,'derived','derived',999),(984,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',999),(1043,'derived','derived',1034),(1044,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',1034),(1045,'derived','derived',1035),(1046,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1035),(1051,'derived','derived',1038),(1052,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1038),(1057,'derived','derived',1041),(1058,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1041),(1097,'derived','derived',1060),(1098,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',1060),(1099,'derived','derived',1061),(1100,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1061),(1109,'derived','derived',1065),(1110,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1065),(1115,'derived','derived',1068),(1116,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1068),(1151,'derived','derived',1086),(1152,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',1086),(1153,'derived','derived',1087),(1154,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1087),(1165,'derived','derived',1092),(1166,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1092),(1171,'derived','derived',1095),(1172,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1095),(1205,'derived','derived',1112),(1206,'actualAssociationPointer','edu.wustl.catissuecore.domain.Biohazard_biohazardCollection_specimenCollection_edu.wustl.catissuecore.domain.Specimen',1112),(1207,'derived','derived',1113),(1208,'actualAssociationPointer','edu.wustl.catissuecore.domain.ExternalIdentifier_externalIdentifierCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1113),(1221,'derived','derived',1119),(1222,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1119),(1227,'derived','derived',1122),(1228,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenEventParameters_specimenEventCollection_specimen_edu.wustl.catissuecore.domain.Specimen',1122),(1259,'derived','derived',1139),(1260,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1139),(1261,'derived','derived',1139),(1262,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1139),(1263,'derived','derived',1140),(1264,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1140),(1265,'derived','derived',1141),(1266,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1141),(1267,'derived','derived',1142),(1268,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1142),(1269,'derived','derived',1144),(1270,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1144),(1271,'derived','derived',1145),(1272,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1145),(1273,'derived','derived',1145),(1274,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1145),(1275,'derived','derived',1146),(1276,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1146),(1277,'derived','derived',1147),(1278,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1147),(1279,'derived','derived',1148),(1280,'actualAssociationPointer','edu.wustl.catissuecore.domain.Specimen_specimenCollection_specimenCollectionGroup_edu.wustl.catissuecore.domain.AbstractSpecimenCollectionGroup',1148),(1281,'derived','derived',1151),(1282,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1151),(1283,'derived','derived',1152),(1284,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1152),(1285,'derived','derived',1153),(1286,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1153),(1287,'derived','derived',1154),(1288,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1154),(1289,'derived','derived',1155),(1290,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1155),(1291,'derived','derived',1156),(1292,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1156),(1293,'derived','derived',1157),(1294,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1157),(1295,'derived','derived',1158),(1296,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1158),(1297,'derived','derived',1159),(1298,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1159),(1299,'derived','derived',1160),(1300,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1160),(1301,'derived','derived',1161),(1302,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1161),(1303,'derived','derived',1162),(1304,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1162),(1305,'derived','derived',1163),(1306,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1163),(1307,'derived','derived',1164),(1308,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1164),(1309,'derived','derived',1165),(1310,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1165),(1311,'derived','derived',1166),(1312,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1166),(1313,'derived','derived',1167),(1314,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1167),(1315,'derived','derived',1168),(1316,'actualAssociationPointer','edu.wustl.catissuecore.domain.SpecimenCollectionGroup_specimenCollectionGroup_specimenEventParametersCollection_edu.wustl.catissuecore.domain.SpecimenEventParameters',1168),(1317,'derived','derived',1169),(1318,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_textContent_edu.wustl.catissuecore.domain.pathology.TextContent',1169),(1319,'derived','derived',1170),(1320,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_textContent_edu.wustl.catissuecore.domain.pathology.TextContent',1170),(1321,'derived','derived',1173),(1322,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_pathologyReportReviewParameterCollection_edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',1173),(1323,'derived','derived',1174),(1324,'actualAssociationPointer','edu.wustl.catissuecore.domain.pathology.SurgicalPathologyReport_surgicalPathologyReport_pathologyReportReviewParameterCollection_edu.wustl.catissuecore.domain.pathology.PathologyReportReviewParameter',1174),(1337,'derived','derived',1189),(1338,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1189),(1339,'derived','derived',1190),(1340,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1190),(1341,'derived','derived',1191),(1342,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1191),(1343,'derived','derived',1193),(1344,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1193),(1345,'derived','derived',1194),(1346,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1194),(1347,'derived','derived',1195),(1348,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1195),(1349,'derived','derived',1196),(1350,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1196),(1351,'derived','derived',1197),(1352,'actualAssociationPointer','edu.wustl.catissuecore.domain.OrderItem_orderItemCollection_orderDetails_edu.wustl.catissuecore.domain.OrderDetails',1197),(1353,'derived','derived',1199),(1354,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',1199),(1355,'derived','derived',1200),(1356,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',1200),(1357,'derived','derived',1201),(1358,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',1201),(1359,'derived','derived',1204),(1360,'actualAssociationPointer','edu.wustl.catissuecore.domain.NewSpecimenArrayOrderItem_newSpecimenArrayOrderItem_specimenOrderItemCollection_edu.wustl.catissuecore.domain.SpecimenOrderItem',1204),(1361,'caB2BEntityGroup','caB2BEntityGroup',1208),(1362,'derived','derived',1211),(1364,'derived','derived',1213),(1366,'derived','derived',1215),(1368,'derived','derived',1217),(1370,'PRIVILEGE_ID','1',4),(1371,'PRIVILEGE_ID','1',125),(1372,'PRIVILEGE_ID','1',128),(1373,'PRIVILEGE_ID','1',131),(1374,'PRIVILEGE_ID','1',911),(1375,'PRIVILEGE_ID','1',915),(1376,'PRIVILEGE_ID','1',921),(1377,'PRIVILEGE_ID','1',965),(1378,'PRIVILEGE_ID','1',975),(1379,'PRIVILEGE_ID','2',40),(1380,'PRIVILEGE_ID','2',53),(1381,'PRIVILEGE_ID','2',70),(1382,'PRIVILEGE_ID','2',89),(1383,'PRIVILEGE_ID','2',97),(1384,'PRIVILEGE_ID','2',116),(1385,'PRIVILEGE_ID','2',134),(1386,'PRIVILEGE_ID','2',142),(1387,'PRIVILEGE_ID','2',146),(1388,'PRIVILEGE_ID','2',157),(1389,'PRIVILEGE_ID','2',166),(1390,'PRIVILEGE_ID','2',177),(1391,'PRIVILEGE_ID','2',192),(1392,'PRIVILEGE_ID','2',224),(1393,'PRIVILEGE_ID','2',261),(1394,'PRIVILEGE_ID','2',297),(1395,'PRIVILEGE_ID','2',333),(1396,'PRIVILEGE_ID','2',373),(1397,'PRIVILEGE_ID','2',379),(1398,'PRIVILEGE_ID','2',411),(1399,'PRIVILEGE_ID','2',415),(1400,'PRIVILEGE_ID','2',425),(1401,'PRIVILEGE_ID','2',437),(1402,'PRIVILEGE_ID','2',448),(1403,'PRIVILEGE_ID','2',458),(1404,'PRIVILEGE_ID','2',470),(1405,'PRIVILEGE_ID','2',486),(1406,'PRIVILEGE_ID','2',497),(1407,'PRIVILEGE_ID','2',508),(1408,'PRIVILEGE_ID','2',518),(1409,'PRIVILEGE_ID','2',535),(1410,'PRIVILEGE_ID','2',550),(1411,'PRIVILEGE_ID','2',562),(1412,'PRIVILEGE_ID','2',573),(1413,'PRIVILEGE_ID','2',584),(1414,'PRIVILEGE_ID','2',595),(1415,'PRIVILEGE_ID','2',607),(1416,'PRIVILEGE_ID','2',618),(1417,'PRIVILEGE_ID','2',628),(1418,'PRIVILEGE_ID','2',640),(1419,'PRIVILEGE_ID','2',650),(1420,'PRIVILEGE_ID','2',653),(1421,'PRIVILEGE_ID','2',657),(1422,'PRIVILEGE_ID','2',663),(1423,'PRIVILEGE_ID','2',666),(1424,'PRIVILEGE_ID','2',671),(1425,'PRIVILEGE_ID','1',674),(1426,'PRIVILEGE_ID','2',685),(1428,'PRIVILEGE_ID','2',844),(1429,'PRIVILEGE_ID','2',944),(1430,'PRIVILEGE_ID','2',830),(1431,'caB2BEntityGroup','caB2BEntityGroup',1226),(1432,'caB2BEntityGroup','caB2BEntityGroup',1317),(1433,'caB2BEntityGroup','caB2BEntityGroup',1436),(1434,'PackageName','clinical_annotation',1226),(1435,'PackageName','pathology_specimen',1317),(1436,'PackageName','pathology_scg',1436),(1437,'MetadataEntityGroup','MetadataEntityGroup',1),(1438,'MetadataEntityGroup','MetadataEntityGroup',1208),(1439,'MetadataEntityGroup','MetadataEntityGroup',1226),(1440,'MetadataEntityGroup','MetadataEntityGroup',1317),(1441,'MetadataEntityGroup','MetadataEntityGroup',1436),(1442,'IS_BIRTH_DATE','true',847),(1443,'resultview','resultview',844),(1444,'resultview','1',846),(1445,'resultview','2',850);

/*Table structure for table `dyextn_view` */

DROP TABLE IF EXISTS `dyextn_view`;

CREATE TABLE `dyextn_view` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dyextn_view` */

/*Table structure for table `id_table` */

DROP TABLE IF EXISTS `id_table`;

CREATE TABLE `id_table` (
  `NEXT_ASSOCIATION_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`NEXT_ASSOCIATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `id_table` */

insert  into `id_table`(`NEXT_ASSOCIATION_ID`) values (1);

/*Table structure for table `inter_model_association` */

DROP TABLE IF EXISTS `inter_model_association`;

CREATE TABLE `inter_model_association` (
  `ASSOCIATION_ID` bigint(20) NOT NULL,
  `LEFT_ENTITY_ID` bigint(20) NOT NULL,
  `LEFT_ATTRIBUTE_ID` bigint(20) NOT NULL,
  `RIGHT_ENTITY_ID` bigint(20) NOT NULL,
  `RIGHT_ATTRIBUTE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`ASSOCIATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `inter_model_association` */

/*Table structure for table `intra_model_association` */

DROP TABLE IF EXISTS `intra_model_association`;

CREATE TABLE `intra_model_association` (
  `ASSOCIATION_ID` bigint(20) NOT NULL,
  `DE_ASSOCIATION_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`ASSOCIATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `intra_model_association` */

insert  into `intra_model_association`(`ASSOCIATION_ID`,`DE_ASSOCIATION_ID`) values (2,735),(3,1161),(5,907),(7,993),(9,1112),(10,1175),(11,863),(12,86),(13,601),(15,1163),(19,480),(20,905),(24,1173),(25,481),(26,882),(35,503),(40,1041),(46,643),(48,263),(51,1061),(53,545),(54,149),(55,718),(58,1155),(67,409),(69,968),(70,823),(71,167),(73,108),(75,586),(77,679),(78,970),(83,74),(86,454),(89,368),(93,1177),(96,41),(98,710),(100,966),(104,1165),(111,431),(112,1122),(114,98),(118,1191),(124,677),(125,1179),(126,691),(127,1189),(131,296),(132,689),(133,590),(134,1207),(139,265),(140,945),(141,1204),(142,178),(143,532),(144,1065),(145,1148),(147,808),(149,1145),(154,880),(157,1167),(167,878),(173,190),(174,832),(179,1195),(180,1151),(183,1142),(186,828),(187,401),(189,226),(190,1138),(191,757),(192,407),(195,1201),(196,514),(200,676),(201,755),(202,405),(205,1149),(207,1144),(208,7),(209,579),(215,388),(218,381),(221,1205),(222,383),(227,895),(228,1029),(234,826),(238,301),(241,893),(242,400),(243,1197),(244,1033),(245,763),(247,299),(250,335),(252,1035),(255,988),(256,587),(257,619),(260,688),(261,903),(262,976),(263,386),(264,1140),(270,700),(271,66),(272,1092),(273,264),(274,13),(275,642),(276,1159),(281,834),(282,228),(284,1031),(288,390),(289,72),(292,1113),(293,135),(295,996),(296,1170),(297,403),(299,1153),(304,1172),(305,1193),(306,1157),(311,621),(312,91),(313,148),(317,686),(319,1199),(320,623),(323,110),(325,158),(328,374),(329,927),(330,1176),(332,1162),(338,1060),(342,85),(344,881),(346,994),(349,946),(351,482),(357,1192),(359,1174),(364,1164),(368,644),(371,950),(372,835),(376,883),(380,824),(381,193),(387,1119),(391,969),(393,841),(395,410),(396,967),(397,833),(400,585),(401,370),(402,1038),(403,1156),(404,680),(410,1182),(418,807),(420,556),(426,654),(428,753),(430,1178),(432,443),(437,1180),(438,613),(441,1188),(445,787),(449,933),(450,678),(453,421),(456,589),(457,1203),(466,1068),(467,1168),(473,1166),(481,1146),(483,879),(487,692),(489,1147),(494,1190),(495,1152),(498,235),(499,748),(500,896),(501,1141),(502,827),(503,1086),(506,825),(507,380),(508,634),(509,1087),(510,189),(512,337),(517,690),(520,831),(521,402),(522,191),(523,1202),(524,756),(528,568),(531,406),(533,382),(534,54),(536,1150),(538,1143),(543,1206),(544,6),(548,332),(550,961),(555,675),(562,894),(564,492),(565,384),(566,56),(567,1005),(568,464),(570,620),(571,999),(572,588),(573,699),(574,336),(575,1034),(576,399),(577,73),(580,1160),(584,14),(585,385),(586,1158),(587,809),(589,987),(590,300),(591,1030),(595,776),(596,1198),(597,387),(600,904),(603,884),(606,742),(611,687),(612,1169),(613,898),(616,227),(619,8),(621,1194),(622,1139),(623,71),(626,916),(629,147),(632,1196),(634,408),(635,90),(636,111),(638,624),(644,912),(645,1171),(646,764),(647,641),(648,1154),(649,906),(650,622),(653,109),(655,389),(656,404),(657,1095),(660,1200),(661,892),(662,645),(664,1224),(665,1225),(666,1302),(667,1303),(669,1304),(670,1305),(671,1266),(672,1306),(674,1307),(676,1308),(677,1232),(678,1309),(679,1310),(680,1311),(681,1312),(682,1313),(683,1314),(684,1315),(685,1316),(686,1390),(688,1320),(689,1328),(690,1329),(691,1330),(692,1334),(693,1391),(694,1392),(695,1393),(696,1394),(697,1395),(700,1396),(701,1397),(702,1398),(706,1407),(707,1413),(708,1420),(709,1426),(710,1429),(711,1430),(712,1805),(713,1442),(714,1456),(715,1443),(716,1449),(717,1806),(718,1580),(720,1579),(721,1807),(722,1467),(723,1466),(724,1465),(725,1464),(726,1488),(727,1487),(728,1499),(729,1486),(730,1463),(731,1510),(732,1808),(733,1547),(734,1809),(735,1679),(736,1682),(737,1678),(739,1687),(740,1810),(741,1811),(742,1812),(743,1813),(744,1708),(745,1707),(746,1618),(747,1622),(748,1617),(749,1814),(750,1815),(751,1816),(752,1520),(753,1529),(754,1521),(755,1817),(756,1818),(757,1819),(758,1800),(759,1799),(760,1568),(761,1820),(762,1747),(763,1602),(764,1746),(765,1745),(766,1751),(767,1821),(768,1776),(769,1779),(771,1822),(772,1759),(773,1758),(774,1670),(775,1669),(777,1756),(778,1823),(780,1824),(781,1793),(782,1767),(783,1792),(784,1791),(785,1786),(786,1790),(787,1825),(789,1636),(790,1634),(791,1650),(792,1633),(793,1610),(794,1826),(795,1720),(796,1725),(797,1719),(798,1729),(799,1718),(800,1695),(801,1717),(802,1733),(803,1399),(804,1402),(805,1827),(806,1834),(807,1835),(808,1840),(809,1843),(810,1844),(811,1852),(812,1853),(813,1860),(814,1861),(815,1865),(816,1866),(817,1867),(818,1868),(819,1878),(820,1879),(821,1880),(822,1881),(823,1882),(824,1901),(825,1902),(826,1903),(827,1904),(828,1905),(829,1906),(830,1907),(831,1908),(832,1909),(833,1910),(834,1911),(835,1912),(836,1913),(837,1914),(838,1915),(839,1916),(840,1927),(841,1928),(842,1929),(843,1949),(844,1950),(845,1951),(846,1952),(847,1953),(848,1954),(849,1955),(850,1956),(851,1957),(852,1958);

/*Table structure for table `job_details` */

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `JOB_NAME` varchar(255) NOT NULL,
  `JOB_STATUS` varchar(50) DEFAULT NULL,
  `TOTAL_RECORDS_COUNT` bigint(20) DEFAULT NULL,
  `FAILED_RECORDS_COUNT` bigint(20) DEFAULT NULL,
  `TIME_TAKEN` bigint(20) DEFAULT NULL,
  `LOG_FILE` blob,
  `JOB_STARTED_BY` bigint(20) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `CURRENT_RECORDS_PROCESSED` bigint(20) DEFAULT NULL,
  `LOG_FILE_NAME` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `job_details` */

/*Table structure for table `key_seq_generator` */

DROP TABLE IF EXISTS `key_seq_generator`;

CREATE TABLE `key_seq_generator` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `KEY_VALUE` varchar(50) NOT NULL,
  `KEY_SEQUENCE_ID` varchar(50) NOT NULL,
  `KEY_TYPE` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `key_seq_generator` */

/*Table structure for table `path` */

DROP TABLE IF EXISTS `path`;

CREATE TABLE `path` (
  `PATH_ID` bigint(20) NOT NULL,
  `FIRST_ENTITY_ID` bigint(20) DEFAULT NULL,
  `INTERMEDIATE_PATH` varchar(1000) DEFAULT NULL,
  `LAST_ENTITY_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`PATH_ID`),
  KEY `INDEX1` (`FIRST_ENTITY_ID`,`LAST_ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `path` */

insert  into `path`(`PATH_ID`,`FIRST_ENTITY_ID`,`INTERMEDIATE_PATH`,`LAST_ENTITY_ID`) values (0,333,'567',261),(1,177,'284',717),(2,333,'567',297),(3,4,'567',333),(4,373,'328',89),(5,4,'567',297),(6,89,'312',97),(7,97,'653',125),(8,224,'567',333),(9,224,'567',297),(10,261,'567',333),(11,261,'567',224),(12,261,'567',297),(13,297,'567',261),(14,297,'567',333),(15,717,'410',379),(16,333,'274',261),(17,333,'274',224),(18,379,'507',89),(19,4,'274',333),(20,4,'274',224),(21,4,'274',297),(22,4,'274',261),(23,224,'274',261),(24,224,'274',333),(25,224,'274',297),(26,261,'274',333),(27,261,'274',224),(28,261,'274',297),(29,297,'274',261),(30,297,'274',333),(31,297,'274',224),(33,762,'127',981),(41,166,'71',97),(42,97,'73',128),(46,762,'243',857),(54,192,'381',97),(60,740,'499',4),(71,177,'173',97),(72,177,'510',97),(78,762,'118',868),(90,470,'25',70),(91,470,'19',70),(101,762,'357',729),(111,762,'621',781),(125,70,'83',177),(145,762,'494',886),(150,4,'295',618),(170,762,'179',794),(183,762,'632',812),(198,4,'571',584),(276,762,'305',770),(281,333,'387',618),(359,297,'272',618),(363,333,'112',584),(379,224,'40',584),(463,224,'402',618),(581,261,'466',584),(609,297,'657',584),(831,261,'144',618),(3280,70,'12',89),(3283,981,'589',53),(3284,657,'304_612',674),(3285,657,'304',653),(3286,653,'612',674),(3306,674,'330',379),(3310,379,'597',595),(3316,618,'320',4),(3319,657,'304_645',640),(3320,653,'645',640),(3329,379,'187',550),(3340,657,'304_296',685),(3341,653,'296',685),(3344,584,'75',297),(3375,379,'585',618),(3378,618,'650',224),(3408,685,'517',379),(3412,379,'576',508),(3436,584,'400',333),(3476,379,'395',425),(3483,379,'288',415),(3502,379,'521',535),(3554,379,'656',497),(3558,379,'565',628),(3576,618,'570',297),(3616,379,'297',518),(3623,379,'215',584),(3626,584,'572',224),(3642,379,'67',437),(3700,379,'192',458),(3721,584,'456',4),(3749,379,'655',573),(3807,379,'634',448),(3840,618,'311',261),(3877,379,'531',470),(3883,618,'257',333),(3944,379,'242',562),(3969,379,'202',486),(4050,584,'256',261),(4063,379,'263',607),(5726,70,'623',142),(5730,926,'329',685),(5731,40,'96',142),(5732,53,'534',142),(5736,333,'89',70),(5742,297,'548',70),(5750,224,'498',70),(5762,261,'131',70),(6808,770,'595',762),(6817,762,'245',754),(6825,754,'441',740),(6832,740,'606',53),(6843,949,'550',4),(6846,4,'208_328',89),(6847,4,'208',373),(6850,97,'323',116),(6860,812,'70',762),(6889,261,'273',373),(6902,729,'2',762),(6912,857,'11',762),(6948,4,'544_507',89),(6949,4,'544',379),(6977,981,'255',762),(7004,333,'250_507',89),(7005,333,'250',379),(7050,794,'418',762),(7053,868,'376',762),(7061,333,'574',373),(7068,224,'189_507',89),(7069,224,'189',379),(7076,297,'247_507',89),(7077,297,'247',379),(7080,886,'613',762),(7088,297,'590',373),(7103,781,'445',762),(7110,261,'48_507',89),(7111,261,'48',379),(7162,224,'616',373),(7829,177,'591',830),(7831,53,'566',97),(7832,97,'114',131),(7835,177,'591_281',379),(7838,830,'281',379),(8254,830,'372',97),(8263,379,'538',830),(8310,379,'205_93',926),(8311,379,'205',685),(8312,685,'93',926),(8315,379,'533',674),(8425,666,'10',640),(8427,373,'622',224),(8428,89,'635',116),(8432,666,'24',674),(8436,379,'207',4),(8438,379,'481',261),(8439,666,'359',685),(8441,373,'501',297),(8443,373,'190',4),(8456,379,'149',224),(8465,373,'264',261),(8478,373,'183',333),(8481,379,'145',333),(8483,379,'489',297),(9370,595,'104',379),(9377,618,'157',379),(9379,437,'495',379),(9384,628,'467',379),(9389,333,'89_12',89),(9391,458,'648',379),(9399,97,'228',177),(9406,224,'498_12',89),(9408,562,'332',379),(9410,415,'536',379),(9415,297,'548_12',89),(9429,584,'364',379),(9443,535,'580',379),(9450,261,'131_12',89),(9457,448,'299',379),(9463,486,'403',379),(9468,425,'180',379),(9470,550,'3',379),(9474,497,'306',379),(9483,518,'276',379),(9512,573,'15',379),(9520,470,'58',379),(9542,508,'586',379),(9659,607,'473',379),(9941,965,'78',4),(9945,508,'196',97),(9949,965,'69',261),(9953,535,'53',97),(9957,965,'396',297),(9963,965,'100',333),(9967,573,'209',97),(9974,458,'568',97),(9986,448,'86',97),(9993,562,'528',97),(10000,470,'351',97),(10004,965,'391',224),(10008,618,'638',97),(10015,595,'13',97),(10022,518,'143',97),(10034,486,'564',97),(10041,425,'111',97),(10048,607,'438',97),(10060,628,'508',97),(10087,415,'453',97),(10114,497,'35',97),(10156,584,'133',97),(10163,550,'420',97),(10243,4,'571_133',97),(10255,437,'432',97),(10340,4,'295_638',97),(10513,830,'174',177),(27352,794,'587',379),(27382,794,'147',373),(27420,674,'124',663),(27421,640,'46',663),(27422,685,'132',663),(27434,902,'649',224),(27437,902,'20',261),(27440,902,'5',4),(27441,1858,'584',220),(27443,902,'261',333),(27446,902,'600',297),(27539,97,'636',112),(29811,674,'404',89),(29814,640,'662',89),(29817,685,'487',89),(29821,886,'227',297),(29854,886,'500',333),(29885,812,'502',297),(29919,812,'506',224),(29945,886,'241',224),(30001,886,'661',4),(30025,812,'234',261),(30029,812,'380',4),(30077,812,'186',333),(30197,886,'562',261),(37016,944,'349',844),(37017,844,'457',830),(37022,844,'457_281',379),(37065,709,'437',698),(37068,709,'437_430',685),(37069,698,'430',685),(37072,379,'207_584',220),(37075,709,'437_430_517',379),(37151,333,'89_83',177),(37207,297,'548_83',177),(41325,949,'371',53),(54288,717,'55',177),(54292,379,'218',717),(54394,379,'218_55',177),(89847,830,'520',844),(89851,844,'523',944),(89854,944,'140',89),(99426,369,'401',203),(99431,379,'222_401',203),(99432,379,'222',369),(103211,657,'304_645_46',663),(103212,653,'645_46',663),(103214,653,'296_132',663),(103216,653,'612_124',663),(103220,685,'611',671),(103221,674,'555',671),(103227,640,'647',671),(103252,706,'125_430',685),(103253,706,'125',698),(103265,706,'125_430_517',379),(103337,261,'51',902),(103340,333,'292',902),(103342,297,'509',902),(103345,4,'346',902),(103352,224,'252',902),(103379,134,'293',142),(103392,146,'313',142),(103406,53,'271',157),(103407,157,'325',142),(103423,70,'577',146),(103424,70,'342',146),(103435,70,'289',157),(106891,674,'200',666),(106892,685,'260',666),(106893,640,'275',666),(119694,261,'338',965),(119697,224,'575',965),(119699,4,'7',965),(119701,297,'503',965),(119704,333,'9',965),(126960,844,'457_281_149',224),(126962,844,'457_281_207',4),(126980,844,'457_281_489',297),(126982,844,'457_281_145',333),(126988,844,'457_281_481',261),(142504,754,'524',97),(160007,754,'191',89),(160040,297,'238_401',203),(160041,297,'238',369),(160044,224,'282_401',203),(160045,224,'282',369),(160048,4,'619_401',203),(160049,4,'619',369),(160056,261,'139_401',203),(160057,261,'139',369),(160084,333,'512_401',203),(160085,333,'512',369),(172495,224,'189_538_520',844),(172505,297,'247_538_520',844),(172515,261,'48_538_520',844),(172525,333,'250_538_520',844),(172535,4,'544_538_520',844),(174534,740,'428',754),(174599,698,'270',706),(174600,685,'317_270',706),(174601,685,'317',698),(174606,379,'205_317_270',706),(174607,379,'205_317',698),(174624,698,'573_98',714),(174625,698,'573',709),(174626,709,'98',714),(174632,379,'205_317_573_98',714),(174633,379,'205_317_573',709),(174634,685,'317_573_98',714),(174635,685,'317_573',709),(211327,640,'368_426',657),(211328,640,'368',653),(211329,653,'426',657),(211330,685,'126_426',657),(211331,685,'126',653),(211332,674,'450_426',657),(211333,674,'450',653),(223431,762,'646',192),(246855,830,'397',840),(246856,840,'393',203),(283393,709,'437_270',706),(287035,844,'457_281_207_584',220),(332028,844,'457_174',177),(334059,754,'201',192),(340264,177,'142',203),(422300,844,'457_281_205',685),(422305,844,'457_281_533',674),(430821,706,'125_573_98',714),(430822,706,'125_573',709),(477861,975,'262_134',915),(477862,975,'262',921),(477864,921,'134',915),(477865,915,'221',911),(525053,932,'449',192),(570293,657,'304_645_662',89),(570296,653,'645_662',89),(697711,653,'296_260',666),(697712,657,'304_645_275',666),(697713,653,'645_275',666),(697715,653,'612_200',666),(725124,709,'437_430_93',926),(725125,698,'430_93',926),(743282,844,'457_397_393',203),(743283,844,'457_397',840),(751009,868,'603',157),(845640,911,'644',915),(845642,915,'626',921),(845643,921,'543',975),(864301,653,'296_611',671),(864303,653,'612_555',671),(864304,657,'304_645_647',671),(864305,653,'645_647',671),(930440,706,'125_430_93',926),(984072,666,'10_368_426',657),(984073,666,'10_368',653),(984074,666,'24_450_426',657),(984075,666,'24_450',653),(984076,666,'359_126_426',657),(984077,666,'359_126',653),(985265,1858,'567',1858),(985266,1858,'274',1858),(985309,868,'26',794),(985310,886,'141',868),(985311,812,'195',868),(985312,868,'344',812),(985313,868,'167',770),(985314,794,'660',868),(985315,770,'596',868),(985316,868,'483',886),(985317,868,'154',781),(985318,781,'319',868),(985319,674,'77',685),(985339,177,'664',177),(985340,177,'665',177),(985341,844,'845_666',1283),(985342,844,'845_667',1290),(985345,844,'845_669',1227),(985346,844,'845_670',1264),(985347,1264,'671',1236),(985348,844,'845_670_671',1236),(985349,844,'845_672',1271),(985352,844,'845_674',1274),(985355,844,'845_676',1230),(985356,1230,'677',1236),(985357,844,'845_676_677',1236),(985358,844,'845_678',1297),(985359,844,'845_679',1241),(985360,844,'845_680',1279),(985361,844,'845_681',1254),(985362,844,'845_682',1249),(985363,844,'845_683',1277),(985364,844,'845_684',1295),(985365,844,'845_685',1300),(985366,4,'847_686',1325),(985369,1318,'688',1322),(985371,1325,'689',1344),(985372,4,'847_686_689',1344),(985373,1325,'690',1339),(985374,4,'847_686_690',1339),(985375,1325,'691',1332),(985376,4,'847_686_691',1332),(985377,1332,'692',1336),(985378,4,'847_686_691_692',1336),(985379,4,'847_693',1359),(985380,4,'847_694',1375),(985381,4,'847_695',1349),(985382,4,'847_696',1363),(985383,4,'847_697',1377),(985388,4,'847_700',1357),(985389,4,'847_701',1386),(985390,4,'847_702',1365),(985397,1377,'706',1408),(985398,4,'847_697_706',1408),(985399,1365,'707',1414),(985400,4,'847_702_707',1414),(985401,1290,'708',1421),(985402,844,'845_667_708',1421),(985403,1227,'709',1427),(985404,844,'845_669_709',1427),(985405,1427,'710',1434),(985406,844,'845_669_709_710',1434),(985407,1427,'711',1432),(985408,844,'845_669_709_711',1432),(985409,379,'849_712',1440),(985410,1440,'713',1454),(985411,379,'849_712_713',1454),(985412,1454,'714',1458),(985413,379,'849_712_713_714',1458),(985414,1440,'715',1447),(985415,379,'849_712_715',1447),(985416,1447,'716',1451),(985417,379,'849_712_715_716',1451),(985418,379,'849_717',1577),(985419,1577,'718',1584),(985420,379,'849_717_718',1584),(985423,1577,'720',1589),(985424,379,'849_717_720',1589),(985425,379,'849_721',1461),(985426,1461,'722',1468),(985427,379,'849_721_722',1468),(985428,1461,'723',1473),(985429,379,'849_721_723',1473),(985430,1461,'724',1479),(985431,379,'849_721_724',1479),(985432,1461,'725',1484),(985433,379,'849_721_725',1484),(985434,1484,'726',1489),(985435,379,'849_721_725_726',1489),(985436,1484,'727',1497),(985437,379,'849_721_725_727',1497),(985438,1497,'728',1501),(985439,379,'849_721_725_727_728',1501),(985440,1484,'729',1505),(985441,379,'849_721_725_729',1505),(985442,1461,'730',1508),(985443,379,'849_721_730',1508),(985444,1508,'731',1513),(985445,379,'849_721_730_731',1513),(985446,379,'849_732',1545),(985447,1545,'733',1551),(985448,379,'849_732_733',1551),(985449,379,'849_734',1676),(985450,1676,'735',1680),(985451,379,'849_734_735',1680),(985452,1680,'736',1663),(985453,379,'849_734_735_736',1663),(985454,1676,'737',1685),(985455,379,'849_734_737',1685),(985458,1685,'739',1690),(985459,379,'849_734_737_739',1690),(985460,379,'849_740',1652),(985461,379,'849_741',1794),(985462,379,'849_742',1625),(985463,379,'849_743',1705),(985464,1705,'744',1701),(985465,379,'849_743_744',1701),(985466,1705,'745',1615),(985467,379,'849_743_745',1615),(985468,1615,'746',1620),(985469,379,'849_743_745_746',1620),(985470,1620,'747',1437),(985471,379,'849_743_745_746_747',1437),(985472,1615,'748',1562),(985473,379,'849_743_745_748',1562),(985474,379,'849_749',1516),(985475,379,'849_750',1559),(985476,379,'849_751',1518),(985477,1518,'752',1527),(985478,379,'849_751_752',1527),(985479,1527,'753',1533),(985480,379,'849_751_752_753',1533),(985481,1518,'754',1524),(985482,379,'849_751_754',1524),(985483,379,'849_755',1536),(985484,379,'849_756',1539),(985485,379,'849_757',1797),(985486,1797,'758',1574),(985487,379,'849_757_758',1574),(985488,1797,'759',1566),(985489,379,'849_757_759',1566),(985490,1566,'760',1570),(985491,379,'849_757_759_760',1570),(985492,379,'849_761',1735),(985493,1735,'762',1600),(985494,379,'849_761_762',1600),(985495,1600,'763',1556),(985496,379,'849_761_762_763',1556),(985497,1735,'764',1605),(985498,379,'849_761_764',1605),(985499,1735,'765',1749),(985500,379,'849_761_765',1749),(985501,1749,'766',1556),(985502,379,'849_761_765_766',1556),(985503,379,'849_767',1773),(985504,1773,'768',1777),(985505,379,'849_767_768',1777),(985506,1777,'769',1781),(985507,379,'849_767_768_769',1781),(985510,379,'849_771',1754),(985511,1754,'772',1709),(985512,379,'849_771_772',1709),(985513,1754,'773',1667),(985514,379,'849_771_773',1667),(985515,1667,'774',1659),(985516,379,'849_771_773_774',1659),(985517,1667,'775',1673),(985518,379,'849_771_773_775',1673),(985521,1754,'777',1762),(985522,379,'849_771_777',1762),(985523,379,'849_778',1593),(985526,379,'849_780',1788),(985527,1788,'781',1765),(985528,379,'849_780_781',1765),(985529,1765,'782',1770),(985530,379,'849_780_781_782',1770),(985531,1788,'783',1640),(985532,379,'849_780_783',1640),(985533,1788,'784',1784),(985534,379,'849_780_784',1784),(985535,1784,'785',1770),(985536,379,'849_780_784_785',1770),(985537,1788,'786',1541),(985538,379,'849_780_786',1541),(985539,379,'849_787',1631),(985542,1631,'789',1644),(985543,379,'849_787_789',1644),(985544,1631,'790',1648),(985545,379,'849_787_790',1648),(985546,1648,'791',1612),(985547,379,'849_787_790_791',1612),(985548,1631,'792',1608),(985549,379,'849_787_792',1608),(985550,1608,'793',1612),(985551,379,'849_787_792_793',1612),(985552,379,'849_794',1715),(985553,1715,'795',1723),(985554,379,'849_794_795',1723),(985555,1723,'796',1697),(985556,379,'849_794_795_796',1697),(985557,1715,'797',1727),(985558,379,'849_794_797',1727),(985559,1727,'798',1697),(985560,379,'849_794_797_798',1697),(985561,1715,'799',1693),(985562,379,'849_794_799',1693),(985563,1693,'800',1697),(985564,379,'849_794_799_800',1697),(985565,1715,'801',1731),(985566,379,'849_794_801',1731),(985567,1731,'802',1697),(985568,379,'849_794_801_802',1697),(985569,1325,'803',1400),(985570,4,'847_686_803',1400),(985571,1400,'804',1404),(985572,4,'847_686_803_804',1404),(985573,1773,'805',1828),(985574,379,'849_767_805',1828),(985575,1754,'806',1838),(985576,379,'849_771_806',1838),(985577,1754,'807',1836),(985578,379,'849_771_807',1836),(985579,1593,'808',1841),(985580,379,'849_778_808',1841),(985581,1631,'809',1847),(985582,379,'849_787_809',1847),(985583,1631,'810',1845),(985584,379,'849_787_810',1845),(985585,844,'811',1849),(985586,1849,'812',844),(985587,1858,'813',415),(985588,415,'814',1858),(985589,717,'815',1862),(985590,1862,'816',717),(985591,1862,'817',4),(985592,4,'818',1862),(985593,1870,'819',97),(985594,1870,'820',97),(985595,1870,'821',89),(985596,1870,'822',89),(985597,1870,'823',70),(985598,4,'824',1886),(985599,1886,'825',4),(985600,97,'826',177),(985601,177,'827',97),(985602,177,'828',89),(985603,89,'829',177),(985604,89,'830',97),(985605,97,'831',89),(985606,89,'832',373),(985607,729,'833',740),(985608,40,'834',1885),(985609,1885,'835',40),(985610,70,'836',1886),(985611,1886,'837',70),(985612,1884,'838',1883),(985613,1883,'839',4),(985614,770,'833',740),(985615,857,'833',740),(985616,886,'833',740),(985617,781,'833',740),(985618,812,'833',740),(985619,794,'833',740),(985620,868,'833',740),(985621,981,'833',740),(985622,1883,'819',97),(985623,1884,'819',97),(985624,1883,'820',97),(985625,1884,'820',97),(985626,1883,'821',89),(985627,1884,'821',89),(985628,1883,'822',89),(985629,1884,'822',89),(985630,1883,'823',70),(985631,1884,'823',70),(985632,4,'584',220),(985633,261,'584',220),(985634,333,'584',220),(985635,224,'584',220),(985636,297,'584',220),(985637,4,'813',415),(985638,261,'813',415),(985639,333,'813',415),(985640,224,'813',415),(985641,297,'813',415),(985642,415,'814',4),(985643,415,'814',261),(985644,415,'814',333),(985645,415,'814',224),(985646,415,'814',297),(985647,4,'567',4),(985648,261,'567',261),(985649,333,'567',333),(985650,224,'567',224),(985651,297,'567',297),(985652,4,'274',4),(985653,261,'274',261),(985654,333,'274',333),(985655,224,'274',224),(985656,297,'274',297),(985657,261,'818',1862),(985658,333,'818',1862),(985659,224,'818',1862),(985660,297,'818',1862),(985661,1862,'817',261),(985662,1862,'817',333),(985663,1862,'817',224),(985664,1862,'817',297),(985665,261,'824',1886),(985666,333,'824',1886),(985667,224,'824',1886),(985668,297,'824',1886),(985669,1886,'825',261),(985670,1886,'825',333),(985671,1886,'825',224),(985672,1886,'825',297),(985673,949,'550',261),(985674,949,'550',333),(985675,949,'550',224),(985676,949,'550',297),(985677,740,'499',261),(985678,740,'499',333),(985679,740,'499',224),(985680,740,'499',297),(985681,1887,'816',717),(985682,1888,'816',717),(985683,1889,'816',717),(985684,1890,'816',717),(985685,717,'815',1887),(985686,717,'815',1888),(985687,717,'815',1889),(985688,717,'815',1890),(985689,1887,'817',4),(985690,1888,'817',4),(985691,1889,'817',4),(985692,1890,'817',4),(985693,4,'818',1887),(985694,4,'818',1888),(985695,4,'818',1889),(985696,4,'818',1890),(985697,628,'814',1858),(985698,607,'814',1858),(985699,458,'814',1858),(985700,497,'814',1858),(985701,595,'814',1858),(985702,425,'814',1858),(985703,470,'814',1858),(985704,486,'814',1858),(985705,437,'814',1858),(985706,448,'814',1858),(985707,508,'814',1858),(985708,550,'814',1858),(985709,535,'814',1858),(985710,562,'814',1858),(985711,518,'814',1858),(985712,573,'814',1858),(985713,1858,'813',628),(985714,1858,'813',607),(985715,1858,'813',458),(985716,1858,'813',497),(985717,1858,'813',595),(985718,1858,'813',425),(985719,1858,'813',470),(985720,1858,'813',486),(985721,1858,'813',437),(985722,1858,'813',448),(985723,1858,'813',508),(985724,1858,'813',550),(985725,1858,'813',535),(985726,1858,'813',562),(985727,1858,'813',518),(985728,1858,'813',573),(985729,628,'814',4),(985730,607,'814',4),(985731,458,'814',4),(985732,497,'814',4),(985733,595,'814',4),(985734,425,'814',4),(985735,470,'814',4),(985736,486,'814',4),(985737,437,'814',4),(985738,448,'814',4),(985739,508,'814',4),(985740,550,'814',4),(985741,535,'814',4),(985742,562,'814',4),(985743,518,'814',4),(985744,573,'814',4),(985745,4,'813',628),(985746,4,'813',607),(985747,4,'813',458),(985748,4,'813',497),(985749,4,'813',595),(985750,4,'813',425),(985751,4,'813',470),(985752,4,'813',486),(985753,4,'813',437),(985754,4,'813',448),(985755,4,'813',508),(985756,4,'813',550),(985757,4,'813',535),(985758,4,'813',562),(985759,4,'813',518),(985760,4,'813',573),(985761,628,'814',261),(985762,607,'814',261),(985763,458,'814',261),(985764,497,'814',261),(985765,595,'814',261),(985766,425,'814',261),(985767,470,'814',261),(985768,486,'814',261),(985769,437,'814',261),(985770,448,'814',261),(985771,508,'814',261),(985772,550,'814',261),(985773,535,'814',261),(985774,562,'814',261),(985775,518,'814',261),(985776,573,'814',261),(985777,261,'813',628),(985778,261,'813',607),(985779,261,'813',458),(985780,261,'813',497),(985781,261,'813',595),(985782,261,'813',425),(985783,261,'813',470),(985784,261,'813',486),(985785,261,'813',437),(985786,261,'813',448),(985787,261,'813',508),(985788,261,'813',550),(985789,261,'813',535),(985790,261,'813',562),(985791,261,'813',518),(985792,261,'813',573),(985793,628,'814',333),(985794,607,'814',333),(985795,458,'814',333),(985796,497,'814',333),(985797,595,'814',333),(985798,425,'814',333),(985799,470,'814',333),(985800,486,'814',333),(985801,437,'814',333),(985802,448,'814',333),(985803,508,'814',333),(985804,550,'814',333),(985805,535,'814',333),(985806,562,'814',333),(985807,518,'814',333),(985808,573,'814',333),(985809,333,'813',628),(985810,333,'813',607),(985811,333,'813',458),(985812,333,'813',497),(985813,333,'813',595),(985814,333,'813',425),(985815,333,'813',470),(985816,333,'813',486),(985817,333,'813',437),(985818,333,'813',448),(985819,333,'813',508),(985820,333,'813',550),(985821,333,'813',535),(985822,333,'813',562),(985823,333,'813',518),(985824,333,'813',573),(985825,628,'814',224),(985826,607,'814',224),(985827,458,'814',224),(985828,497,'814',224),(985829,595,'814',224),(985830,425,'814',224),(985831,470,'814',224),(985832,486,'814',224),(985833,437,'814',224),(985834,448,'814',224),(985835,508,'814',224),(985836,550,'814',224),(985837,535,'814',224),(985838,562,'814',224),(985839,518,'814',224),(985840,573,'814',224),(985841,224,'813',628),(985842,224,'813',607),(985843,224,'813',458),(985844,224,'813',497),(985845,224,'813',595),(985846,224,'813',425),(985847,224,'813',470),(985848,224,'813',486),(985849,224,'813',437),(985850,224,'813',448),(985851,224,'813',508),(985852,224,'813',550),(985853,224,'813',535),(985854,224,'813',562),(985855,224,'813',518),(985856,224,'813',573),(985857,628,'814',297),(985858,607,'814',297),(985859,458,'814',297),(985860,497,'814',297),(985861,595,'814',297),(985862,425,'814',297),(985863,470,'814',297),(985864,486,'814',297),(985865,437,'814',297),(985866,448,'814',297),(985867,508,'814',297),(985868,550,'814',297),(985869,535,'814',297),(985870,562,'814',297),(985871,518,'814',297),(985872,573,'814',297),(985873,297,'813',628),(985874,297,'813',607),(985875,297,'813',458),(985876,297,'813',497),(985877,297,'813',595),(985878,297,'813',425),(985879,297,'813',470),(985880,297,'813',486),(985881,297,'813',437),(985882,297,'813',448),(985883,297,'813',508),(985884,297,'813',550),(985885,297,'813',535),(985886,297,'813',562),(985887,297,'813',518),(985888,297,'813',573),(985889,333,'567',261),(985890,333,'567',224),(985891,333,'567',297),(985892,4,'567',333),(985893,4,'567',224),(985894,4,'567',297),(985895,4,'567',261),(985896,224,'567',261),(985897,224,'567',333),(985898,224,'567',297),(985899,261,'567',333),(985900,261,'567',224),(985901,261,'567',297),(985902,297,'567',261),(985903,297,'567',333),(985904,297,'567',224),(985905,333,'274',261),(985906,333,'274',224),(985907,333,'274',297),(985908,4,'274',333),(985909,4,'274',224),(985910,4,'274',297),(985911,4,'274',261),(985912,224,'274',261),(985913,224,'274',333),(985914,224,'274',297),(985915,261,'274',333),(985916,261,'274',224),(985917,261,'274',297),(985918,297,'274',261),(985919,297,'274',333),(985920,297,'274',224),(985921,89,'832',379),(985922,177,'591_281_207',4),(985923,177,'591_281_481',261),(985924,177,'591_281_145',333),(985925,177,'591_281_149',224),(985926,177,'591_281_489',297),(985927,177,'591_281_205',685),(985928,754,'441_499',4),(985929,754,'441_499',261),(985930,754,'441_499',333),(985931,754,'441_499',224),(985932,754,'441_499',297),(985933,379,'538_520',844),(985934,70,'836_825',4),(985935,70,'836_825',261),(985936,70,'836_825',333),(985937,70,'836_825',224),(985938,70,'836_825',297),(985939,830,'281_207',4),(985940,830,'281_481',261),(985941,830,'281_145',333),(985942,830,'281_149',224),(985943,830,'281_489',297),(985944,89,'832_207',4),(985945,89,'832_481',261),(985946,89,'832_145',333),(985947,89,'832_149',224),(985948,89,'832_489',297),(985949,762,'245_441_499',4),(985950,762,'245_441_499',261),(985951,762,'245_441_499',333),(985952,762,'245_441_499',224),(985953,762,'245_441_499',297),(985954,177,'591_520',844),(985955,177,'284_815',1862),(985956,177,'284_815',1887),(985957,177,'284_815',1888),(985958,177,'284_815',1889),(985959,177,'284_815',1890),(985960,729,'833_499',4),(985961,729,'833_499',261),(985962,729,'833_499',333),(985963,729,'833_499',224),(985964,729,'833_499',297),(985965,53,'840',949),(985966,177,'841',1924),(985967,1924,'842',177),(985968,1434,'671',1236),(985969,1271,'671',1236),(985970,1274,'671',1236),(985971,333,'567',261),(985972,333,'567',224),(985973,333,'567',297),(985974,4,'567',333),(985975,4,'567',224),(985976,4,'567',297),(985977,4,'567',261),(985978,224,'567',261),(985979,224,'567',333),(985980,224,'567',297),(985981,261,'567',333),(985982,261,'567',224),(985983,261,'567',297),(985984,297,'567',261),(985985,297,'567',333),(985986,297,'567',224),(985987,333,'274',261),(985988,333,'274',224),(985989,333,'274',297),(985990,4,'274',333),(985991,4,'274',224),(985992,4,'274',297),(985993,4,'274',261),(985994,224,'274',261),(985995,224,'274',333),(985996,224,'274',297),(985997,261,'274',333),(985998,261,'274',224),(985999,261,'274',297),(986000,297,'274',261),(986001,297,'274',333),(986002,297,'274',224),(986003,1930,'843',1936),(986004,1936,'844',1930),(986005,844,'845',1941),(986006,1941,'846',844),(986007,4,'847',1943),(986008,1943,'848',4),(986009,379,'849',1945),(986010,1945,'850',379),(986011,177,'851',1947),(986012,1947,'852',177),(986013,1941,'666',1283),(986014,1941,'667',1290),(986015,1941,'669',1227),(986016,1941,'670',1264),(986017,1941,'672',1271),(986018,1941,'674',1274),(986019,1941,'676',1230),(986020,1941,'678',1297),(986021,1941,'679',1241),(986022,1941,'682',1249),(986023,1941,'681',1254),(986024,1941,'680',1279),(986025,1941,'683',1277),(986026,1941,'684',1295),(986027,1941,'685',1300),(986028,1943,'686',1325),(986029,1943,'693',1359),(986030,1943,'694',1375),(986031,1943,'695',1349),(986032,1943,'696',1363),(986033,1943,'697',1377),(986034,1943,'700',1357),(986035,1943,'701',1386),(986036,1943,'702',1365),(986037,1945,'712',1440),(986038,1945,'717',1577),(986039,1945,'721',1461),(986040,1945,'732',1545),(986041,1945,'734',1676),(986042,1945,'740',1652),(986043,1945,'741',1794),(986044,1945,'742',1625),(986045,1945,'743',1705),(986046,1945,'749',1516),(986047,1945,'750',1559),(986048,1945,'751',1518),(986049,1945,'755',1536),(986050,1945,'756',1539),(986051,1945,'757',1797),(986052,1945,'761',1735),(986053,1945,'767',1773),(986054,1945,'771',1754),(986055,1945,'778',1593),(986056,1945,'780',1788),(986057,1945,'787',1631),(986058,1945,'794',1715),(986059,4,'544_538_174',177),(986060,297,'247_538_174',177),(986061,333,'250_538_174',177),(986062,261,'48_538_174',177),(986063,224,'189_538_174',177),(986064,177,'591_281_565',628),(986065,628,'467_538_174',177),(986066,177,'591_281_531',470),(986067,470,'58_538_174',177),(986068,177,'591_281_655',573),(986069,573,'15_538_174',177),(986070,177,'591_281_192',458),(986071,458,'648_538_174',177),(986072,177,'591_281_585',618),(986073,618,'157_538_174',177),(986074,177,'591_281_202',486),(986075,486,'403_538_174',177),(986076,177,'591_281_597',595),(986077,595,'104_538_174',177),(986078,177,'591_281_656',497),(986079,497,'306_538_174',177),(986080,177,'591_281_263',607),(986081,607,'473_538_174',177),(986082,177,'591_281_634',448),(986083,448,'299_538_174',177),(986084,177,'591_281_395',425),(986085,425,'180_538_174',177),(986086,177,'591_281_67',437),(986087,437,'495_538_174',177),(986088,177,'591_281_521',535),(986089,535,'580_538_174',177),(986090,177,'591_281_187',550),(986091,550,'3_538_174',177),(986092,177,'591_281_242',562),(986093,562,'332_538_174',177),(986094,177,'591_281_297',518),(986095,518,'276_538_174',177),(986096,53,'840_550_544_538_174',177),(986097,53,'840_550_247_538_174',177),(986098,53,'840_550_250_538_174',177),(986099,53,'840_550_48_538_174',177),(986100,53,'840_550_189_538_174',177);

/*Table structure for table `query_base_expression` */

DROP TABLE IF EXISTS `query_base_expression`;

CREATE TABLE `query_base_expression` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `EXPR_TYPE` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_base_expression` */

/*Table structure for table `query_condition` */

DROP TABLE IF EXISTS `query_condition`;

CREATE TABLE `query_condition` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `ATTRIBUTE_ID` bigint(20) NOT NULL,
  `RELATIONAL_OPERATOR` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_condition` */

/*Table structure for table `query_condition_values` */

DROP TABLE IF EXISTS `query_condition_values`;

CREATE TABLE `query_condition_values` (
  `CONDITION_ID` bigint(20) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `POSITION` int(11) NOT NULL,
  PRIMARY KEY (`CONDITION_ID`,`POSITION`),
  KEY `FK9997379D6458C2E7` (`CONDITION_ID`),
  CONSTRAINT `FK9997379D6458C2E7` FOREIGN KEY (`CONDITION_ID`) REFERENCES `query_condition` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_condition_values` */

/*Table structure for table `query_connector` */

DROP TABLE IF EXISTS `query_connector`;

CREATE TABLE `query_connector` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `OPERATOR` varchar(255) DEFAULT NULL,
  `NESTING_NUMBER` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_connector` */

/*Table structure for table `query_join_graph` */

DROP TABLE IF EXISTS `query_join_graph`;

CREATE TABLE `query_join_graph` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMMONS_GRAPH_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK2B41B5D09DBC4D94` (`COMMONS_GRAPH_ID`),
  CONSTRAINT `FK2B41B5D09DBC4D94` FOREIGN KEY (`COMMONS_GRAPH_ID`) REFERENCES `commons_graph` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_join_graph` */

/*Table structure for table `query_model_association` */

DROP TABLE IF EXISTS `query_model_association`;

CREATE TABLE `query_model_association` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_model_association` */

/*Table structure for table `query_operand` */

DROP TABLE IF EXISTS `query_operand`;

CREATE TABLE `query_operand` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `OPND_TYPE` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_operand` */

/*Table structure for table `query_output_term` */

DROP TABLE IF EXISTS `query_output_term`;

CREATE TABLE `query_output_term` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) DEFAULT NULL,
  `TIME_INTERVAL` varchar(255) DEFAULT NULL,
  `TERM_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK13C8A3D388C86B0D` (`TERM_ID`),
  CONSTRAINT `FK13C8A3D388C86B0D` FOREIGN KEY (`TERM_ID`) REFERENCES `query_base_expression` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_output_term` */

/*Table structure for table `query_parameter` */

DROP TABLE IF EXISTS `query_parameter`;

CREATE TABLE `query_parameter` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) DEFAULT NULL,
  `OBJECT_CLASS` varchar(255) DEFAULT NULL,
  `OBJECT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_parameter` */

/*Table structure for table `query_query_entity` */

DROP TABLE IF EXISTS `query_query_entity`;

CREATE TABLE `query_query_entity` (
  `IDENTIFIER` bigint(20) NOT NULL AUTO_INCREMENT,
  `ENTITY_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_query_entity` */

/*Table structure for table `query_rule_cond` */

DROP TABLE IF EXISTS `query_rule_cond`;

CREATE TABLE `query_rule_cond` (
  `RULE_ID` bigint(20) NOT NULL,
  `CONDITION_ID` bigint(20) NOT NULL,
  `POSITION` int(11) NOT NULL,
  PRIMARY KEY (`RULE_ID`,`POSITION`),
  KEY `FKC32D37AE6458C2E7` (`CONDITION_ID`),
  KEY `FKC32D37AE39F0A10D` (`RULE_ID`),
  CONSTRAINT `FKC32D37AE39F0A10D` FOREIGN KEY (`RULE_ID`) REFERENCES `query_operand` (`IDENTIFIER`),
  CONSTRAINT `FKC32D37AE6458C2E7` FOREIGN KEY (`CONDITION_ID`) REFERENCES `query_condition` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_rule_cond` */

/*Table structure for table `query_subexpr_operand` */

DROP TABLE IF EXISTS `query_subexpr_operand`;

CREATE TABLE `query_subexpr_operand` (
  `IDENTIFIER` bigint(20) NOT NULL,
  `EXPRESSION_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`IDENTIFIER`),
  KEY `FK2BF760E832E875C8` (`IDENTIFIER`),
  KEY `FK2BF760E8E92C814D` (`EXPRESSION_ID`),
  CONSTRAINT `FK2BF760E832E875C8` FOREIGN KEY (`IDENTIFIER`) REFERENCES `query_operand` (`IDENTIFIER`),
  CONSTRAINT `FK2BF760E8E92C814D` FOREIGN KEY (`EXPRESSION_ID`) REFERENCES `query_base_expression` (`IDENTIFIER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `query_subexpr_operand` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
